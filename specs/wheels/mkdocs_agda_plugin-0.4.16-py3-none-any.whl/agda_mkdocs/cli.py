"""Command-line interface for agda-mkdocs."""

import logging
import os
import shutil
from pathlib import Path

import click
import yaml

from .utils import get_module_name_from_file_path

log = logging.getLogger("mkdocs.plugins.agda")


# Custom YAML loader that handles !ENV tags
class EnvYAMLLoader(yaml.FullLoader):
    """YAML loader with support for !ENV tags."""

    pass


def env_constructor(loader, node):
    """Constructor for !ENV tags in YAML."""
    if isinstance(node, yaml.nodes.ScalarNode):
        # Single environment variable
        value = loader.construct_scalar(node)
        return os.environ.get(value, value)
    elif isinstance(node, yaml.nodes.SequenceNode):
        # List with variable name and default value
        values = loader.construct_sequence(node)
        if len(values) >= 2:
            var_name, default = values[0], values[1]
            return os.environ.get(var_name, default)
        elif len(values) == 1:
            return os.environ.get(values[0], values[0])
        else:
            return None
    return None


# Register the !ENV constructor
EnvYAMLLoader.add_constructor("!ENV", env_constructor)


def get_version() -> str:
    """Get the version from pyproject.toml."""
    import tomllib

    pyproject_path = Path(__file__).parent.parent.parent / "pyproject.toml"
    if not pyproject_path.exists():
        # Fallback for installed package
        try:
            from importlib.metadata import version

            return version("mkdocs-agda-plugin")
        except Exception:
            return "0.1.0"  # Default version if all else fails

    with open(pyproject_path, "rb") as f:
        pyproject = tomllib.load(f)
    return pyproject["project"]["version"]


def agda_options(f):
    """Decorator to add common Agda plugin options to CLI commands."""
    # Core options
    f = click.option("--agda-dir", default="html", help="Agda HTML output directory")(f)
    f = click.option(
        "--agda-config-dir", default=None, help="Agda config directory (.agda)"
    )(f)
    f = click.option(
        "--include-css/--no-include-css", default=True, help="Include Agda CSS"
    )(f)
    f = click.option(
        "--cache-dir", default=".agda-mkdocs-cache", help="Cache directory"
    )(f)
    f = click.option(
        "--highlight-code-only/--highlight-all",
        default=True,
        help="Highlight only code blocks",
    )(f)
    f = click.option(
        "--fail-on-error/--no-fail-on-error", default=False, help="Fail build on errors"
    )(f)
    f = click.option(
        "--force-rebuild/--no-force-rebuild",
        default=False,
        help="Force rebuild all files",
    )(f)

    # Compilation mode
    f = click.option(
        "--compilation-mode",
        type=click.Choice(["auto", "batch", "per-file"]),
        default="auto",
        help="Compilation strategy",
    )(f)
    f = click.option(
        "--auto-generate-index/--no-auto-generate-index",
        default=False,
        help="Auto-generate index file",
    )(f)
    f = click.option(
        "--index-file-name",
        default="everything.lagda.md",
        help="Index file name for batch compilation",
    )(f)
    f = click.option(
        "--compilation-timeout",
        type=int,
        default=30,
        help="Agda compilation timeout (seconds)",
    )(f)

    # Index generation
    f = click.option(
        "--generate-index/--no-generate-index",
        default=True,
        help="Generate module index",
    )(f)
    f = click.option(
        "--index-filename", default="agda-modules.md", help="Module index filename"
    )(f)
    f = click.option(
        "--generate-datatype-index/--no-generate-datatype-index",
        default=False,
        help="Generate datatype index",
    )(f)
    f = click.option(
        "--datatype-index-filename",
        default="agda-datatypes.md",
        help="Datatype index filename",
    )(f)
    f = click.option(
        "--generate-function-index/--no-generate-function-index",
        default=False,
        help="Generate function index",
    )(f)
    f = click.option(
        "--function-index-filename",
        default="agda-functions.md",
        help="Function index filename",
    )(f)

    # Symbol options
    f = click.option(
        "--include-operators/--no-include-operators",
        default=True,
        help="Include operators in indexes",
    )(f)
    f = click.option(
        "--track-cross-module-refs/--no-track-cross-module-refs",
        default=True,
        help="Track cross-module references",
    )(f)

    # Inline references
    f = click.option(
        "--enable-inline-references/--no-enable-inline-references",
        default=True,
        help="Enable Agda@name syntax",
    )(f)
    f = click.option(
        "--show-module-references/--no-show-module-references",
        default=True,
        help="Show module references",
    )(f)

    # Link handling
    f = click.option(
        "--rewrite-urls/--no-rewrite-urls", default=True, help="Enable URL rewriting"
    )(f)
    f = click.option(
        "--verify-links/--no-verify-links",
        default=True,
        help="Verify links after build",
    )(f)
    f = click.option(
        "--fail-on-broken-links/--no-fail-on-broken-links",
        default=False,
        help="Fail on broken links",
    )(f)

    # HTML options
    f = click.option(
        "--highlight-occurrences/--no-highlight-occurrences",
        default=False,
        help="Highlight symbol occurrences",
    )(f)
    f = click.option("--custom-css", default=None, help="Custom CSS file URL")(f)

    return f


def cli_options_to_plugin_config(cli_args):
    """Convert CLI arguments to plugin config format.

    Args:
        cli_args: Dictionary of CLI arguments from Click

    Returns:
        Dictionary in plugin config format
    """
    # Map CLI argument names (with hyphens) to plugin config names (with underscores)
    config = {}

    # Direct mappings
    mappings = {
        "agda_dir": "agda_dir",
        "agda_config_dir": "agda_config_dir",
        "include_css": "include_css",
        "cache_dir": "cache_dir",
        "highlight_code_only": "highlight_code_only",
        "fail_on_error": "fail_on_error",
        "force_rebuild": "force_rebuild",
        "compilation_mode": "compilation_mode",
        "auto_generate_index": "auto_generate_index",
        "index_file_name": "index_file_name",
        "compilation_timeout": "compilation_timeout",
        "generate_index": "generate_index",
        "index_filename": "index_filename",
        "generate_datatype_index": "generate_datatype_index",
        "datatype_index_filename": "datatype_index_filename",
        "generate_function_index": "generate_function_index",
        "function_index_filename": "function_index_filename",
        "include_operators": "include_operators",
        "track_cross_module_refs": "track_cross_module_refs",
        "enable_inline_references": "enable_inline_references",
        "show_module_references": "show_module_references",
        "rewrite_urls": "rewrite_urls",
        "verify_links": "verify_links",
        "fail_on_broken_links": "fail_on_broken_links",
        "highlight_occurrences": "highlight_occurrences",
        "custom_css": "custom_css",
    }

    for cli_key, config_key in mappings.items():
        if cli_key in cli_args and cli_args[cli_key] is not None:
            config[config_key] = cli_args[cli_key]

    return config


def apply_config_overrides(config_dict, agda_opts, cli_overrides):
    """Apply CLI options and overrides to mkdocs config.

    Args:
        config_dict: Original mkdocs config dictionary
        agda_opts: Agda options from CLI decorator
        cli_overrides: List of key=value strings from --set

    Returns:
        Modified config dictionary
    """
    import copy

    config = copy.deepcopy(config_dict)

    # Find agda plugin in config
    agda_plugin_config = None
    plugins = config.get("plugins", [])
    for i, plugin in enumerate(plugins):
        if isinstance(plugin, dict) and "agda" in plugin:
            agda_plugin_config = plugin["agda"] or {}
            break
        elif plugin == "agda":
            # Plugin with no config, create config dict
            plugins[i] = {"agda": {}}
            agda_plugin_config = plugins[i]["agda"]
            break

    if agda_plugin_config is None:
        # No agda plugin found, add it
        if not plugins:
            config["plugins"] = []
        config["plugins"].append({"agda": {}})
        agda_plugin_config = config["plugins"][-1]["agda"]

    # Apply agda options from decorator
    plugin_config = cli_options_to_plugin_config(agda_opts)
    agda_plugin_config.update(plugin_config)

    # Apply --set overrides
    for override in cli_overrides:
        if "=" not in override:
            click.echo(
                f"Warning: Invalid override format '{override}', expected key=value"
            )
            continue
        key, value = override.split("=", 1)
        # Try to parse value as boolean/int
        if value.lower() in ("true", "yes", "1"):
            value = True
        elif value.lower() in ("false", "no", "0"):
            value = False
        elif value.isdigit():
            value = int(value)
        agda_plugin_config[key] = value

    return config


@click.group()
@click.version_option(version=get_version())
def cli():
    """Agda-MkDocs: A tool for working with Agda literate markdown in MkDocs."""
    pass


@cli.command()
def check():
    """Check if Agda is installed and working."""
    if shutil.which("agda"):
        click.echo("[OK] Agda is installed")

        # Get Agda version
        import subprocess

        result = subprocess.run(["agda", "--version"], capture_output=True, text=True)
        if result.returncode == 0:
            click.echo(result.stdout.strip())
        return 0
    else:
        click.echo("[FAIL] Agda is not installed or not in PATH", err=True)
        click.echo("Please install Agda to use this plugin", err=True)
        return 1


@cli.command()
@click.option("--config", "-c", default="mkdocs.yml", help="MkDocs config file")
def doctor(config):
    """Check Agda installation and validate MkDocs configuration."""
    import subprocess
    import sys

    import yaml

    has_errors = False

    # Check Agda
    click.echo("Checking Agda installation...")
    if shutil.which("agda"):
        click.echo("  [OK] Agda is installed")
        result = subprocess.run(["agda", "--version"], capture_output=True, text=True)
        if result.returncode == 0:
            click.echo(f"  {result.stdout.strip()}")
    else:
        click.echo("  [FAIL] Agda is not installed or not in PATH", err=True)
        has_errors = True

    # Check MkDocs
    click.echo("\nChecking MkDocs installation...")
    if shutil.which("mkdocs"):
        click.echo("  [OK] MkDocs is installed")
        result = subprocess.run(["mkdocs", "--version"], capture_output=True, text=True)
        if result.returncode == 0:
            click.echo(f"  {result.stdout.strip()}")
    else:
        click.echo("  [FAIL] MkDocs is not installed or not in PATH", err=True)
        has_errors = True

    # Check MkDocs configuration
    click.echo(f"\nChecking MkDocs configuration: {config}")
    config_path = Path(config)
    if not config_path.exists():
        click.echo(f"  [FAIL] Config file not found: {config}", err=True)
        has_errors = True
    else:
        click.echo(f"  [OK] Config file exists: {config}")
        try:
            with open(config_path) as f:
                config_data = yaml.safe_load(f)

            # Check for agda plugin
            plugins = config_data.get("plugins", [])
            has_agda_plugin = False
            for plugin in plugins:
                if isinstance(plugin, dict) and "agda" in plugin:
                    has_agda_plugin = True
                    click.echo("  [OK] Agda plugin is configured")
                    agda_config = plugin["agda"]
                    if agda_config:
                        click.echo("  Plugin options:")
                        for key, value in agda_config.items():
                            click.echo(f"    - {key}: {value}")
                    break
                elif plugin == "agda":
                    has_agda_plugin = True
                    click.echo("  [OK] Agda plugin is configured (default options)")
                    break

            if not has_agda_plugin:
                click.echo("  [WARN] Agda plugin not found in plugins configuration")
                click.echo("  Add it to mkdocs.yml:")
                click.echo("    plugins:")
                click.echo("      - agda")

            # Check for Material theme (recommended)
            theme = config_data.get("theme", {})
            if isinstance(theme, dict):
                theme_name = theme.get("name", "")
            else:
                theme_name = theme

            if theme_name == "material":
                click.echo("  [OK] Using Material theme (recommended)")
            else:
                click.echo(f"  [INFO] Using theme: {theme_name}")
                click.echo("  Note: This plugin is optimized for Material theme")

            # Check docs directory
            docs_dir = config_data.get("docs_dir", "docs")
            docs_path = Path(docs_dir)
            if docs_path.exists():
                click.echo(f"  [OK] Docs directory exists: {docs_dir}")
                # Check for .lagda.md files
                lagda_files = list(docs_path.rglob("*.lagda.md"))
                if lagda_files:
                    click.echo(f"  [OK] Found {len(lagda_files)} Agda literate files")
                else:
                    click.echo("  [WARN] No .lagda.md files found in docs directory")
            else:
                click.echo(f"  [FAIL] Docs directory not found: {docs_dir}", err=True)
                has_errors = True

        except Exception as e:
            click.echo(f"  [FAIL] Error reading config: {e}", err=True)
            has_errors = True

    # Final summary
    click.echo("\n" + "=" * 60)
    if has_errors:
        click.echo("[FAIL] Some checks failed")
        sys.exit(1)
    else:
        click.echo("[OK] All checks passed")
        sys.exit(0)


@cli.command()
@click.option("--name", default="my-agda-docs", help="Project name")
@click.option(
    "--github-actions/--no-github-actions",
    default=True,
    help="Generate GitHub Actions workflow",
)
@click.option(
    "--with-libraries/--no-libraries",
    default=True,
    help="Set up Agda standard library and cubical library as git submodules",
)
def init(name, github_actions, with_libraries):
    """Initialize a new MkDocs project with Agda support."""
    import subprocess
    import sys

    project_dir = Path(name)

    if project_dir.exists():
        click.echo(f"Error: Directory '{name}' already exists", err=True)
        sys.exit(1)

    # Create project structure
    project_dir.mkdir()
    docs_dir = project_dir / "docs"
    docs_dir.mkdir()

    # Create mkdocs.yml with comprehensive plugin configuration
    mkdocs_config = f"""site_name: {name.replace("-", " ").title()}

theme:
  name: material
  features:
    - content.code.copy
    - navigation.sections

plugins:
  - search
  - tags:
      tags_file: tags.md
  - agda:
      # Core Options
      agda_config_dir: .agda              # Path to Agda config directory for project-local libraries
      cache_dir: .agda-mkdocs-cache       # Cache directory (relative to project root)
      highlight_code_only: true           # Only highlight code blocks (vs entire file)
      include_css: true                   # Include Agda CSS in output

      # Symbol Indexes (all enabled by default)
      generate_datatype_index: true       # Generate datatype index
      datatype_index_filename: agda-datatypes.md
      generate_function_index: true       # Generate function index
      function_index_filename: agda-functions.md
      generate_usage_index: true          # Generate symbol usage index
      usage_index_filename: agda-usage.md

      # Module References (LogSeq-style bidirectional links - enabled by default)
      show_module_references: true        # Show module references section
      show_backreferences: true           # Show who references this module
      show_forward_references: true       # Show what this module references

      # Inline References (Agda@symbol syntax - enabled by default)
      enable_inline_references: true      # Enable Agda@symbol inline references

      # Additional Options (see 'agda-mkdocs config' for full list)
      # agda_dir: html                    # Directory for Agda HTML output
      # backend: html                     # Agda backend: 'html' or 'latex'
      # compilation_timeout: 30           # Agda compilation timeout in seconds
      # force_rebuild: false              # Force rebuild all files, ignoring cache
      # fail_on_error: false              # Fail build on Agda compilation errors
      # verbose: false                    # Enable verbose logging
      # include_copy_button: true         # Add copy button to code blocks
      # custom_css: null                  # Custom CSS URL for Agda HTML backend
      # highlight_occurrences: false      # Enable occurrence highlighting
      # generate_index: true              # Generate module index
      # index_filename: agda-modules.md   # Module index filename
      # index_include_sections: false     # Group modules by sections in index
      # include_operators: true           # Include operators in symbol extraction
      # include_examples: true            # Include example code in symbol docs
      # min_usage_count: 1                # Minimum symbol usage count for indexes
      # track_cross_module_refs: true     # Track cross-module references
      # inline_ref_unresolved_warning: true  # Warn about unresolved inline refs
      # generate_references_section: true # Generate references section in pages
      # index_files: []                   # List of index files for batch compilation
      # auto_generate_index: false        # Auto-generate index file for batch compilation
      # index_file_name: everything.lagda.md  # Name of auto-generated index file

      # Run 'agda-mkdocs config' to see all available options with descriptions

markdown_extensions:
  - pymdownx.highlight:
      use_pygments: true
  - pymdownx.superfences
  - admonition
"""

    (project_dir / "mkdocs.yml").write_text(mkdocs_config)

    # Create example Agda file with tags
    example_agda = """---
title: Natural Numbers in Agda
tags:
  - agda
  - natural-numbers
  - tutorial
---

# Natural Numbers in Agda

This is an example of literate Agda programming with MkDocs.

## Basic Definition

Let's define natural numbers:

```agda
module Example where

data ℕ : Set where
  zero : ℕ
  suc  : ℕ → ℕ
```

## Addition

Now we can define addition:

```agda
_+_ : ℕ → ℕ → ℕ
zero + n = n
suc m + n = suc (m + n)
```

This will be highlighted by Agda when processed!
"""

    (docs_dir / "index.lagda.md").write_text(example_agda)

    # Create .gitignore
    gitignore_content = [
        ".agda-mkdocs-cache/",
        "site/",
        "*.agdai",
    ]

    if with_libraries:
        gitignore_content.extend(
            [
                ".agda/",
                "agda-libraries/",
            ]
        )

    gitignore = "\n".join(gitignore_content) + "\n"
    (project_dir / ".gitignore").write_text(gitignore)

    # Create pyproject.toml
    pyproject_toml = f"""[project]
name = "{name}"
version = "0.1.0"
description = "Agda documentation with MkDocs"
requires-python = ">=3.12"
dependencies = [
    "mkdocs-agda-plugin",
    "mkdocs-material>=9.5.0",
]

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"
"""

    (project_dir / "pyproject.toml").write_text(pyproject_toml)

    # Set up Agda libraries if requested
    if with_libraries:
        click.echo("Setting up Agda libraries...")

        # Create .agda directory structure
        agda_dir = project_dir / ".agda"
        agda_dir.mkdir()

        # Create .agda/defaults file
        defaults_content = "standard-library\ncubical\n"
        (agda_dir / "defaults").write_text(defaults_content)

        # Create .agda/libraries file (will be updated after submodules are added)
        libraries_content = "agda-libraries/agda-stdlib/standard-library.agda-lib\nagda-libraries/cubical/cubical.agda-lib\n"
        (agda_dir / "libraries").write_text(libraries_content)

        # Initialize git repository if not already a git repo
        try:
            subprocess.run(
                ["git", "rev-parse", "--git-dir"],
                cwd=project_dir,
                check=True,
                capture_output=True,
            )
            click.echo("  [OK] Using existing git repository")
        except subprocess.CalledProcessError:
            # Not a git repo, initialize one
            subprocess.run(
                ["git", "init"], cwd=project_dir, check=True, capture_output=True
            )
            click.echo("  [OK] Initialized git repository")

        # Create agda-libraries directory
        agda_libraries_dir = project_dir / "agda-libraries"
        agda_libraries_dir.mkdir()

        # Add git submodules
        try:
            click.echo("  Adding agda-stdlib submodule...")
            subprocess.run(
                [
                    "git",
                    "submodule",
                    "add",
                    "--depth=1",
                    "https://github.com/agda/agda-stdlib.git",
                    "agda-libraries/agda-stdlib",
                ],
                cwd=project_dir,
                check=True,
                capture_output=True,
            )
            click.echo("  [OK] Added agda-stdlib submodule")

            click.echo("  Adding cubical submodule...")
            subprocess.run(
                [
                    "git",
                    "submodule",
                    "add",
                    "--depth=1",
                    "https://github.com/agda/cubical.git",
                    "agda-libraries/cubical",
                ],
                cwd=project_dir,
                check=True,
                capture_output=True,
            )
            click.echo("  [OK] Added cubical submodule")

        except subprocess.CalledProcessError as e:
            click.echo(f"  [WARN] Failed to add git submodules: {e}", err=True)
            click.echo("  You can manually add them later with:")
            click.echo(f"    cd {name}")
            click.echo(
                "    git submodule add --depth=1 https://github.com/agda/agda-stdlib.git agda-libraries/agda-stdlib"
            )
            click.echo(
                "    git submodule add --depth=1 https://github.com/agda/cubical.git agda-libraries/cubical"
            )

    # Create GitHub Actions workflow if requested
    if github_actions:
        github_dir = project_dir / ".github" / "workflows"
        github_dir.mkdir(parents=True)

        workflow_content = """name: Build and Deploy Documentation

on:
  push:
    branches:
      - main
  pull_request:

permissions:
  contents: read
  pages: write
  id-token: write

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout repository
        uses: actions/checkout@v4"""

        if with_libraries:
            workflow_content += """
        with:
          submodules: recursive"""

        workflow_content += """

      - name: Setup Agda
        uses: wenkokke/setup-agda@latest
        with:
          agda-version: 'latest'

      - name: Setup Python
        uses: actions/setup-python@v5
        with:
          python-version: '3.12'

      - name: Install uv
        uses: astral-sh/setup-uv@v4

      - name: Install dependencies
        run: |
          uv sync

      - name: Build documentation
        run: |
          uv run mkdocs build --strict"""

        workflow_content += """

      - name: Upload artifact
        uses: actions/upload-pages-artifact@v3
        with:
          path: ./site

  deploy:
    if: github.ref == 'refs/heads/main'
    needs: build
    runs-on: ubuntu-latest
    environment:
      name: github-pages
      url: ${{ steps.deployment.outputs.page_url }}
    steps:
      - name: Deploy to GitHub Pages
        id: deployment
        uses: actions/deploy-pages@v4
"""

        workflow = workflow_content
        (github_dir / "deploy.yml").write_text(workflow)
        click.echo(
            "  [OK] Created GitHub Actions workflow: .github/workflows/deploy.yml"
        )

    click.echo(f"[OK] Created new Agda-MkDocs project: {name}")
    click.echo("  Next steps:")
    click.echo(f"    1. cd {name}")

    if with_libraries:
        click.echo("    2. uv sync  # Install dependencies and initialize submodules")
        click.echo("    3. uv run agda-mkdocs serve")
        click.echo("    4. Open http://localhost:8000")
        click.echo("  ")
        click.echo("  Agda libraries configured:")
        click.echo("    - Standard library (agda-stdlib)")
        click.echo("    - Cubical library")
        click.echo("    - Project-local .agda configuration")
    else:
        click.echo("    2. agda-mkdocs serve")
        click.echo("    3. Open http://localhost:8000")

    if github_actions:
        click.echo("  ")
        click.echo("  GitHub Actions is configured:")
        click.echo("    - Enable GitHub Pages in repository settings")
        click.echo("    - Set source to 'GitHub Actions'")
        click.echo("    - Push to main branch to trigger deployment")


@cli.command()
@click.argument("file", type=click.Path(exists=True))
@click.option("--output", "-o", help="Output file path")
def process(file, output):
    """Process a single Agda literate markdown file."""
    import tempfile

    from .processor import AgdaProcessor

    file_path = Path(file)

    if not file_path.name.endswith((".lagda", ".lagda.md", ".agda")):
        click.echo(f"Error: {file} is not an Agda literate file", err=True)
        return 1

    processor = AgdaProcessor(verbose=True)

    with tempfile.TemporaryDirectory() as temp_dir:
        try:
            content = file_path.read_text()
            processed = processor.process_file(
                file_path,
                content,
                Path(temp_dir),
            )

            if output:
                Path(output).write_text(processed)
                click.echo(f"[OK] Processed file written to: {output}")
            else:
                click.echo(processed)

        except Exception as e:
            click.echo(f"Error processing file: {e}", err=True)
            return 1

    return 0


@cli.command()
@click.option(
    "--path",
    "-p",
    default=".",
    help="Directory to search for cache directories (default: current directory)",
)
@click.option(
    "--cache-name",
    default=".agda-mkdocs-cache",
    help="Name of cache directory to search for (default: .agda-mkdocs-cache)",
)
@click.option("--config", "-c", default="mkdocs.yml", help="MkDocs config file")
@click.option(
    "--dry-run", is_flag=True, help="Show what would be deleted without deleting"
)
@click.option(
    "--all", is_flag=True, help="Also clear temporary Agda directories in /tmp"
)
def clear_cache(path, cache_name, config, dry_run, all):
    """Clear Agda processing cache directories and site directory.

    Reads mkdocs.yml to find the site_dir (default: site/) and
    cache_dir, then removes them along with temporary Agda directories.
    """
    import re
    import sys
    import tempfile

    search_path = Path(path).resolve()

    if not search_path.exists():
        click.echo(f"[FAIL] Path does not exist: {path}", err=True)
        sys.exit(1)

    cache_dirs = []
    index_files = []  # Track auto-generated index files to delete

    # Try to read mkdocs.yml to get site_dir and index files
    config_path = Path(config)
    if config_path.exists():
        # Resolve config directory outside try block so it's available in except
        config_dir = (
            config_path.parent.resolve()
            if not config_path.is_absolute()
            else config_path.parent
        )

        try:
            with open(config_path) as f:
                mkdocs_config = yaml.safe_load(f)

            docs_dir = config_dir / mkdocs_config.get("docs_dir", "docs")

            # Get site_dir (default: site)
            site_dir = config_dir / mkdocs_config.get("site_dir", "site")
            if site_dir.exists() and site_dir.is_dir():
                cache_dirs.append(site_dir)

            # Get cache_dir and index files from agda plugin config
            for plugin in mkdocs_config.get("plugins", []):
                if isinstance(plugin, dict) and "agda" in plugin:
                    agda_config = plugin["agda"] or {}
                    plugin_cache_dir = config_dir / agda_config.get(
                        "cache_dir", ".agda-mkdocs-cache"
                    )
                    if plugin_cache_dir.exists() and plugin_cache_dir.is_dir():
                        if plugin_cache_dir not in cache_dirs:
                            cache_dirs.append(plugin_cache_dir)

                    # Collect auto-generated index files
                    if agda_config.get("auto_generate_index", False):
                        index_file = docs_dir / agda_config.get(
                            "index_file_name", "everything.lagda.md"
                        )
                        if index_file.exists():
                            index_files.append(index_file)

                    if agda_config.get("generate_index", False):
                        index_file = docs_dir / agda_config.get(
                            "index_filename", "agda-modules.md"
                        )
                        if index_file.exists():
                            index_files.append(index_file)

                    if agda_config.get("generate_datatype_index", False):
                        index_file = docs_dir / agda_config.get(
                            "datatype_index_filename", "agda-datatypes.md"
                        )
                        if index_file.exists():
                            index_files.append(index_file)

                    if agda_config.get("generate_function_index", False):
                        index_file = docs_dir / agda_config.get(
                            "function_index_filename", "agda-functions.md"
                        )
                        if index_file.exists():
                            index_files.append(index_file)

                    if agda_config.get("generate_usage_index", False):
                        index_file = docs_dir / agda_config.get(
                            "usage_index_filename", "agda-usage.md"
                        )
                        if index_file.exists():
                            index_files.append(index_file)

                    break
        except Exception as e:
            # If YAML parsing fails (e.g., Material extensions), try regex
            log.debug(f"YAML parsing failed: {e}, using regex fallback")
            try:
                with open(config_path) as f:
                    content = f.read()

                # Get docs_dir
                docs_match = re.search(
                    r'^docs_dir:\s*["\']?([^"\'\n]+)["\']?', content, re.MULTILINE
                )
                docs_dir = (
                    config_dir / docs_match.group(1).strip()
                    if docs_match
                    else config_dir / "docs"
                )

                # Get site_dir
                site_match = re.search(
                    r'^site_dir:\s*["\']?([^"\'\n]+)["\']?', content, re.MULTILINE
                )
                if site_match:
                    site_dir = config_dir / site_match.group(1).strip()
                    if (
                        site_dir.exists()
                        and site_dir.is_dir()
                        and site_dir not in cache_dirs
                    ):
                        cache_dirs.append(site_dir)

                # Get cache_dir from agda plugin section
                cache_match = re.search(
                    r'cache_dir:\s*["\']?([^"\'\n]+)["\']?', content, re.MULTILINE
                )
                if cache_match:
                    cache_dir = config_dir / cache_match.group(1).strip()
                    if (
                        cache_dir.exists()
                        and cache_dir.is_dir()
                        and cache_dir not in cache_dirs
                    ):
                        cache_dirs.append(cache_dir)

                # Detect auto-generated index files using regex
                if re.search(r"auto_generate_index:\s*true", content):
                    index_name_match = re.search(
                        r'index_file_name:\s*["\']?([^"\'\n]+)["\']?', content
                    )
                    index_file = docs_dir / (
                        index_name_match.group(1).strip()
                        if index_name_match
                        else "everything.lagda.md"
                    )
                    if index_file.exists():
                        index_files.append(index_file)

                if re.search(r"generate_index:\s*true", content):
                    index_name_match = re.search(
                        r'index_filename:\s*["\']?([^"\'\n]+)["\']?', content
                    )
                    index_file = docs_dir / (
                        index_name_match.group(1).strip()
                        if index_name_match
                        else "agda-modules.md"
                    )
                    if index_file.exists():
                        index_files.append(index_file)

                if re.search(r"generate_datatype_index:\s*true", content):
                    index_name_match = re.search(
                        r'datatype_index_filename:\s*["\']?([^"\'\n]+)["\']?', content
                    )
                    index_file = docs_dir / (
                        index_name_match.group(1).strip()
                        if index_name_match
                        else "agda-datatypes.md"
                    )
                    if index_file.exists():
                        index_files.append(index_file)

                if re.search(r"generate_function_index:\s*true", content):
                    index_name_match = re.search(
                        r'function_index_filename:\s*["\']?([^"\'\n]+)["\']?', content
                    )
                    index_file = docs_dir / (
                        index_name_match.group(1).strip()
                        if index_name_match
                        else "agda-functions.md"
                    )
                    if index_file.exists():
                        index_files.append(index_file)

                if re.search(r"generate_usage_index:\s*true", content):
                    index_name_match = re.search(
                        r'usage_index_filename:\s*["\']?([^"\'\n]+)["\']?', content
                    )
                    index_file = docs_dir / (
                        index_name_match.group(1).strip()
                        if index_name_match
                        else "agda-usage.md"
                    )
                    if index_file.exists():
                        index_files.append(index_file)
            except Exception:
                pass

    # Find cache directories in the specified path
    if cache_name:
        # Look for the specific cache directory name
        found_dirs = list(search_path.rglob(cache_name))
        cache_dirs.extend([d for d in found_dirs if d.is_dir() and d not in cache_dirs])

    # Always check in the current working directory
    cwd_cache = Path.cwd() / cache_name
    if cwd_cache.exists() and cwd_cache.is_dir() and cwd_cache not in cache_dirs:
        cache_dirs.append(cwd_cache)

    # Check for cache in parent directories (up to 3 levels)
    current = Path.cwd()
    for _ in range(3):
        parent = current.parent
        if parent == current:  # Reached root
            break
        parent_cache = parent / cache_name
        if (
            parent_cache.exists()
            and parent_cache.is_dir()
            and parent_cache not in cache_dirs
        ):
            cache_dirs.append(parent_cache)
        current = parent

    # Also check for temporary Agda directories if --all flag is set
    if all:
        temp_dir = Path(tempfile.gettempdir())
        agda_temp_patterns = ["agda-*", "tmp*agda*", "mkdocs*agda*"]
        for pattern in agda_temp_patterns:
            for temp_cache in temp_dir.glob(pattern):
                if temp_cache.is_dir() and temp_cache not in cache_dirs:
                    cache_dirs.append(temp_cache)

    if not cache_dirs and not index_files:
        click.echo("No cache directories or index files found")
        if not all:
            click.echo("Tip: Use --all to also clear temporary Agda directories")
        sys.exit(0)

    # Display found directories
    if cache_dirs:
        click.echo(
            f"Found {len(cache_dirs)} cache director{'y' if len(cache_dirs) == 1 else 'ies'}:"
        )
        for cache_dir in cache_dirs:
            try:
                # Show size of cache directory
                size = sum(
                    f.stat().st_size for f in cache_dir.rglob("*") if f.is_file()
                )
                size_mb = size / (1024 * 1024)
                click.echo(f"  - {cache_dir} ({size_mb:.1f} MB)")
            except Exception:
                click.echo(f"  - {cache_dir}")

    # Display found index files
    if index_files:
        click.echo(
            f"\nFound {len(index_files)} auto-generated index file{'s' if len(index_files) != 1 else ''}:"
        )
        for index_file in index_files:
            try:
                size = index_file.stat().st_size / 1024
                click.echo(f"  - {index_file} ({size:.1f} KB)")
            except Exception:
                click.echo(f"  - {index_file}")

    if dry_run:
        click.echo("\n[DRY RUN] No files or directories were deleted")
        sys.exit(0)

    # Confirm deletion
    if len(cache_dirs) + len(index_files) > 1 or all:
        if not click.confirm("\nDelete these items?", default=False):
            click.echo("Cancelled")
            sys.exit(0)

    # Remove cache directories and index files
    import sys

    from tqdm import tqdm

    cleared_dirs = 0
    cleared_files = 0
    total_size = 0

    # Remove cache directories
    if cache_dirs:
        with tqdm(
            cache_dirs,
            desc="Clearing caches",
            unit="dir",
            disable=not sys.stdout.isatty(),
        ) as pbar:
            for cache_dir in pbar:
                try:
                    # Calculate size before deletion
                    size = sum(
                        f.stat().st_size for f in cache_dir.rglob("*") if f.is_file()
                    )
                    total_size += size

                    shutil.rmtree(cache_dir)
                    cleared_dirs += 1
                    pbar.set_description(f"Cleared {cache_dir.name}")
                except Exception as e:
                    tqdm.write(f"  [FAIL] Error removing {cache_dir}: {e}")

    # Remove index files
    if index_files:
        with tqdm(
            index_files,
            desc="Removing index files",
            unit="file",
            disable=not sys.stdout.isatty(),
        ) as pbar:
            for index_file in pbar:
                try:
                    size = index_file.stat().st_size
                    total_size += size

                    index_file.unlink()
                    cleared_files += 1
                    pbar.set_description(f"Removed {index_file.name}")
                except Exception as e:
                    tqdm.write(f"  [FAIL] Error removing {index_file}: {e}")

    total_mb = total_size / (1024 * 1024)
    summary_parts = []
    if cleared_dirs > 0:
        summary_parts.append(
            f"{cleared_dirs} cache director{'y' if cleared_dirs == 1 else 'ies'}"
        )
    if cleared_files > 0:
        summary_parts.append(
            f"{cleared_files} index file{'s' if cleared_files != 1 else ''}"
        )

    summary = " and ".join(summary_parts)
    click.echo(f"\n[OK] Cleared {summary} ({total_mb:.1f} MB freed)")
    sys.exit(0)


@cli.command(name="config")
def show_config():
    """Show all available plugin configuration options.

    Displays all configuration options for the agda-mkdocs plugin
    with their descriptions, types, and default values.
    """
    options = [
        # Core options
        ("agda_dir", "str", "html", "Directory for Agda HTML output"),
        (
            "agda_config_dir",
            "str",
            "None",
            "Path to Agda config directory (.agda) for project-local libraries",
        ),
        (
            "cache_dir",
            "str",
            ".agda-mkdocs-cache",
            "Cache directory (relative to project root)",
        ),
        ("backend", "str", "html", "Agda backend: 'html' or 'latex'"),
        (
            "highlight_code_only",
            "bool",
            "True",
            "Only highlight code blocks (vs entire file)",
        ),
        (
            "compilation_timeout",
            "int",
            "30",
            "Agda compilation timeout in seconds",
        ),
        # Build control
        (
            "force_rebuild",
            "bool",
            "False",
            "Force rebuild all files, ignoring cache",
        ),
        ("fail_on_error", "bool", "False", "Fail build on Agda compilation errors"),
        ("verbose", "bool", "False", "Enable verbose logging"),
        # Styling
        ("include_css", "bool", "True", "Include Agda CSS in output"),
        ("include_copy_button", "bool", "True", "Add copy button to code blocks"),
        ("custom_css", "str", "None", "Custom CSS URL for Agda HTML backend"),
        ("highlight_occurrences", "bool", "False", "Enable occurrence highlighting"),
        # Index generation
        ("generate_index", "bool", "True", "Generate module index"),
        ("index_filename", "str", "agda-modules.md", "Module index filename"),
        (
            "index_include_sections",
            "bool",
            "False",
            "Group modules by sections in index",
        ),
        # Symbol indexes
        ("generate_datatype_index", "bool", "False", "Generate datatype index"),
        (
            "datatype_index_filename",
            "str",
            "agda-datatypes.md",
            "Datatype index filename",
        ),
        ("generate_function_index", "bool", "False", "Generate function index"),
        (
            "function_index_filename",
            "str",
            "agda-functions.md",
            "Function index filename",
        ),
        ("generate_usage_index", "bool", "False", "Generate symbol usage index"),
        ("usage_index_filename", "str", "agda-usage.md", "Usage index filename"),
        # Symbol extraction
        (
            "include_operators",
            "bool",
            "True",
            "Include operators in symbol extraction",
        ),
        ("include_examples", "bool", "True", "Include example code in symbol docs"),
        (
            "min_usage_count",
            "int",
            "1",
            "Minimum symbol usage count for indexes",
        ),
        ("track_cross_module_refs", "bool", "True", "Track cross-module references"),
        # Inline references
        (
            "enable_inline_references",
            "bool",
            "True",
            "Enable Agda@symbol inline references",
        ),
        (
            "inline_ref_unresolved_warning",
            "bool",
            "True",
            "Warn about unresolved inline refs",
        ),
        (
            "generate_references_section",
            "bool",
            "True",
            "Generate references section in pages",
        ),
        # Module references (LogSeq-style)
        (
            "show_module_references",
            "bool",
            "True",
            "Show module references section",
        ),
        ("show_backreferences", "bool", "True", "Show who references this module"),
        (
            "show_forward_references",
            "bool",
            "True",
            "Show what this module references",
        ),
        # Batch compilation
        ("index_files", "list", "[]", "List of index files for batch compilation"),
        (
            "auto_generate_index",
            "bool",
            "False",
            "Auto-generate index file for batch compilation",
        ),
        (
            "index_file_name",
            "str",
            "everything.lagda.md",
            "Name of auto-generated index file",
        ),
    ]

    click.echo("=" * 80)
    click.echo("Agda-MkDocs Plugin Configuration Options")
    click.echo("=" * 80)
    click.echo()
    click.echo("Add these options to your mkdocs.yml under the 'agda' plugin:")
    click.echo()
    click.echo("plugins:")
    click.echo("  - agda:")
    click.echo("      option_name: value")
    click.echo()
    click.echo("=" * 80)
    click.echo()

    # Group options by category
    categories = {
        "Core Options": options[0:6],
        "Build Control": options[6:9],
        "Styling & CSS": options[9:13],
        "Index Generation": options[13:16],
        "Symbol Indexes": options[16:22],
        "Symbol Extraction": options[22:26],
        "Inline References": options[26:29],
        "Module References": options[29:32],
        "Batch Compilation": options[32:35],
    }

    for category, category_options in categories.items():
        click.echo(f"## {category}")
        click.echo()
        for name, type_, default, description in category_options:
            click.echo(f"  {name}:")
            click.echo(f"    Type:        {type_}")
            click.echo(f"    Default:     {default}")
            click.echo(f"    Description: {description}")
            click.echo()
        click.echo()

    click.echo("=" * 80)
    click.echo()
    click.echo("For more information, visit:")
    click.echo("  https://github.com/jonaprieto/agda-mkdocs")
    click.echo()


@cli.command()
@click.option("--config", "-c", default="mkdocs.yml", help="MkDocs config file")
@click.option("--watch", is_flag=True, help="Watch for changes and reprocess")
@click.option("--clean", is_flag=True, help="Clean cache before preprocessing")
@click.option("--verbose", "-v", is_flag=True, help="Enable verbose output")
def preprocess(config, watch, clean, verbose):
    """Preprocess Agda files and generate indexes.

    This command:
    1. Compiles all Agda files
    2. Extracts symbols and builds database
    3. Generates all configured indexes
    4. Caches everything for the build phase
    """
    import json
    import sys
    import tempfile
    import time
    from pathlib import Path

    import yaml
    from tqdm import tqdm

    from .cache import CacheManager
    from .index_generators import (
        DatatypeIndexGenerator,
        FunctionIndexGenerator,
        UsageIndexGenerator,
    )
    from .processor import AgdaProcessor
    from .symbol_extractor import SymbolDatabase, SymbolExtractor

    # Load MkDocs configuration
    config_path = Path(config)
    if not config_path.exists():
        click.echo(f"[FAIL] Config file not found: {config}", err=True)
        sys.exit(1)

    # Use custom YAML loader to handle !ENV tags
    with open(config_path) as f:
        mkdocs_config = yaml.load(f, Loader=EnvYAMLLoader)

    # Find agda plugin configuration
    agda_config = {}
    for plugin in mkdocs_config.get("plugins", []):
        if isinstance(plugin, dict) and "agda" in plugin:
            agda_config = plugin["agda"] or {}
            break

    docs_dir = Path(mkdocs_config.get("docs_dir", "docs"))
    cache_dir = Path(agda_config.get("cache_dir", ".agda-mkdocs-cache"))

    # Clean cache if requested
    if clean and cache_dir.exists():
        click.echo(f"Cleaning cache directory: {cache_dir}")
        shutil.rmtree(cache_dir)

    cache_dir.mkdir(parents=True, exist_ok=True)

    # Initialize components
    processor = AgdaProcessor(
        verbose=verbose,
        highlight_code_only=agda_config.get("highlight_code_only", True),
        agda_dir=agda_config.get("agda_dir", "html"),
        include_paths=agda_config.get("include_paths", []),
        timeout=agda_config.get("compilation_timeout", 30),
    )

    cache_manager = CacheManager(cache_dir)
    symbol_database = SymbolDatabase()
    symbol_extractor = SymbolExtractor(verbose=verbose)

    # Find all Agda files
    agda_files = []
    for ext in ["*.lagda.md", "*.lagda", "*.agda"]:
        agda_files.extend(docs_dir.rglob(ext))

    if not agda_files:
        click.echo(f"No Agda files found in {docs_dir}")
        return

    click.echo(f"Found {len(agda_files)} Agda files to process")

    # Process files
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)

        # Copy all Agda files to temp directory to resolve imports
        if verbose:
            click.echo("Copying all Agda files to temporary directory...")
        for agda_file in agda_files:
            relative_path = agda_file.relative_to(docs_dir)
            temp_file = temp_path / relative_path
            temp_file.parent.mkdir(parents=True, exist_ok=True)
            content = agda_file.read_text()
            # Strip YAML frontmatter before copying (needed for Agda compilation)
            agda_content = processor._strip_yaml_frontmatter(content)
            temp_file.write_text(agda_content)

        # Copy include paths (agda-libraries) to temp directory
        for include_path in agda_config.get("include_paths", []):
            include_src = Path(include_path)
            if include_src.exists() and include_src.is_dir():
                include_dest = temp_path / include_path
                if verbose:
                    click.echo(f"Copying include path: {include_path}")
                shutil.copytree(include_src, include_dest, dirs_exist_ok=True)

        # Use tqdm progress bar
        with tqdm(
            agda_files,
            desc="Processing files",
            unit="file",
            disable=not sys.stdout.isatty(),
        ) as pbar:
            for agda_file in pbar:
                relative_path = agda_file.relative_to(docs_dir)
                pbar.set_description(f"Processing {relative_path.name}")

                try:
                    content = agda_file.read_text()

                    # Check cache
                    if not clean and cache_manager.is_cached(agda_file, content):
                        if verbose:
                            tqdm.write(f"  {relative_path}: Using cached version")
                        # Still need to extract symbols from cached HTML
                        # Load cached processed content
                        _ = cache_manager.get_cached_content(agda_file)
                    else:
                        # Process with Agda
                        if verbose:
                            tqdm.write(f"  {relative_path}: Compiling with Agda...")
                        processed_content = processor.process_file(
                            relative_path,
                            content,
                            temp_path,
                            symbol_extractor=symbol_extractor,
                            symbol_database=symbol_database,
                            module_name=get_module_name_from_file_path(str(relative_path)),
                            module_url=get_module_name_from_file_path(str(relative_path)) + ".html",
                        )

                        # Cache the processed content
                        cache_manager.cache_content(
                            agda_file, content, processed_content
                        )

                except Exception as e:
                    tqdm.write(f"  [ERROR] {relative_path}: {e}")
                    if agda_config.get("fail_on_error", False):
                        sys.exit(1)

    # Save symbol database
    symbol_db_path = cache_dir / "symbols.db"
    click.echo(f"Saving symbol database to {symbol_db_path}")
    symbol_database.save(symbol_db_path)

    # Generate indexes
    index_tasks = []
    if agda_config.get("generate_datatype_index", False):
        index_tasks.append(
            (
                "datatype",
                agda_config.get("datatype_index_filename", "agda-datatypes.md"),
                DatatypeIndexGenerator,
            )
        )
    if agda_config.get("generate_function_index", False):
        index_tasks.append(
            (
                "function",
                agda_config.get("function_index_filename", "agda-functions.md"),
                FunctionIndexGenerator,
            )
        )
    if agda_config.get("generate_usage_index", False):
        index_tasks.append(
            (
                "usage",
                agda_config.get("usage_index_filename", "agda-usage.md"),
                UsageIndexGenerator,
            )
        )

    if index_tasks:
        click.echo("Generating indexes...")
        with tqdm(
            index_tasks,
            desc="Generating indexes",
            unit="index",
            disable=not sys.stdout.isatty(),
        ) as pbar:
            for index_type, filename, generator_class in pbar:
                pbar.set_description(f"Generating {index_type} index")
                generator = generator_class(symbol_database, agda_config)
                content = generator.generate_index()
                index_path = docs_dir / filename
                index_path.write_text(content)
                if verbose:
                    tqdm.write(f"  Generated {filename}")

    # Generate metadata
    metadata = {
        "preprocessed_at": time.time(),
        "agda_files": [str(f.relative_to(docs_dir)) for f in agda_files],
        "symbols_count": len(symbol_database.symbols),
        "references_count": len(symbol_database.references),
        "indexes_generated": [],
    }

    if agda_config.get("generate_datatype_index", False):
        metadata["indexes_generated"].append("datatypes")
    if agda_config.get("generate_function_index", False):
        metadata["indexes_generated"].append("functions")
    if agda_config.get("generate_usage_index", False):
        metadata["indexes_generated"].append("usage")

    metadata_path = cache_dir / "metadata.json"
    with open(metadata_path, "w") as f:
        json.dump(metadata, f, indent=2)

    click.echo(
        f"[OK] Preprocessing complete. {len(symbol_database.symbols)} symbols extracted."
    )

    if watch:
        click.echo("Watching for changes... (Press Ctrl+C to stop)")
        # TODO: Implement file watching
        click.echo("Watch mode not yet implemented")


@cli.command()
@click.option("--config", "-c", default="mkdocs.yml", help="MkDocs config file")
@click.option(
    "--site-dir", "-d", default=None, help="Output directory (default: site/)"
)
@click.option("--strict", is_flag=True, help="Enable strict mode (warnings as errors)")
@click.option("--verbose", "-v", is_flag=True, help="Enable verbose output")
@click.option("--quiet", "-q", is_flag=True, help="Suppress output")
@click.option("--clean", is_flag=True, help="Clean site directory before build")
@click.option(
    "--preprocess/--no-preprocess", default=True, help="Run preprocessing if needed"
)
@click.option(
    "--set",
    "config_overrides",
    multiple=True,
    help="Override Agda plugin config: --set key=value (e.g., --set compilation_mode=batch)",
)
def build(
    config,
    site_dir,
    strict,
    verbose,
    quiet,
    clean,
    preprocess,
    config_overrides,
):
    """Build the MkDocs documentation with preprocessing."""
    import json
    import os
    import subprocess
    import sys
    from pathlib import Path

    config_path = Path(config)

    # Apply config overrides if provided
    temp_config_file = None
    if config_overrides:
        # Since mkdocs doesn't support env var overrides for plugin config,
        # and the config may contain complex YAML (Material theme extensions),
        # we show a warning instead of trying to parse and modify
        click.echo("Warning: --set option not fully implemented yet")
        click.echo(f"Please modify {config} directly to change plugin settings for now")

    try:
        # Load config for preprocessing check only
        if preprocess:
            # Try to load config, but if it fails due to Material extensions, skip preprocessing check
            try:
                with open(config_path) as f:
                    mkdocs_config = yaml.safe_load(f)
            except yaml.constructor.ConstructorError:
                # Config has Material extensions, skip preprocessing check
                if not quiet:
                    click.echo("Skipping preprocessing check (complex YAML config)")
                mkdocs_config = None

            if mkdocs_config:
                # Find agda plugin configuration
                agda_config = {}
                for plugin in mkdocs_config.get("plugins", []):
                    if isinstance(plugin, dict) and "agda" in plugin:
                        agda_config = plugin["agda"] or {}
                        break

                cache_dir = Path(agda_config.get("cache_dir", ".agda-mkdocs-cache"))
                metadata_path = cache_dir / "metadata.json"

                # Check if preprocessing is up to date
                needs_preprocessing = True
                if metadata_path.exists():
                    with open(metadata_path) as f:
                        metadata = json.load(f)

                    # Check if any Agda file is newer than preprocessing
                    preprocessed_time = metadata.get("preprocessed_at", 0)
                    docs_dir = Path(mkdocs_config.get("docs_dir", "docs"))

                    needs_preprocessing = False
                    for agda_file in metadata.get("agda_files", []):
                        file_path = docs_dir / agda_file
                        if file_path.exists():
                            if file_path.stat().st_mtime > preprocessed_time:
                                needs_preprocessing = True
                                break

                if needs_preprocessing:
                    if not quiet:
                        click.echo("Running preprocessing...")

                    # Run preprocess command
                    from .cli import preprocess as preprocess_cmd

                    ctx = click.Context(preprocess_cmd)
                    ctx.invoke(
                        preprocess_cmd,
                        config=config,
                        verbose=verbose,
                        watch=False,
                        clean=False,
                    )

        # Run MkDocs build
        cmd = []
        if os.environ.get("VIRTUAL_ENV") or shutil.which("uv"):
            # Use uv run to ensure dependencies are available
            cmd = ["uv", "run", "mkdocs", "build", "--config-file", config]
        else:
            cmd = ["mkdocs", "build", "--config-file", config]

        if site_dir:
            cmd.extend(["--site-dir", site_dir])
        if strict:
            cmd.append("--strict")
        if verbose:
            cmd.append("--verbose")
        if quiet:
            cmd.append("--quiet")
        if clean:
            cmd.append("--clean")

        if not quiet:
            click.echo(f"Building site from: {config}")

        result = subprocess.run(cmd, check=False)
        exit_code = result.returncode

    except FileNotFoundError:
        click.echo("[FAIL] MkDocs not found. Please install mkdocs.", err=True)
        exit_code = 1
    except KeyboardInterrupt:
        click.echo("\nBuild interrupted")
        exit_code = 1
    finally:
        # Clean up temporary config file
        if temp_config_file and os.path.exists(temp_config_file):
            os.unlink(temp_config_file)

    sys.exit(exit_code)


@cli.command()
@click.option("--config", "-c", default="mkdocs.yml", help="MkDocs config file")
@click.option("--dev-addr", "-a", default="127.0.0.1:8000", help="Address to serve on")
@click.option("--strict", is_flag=True, help="Enable strict mode (warnings as errors)")
@click.option("--verbose", "-v", is_flag=True, help="Enable verbose output")
@click.option("--watch-theme", is_flag=True, help="Include theme directory in watch")
@click.option("--no-livereload", is_flag=True, help="Disable live reloading")
@click.option("--dirtyreload", is_flag=True, help="Only rebuild changed files")
@click.option(
    "--set",
    "config_overrides",
    multiple=True,
    help="Override Agda plugin config: --set key=value (e.g., --set verbose=true)",
)
def serve(
    config,
    dev_addr,
    strict,
    verbose,
    watch_theme,
    no_livereload,
    dirtyreload,
    config_overrides,
):
    """Start the MkDocs development server with live reload."""
    import os
    import subprocess
    import sys

    # Apply config overrides if provided
    temp_config_file = None
    if config_overrides:
        # Since mkdocs doesn't support env var overrides for plugin config,
        # and the config may contain complex YAML (Material theme extensions),
        # we show a warning instead of trying to parse and modify
        click.echo("Warning: --set option not fully implemented yet")
        click.echo(f"Please modify {config} directly to change plugin settings for now")

    try:
        # Check if we're in a uv environment
        cmd = []
        if os.environ.get("VIRTUAL_ENV") or shutil.which("uv"):
            # Use uv run to ensure dependencies are available
            cmd = [
                "uv",
                "run",
                "mkdocs",
                "serve",
                "--config-file",
                config,
                "--dev-addr",
                dev_addr,
            ]
        else:
            cmd = ["mkdocs", "serve", "--config-file", config, "--dev-addr", dev_addr]

        if strict:
            cmd.append("--strict")
        if verbose:
            cmd.append("--verbose")
        if watch_theme:
            cmd.append("--watch-theme")
        if no_livereload:
            cmd.append("--no-livereload")
        if dirtyreload:
            cmd.append("--dirtyreload")

        click.echo(f"Starting development server from: {config}")
        click.echo(f"Serving at: http://{dev_addr}")
        click.echo("Press Ctrl+C to stop")

        result = subprocess.run(cmd, check=False)
        exit_code = result.returncode

    except FileNotFoundError:
        click.echo("[FAIL] MkDocs not found. Please install mkdocs.", err=True)
        exit_code = 1
    except KeyboardInterrupt:
        click.echo("\nServer stopped")
        exit_code = 0
    finally:
        # Clean up temporary config file
        if temp_config_file and os.path.exists(temp_config_file):
            os.unlink(temp_config_file)

    sys.exit(exit_code)


if __name__ == "__main__":
    cli()
