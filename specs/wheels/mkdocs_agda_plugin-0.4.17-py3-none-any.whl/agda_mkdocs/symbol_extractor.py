"""Symbol extraction from Agda HTML output."""

import json
from dataclasses import dataclass
from enum import Enum
from pathlib import Path

from bs4 import BeautifulSoup

from .utils import log


class SymbolType(Enum):
    """Types of symbols that can be extracted from Agda HTML."""

    DATATYPE = "Datatype"
    RECORD = "Record"
    CONSTRUCTOR = "InductiveConstructor"
    FUNCTION = "Function"
    OPERATOR = "Function Operator"
    MODULE = "Module"
    PRIMITIVE = "Primitive"
    BOUND = "Bound"
    SYMBOL = "Symbol"


class ReferenceType(Enum):
    """Types of references between symbols."""

    USAGE = "usage"  # Symbol is used in expression
    DEFINITION = "definition"  # Symbol is defined here
    TYPE_ANNOTATION = "type"  # Symbol appears in type signature
    PATTERN_MATCH = "pattern"  # Symbol used in pattern matching


@dataclass
class Symbol:
    """A symbol extracted from Agda HTML."""

    name: str
    symbol_type: SymbolType
    module: str
    anchor_id: str
    line_number: int | None
    url: str
    signature: str | None = None
    description: str | None = None


@dataclass
class Reference:
    """A reference from one symbol to another."""

    from_symbol: str
    to_symbol: str
    from_module: str
    to_module: str
    reference_type: ReferenceType
    line_number: int | None = None
    context: str | None = None


class SymbolDatabase:
    """Central repository for all extracted symbols and references."""

    def __init__(self):
        """Initialize empty symbol database."""
        self.symbols: dict[str, Symbol] = {}
        self.references: list[Reference] = []
        self.module_symbols: dict[str, list[str]] = {}
        self.symbol_usage: dict[str, list[Reference]] = {}

    def add_symbol(self, symbol: Symbol) -> None:
        """Add a symbol to the database."""
        self.symbols[symbol.name] = symbol

        if symbol.module not in self.module_symbols:
            self.module_symbols[symbol.module] = []
        self.module_symbols[symbol.module].append(symbol.name)

    def add_reference(self, reference: Reference) -> None:
        """Add a reference to the database."""
        self.references.append(reference)

        if reference.to_symbol not in self.symbol_usage:
            self.symbol_usage[reference.to_symbol] = []
        self.symbol_usage[reference.to_symbol].append(reference)

    def get_by_type(self, symbol_type: SymbolType) -> list[Symbol]:
        """Get all symbols of a specific type."""
        return [
            symbol
            for symbol in self.symbols.values()
            if symbol.symbol_type == symbol_type
        ]

    def get_by_module(self, module: str) -> list[Symbol]:
        """Get all symbols from a specific module."""
        symbol_names = self.module_symbols.get(module, [])
        return [self.symbols[name] for name in symbol_names if name in self.symbols]

    def get_references_to(self, symbol_name: str) -> list[Reference]:
        """Get all references to a specific symbol."""
        return self.symbol_usage.get(symbol_name, [])

    def get_symbol_by_anchor(self, module: str, anchor_id: str) -> Symbol | None:
        """Find a symbol by its module and anchor ID.

        Args:
            module: The module name
            anchor_id: The anchor ID from HTML

        Returns:
            Symbol if found, None otherwise
        """
        for symbol in self.symbols.values():
            if symbol.module == module and symbol.anchor_id == anchor_id:
                return symbol
        return None

    def resolve_anchor_references(self) -> int:
        """Resolve anchor ID references to actual symbol names.

        After all modules are processed, this method resolves references that
        use anchor IDs (like "476") to the actual symbol names (like "Tag").

        Returns:
            Number of references resolved
        """
        import logging

        log = logging.getLogger("mkdocs.plugins.agda")

        resolved_count = 0
        updated_references = []
        updated_usage = {}

        log.debug(
            f"Starting anchor resolution: {len(self.references)} references, {len(self.symbols)} symbols"
        )

        for ref in self.references:
            # Check if to_symbol looks like an anchor ID (numeric or doesn't match any symbol)
            if ref.to_symbol not in self.symbols:
                # Try to resolve by anchor ID
                target_symbol = self.get_symbol_by_anchor(ref.to_module, ref.to_symbol)
                if target_symbol:
                    # Create updated reference with resolved symbol name
                    updated_ref = Reference(
                        from_symbol=ref.from_symbol,
                        to_symbol=target_symbol.name,  # Use actual symbol name
                        from_module=ref.from_module,
                        to_module=ref.to_module,
                        reference_type=ref.reference_type,
                        line_number=ref.line_number,
                        context=ref.context,
                    )
                    updated_references.append(updated_ref)
                    resolved_count += 1

                    # Update usage mapping
                    if target_symbol.name not in updated_usage:
                        updated_usage[target_symbol.name] = []
                    updated_usage[target_symbol.name].append(updated_ref)
                else:
                    # Keep original reference if we can't resolve
                    updated_references.append(ref)
            else:
                # Symbol name is already correct
                updated_references.append(ref)
                if ref.to_symbol not in updated_usage:
                    updated_usage[ref.to_symbol] = []
                updated_usage[ref.to_symbol].append(ref)

        # Replace references and usage with resolved versions
        self.references = updated_references
        self.symbol_usage = updated_usage

        return resolved_count

    def get_module_references_from(self, module: str) -> dict[str, list[Reference]]:
        """Get all references from a module to other modules.

        Returns:
            Dictionary mapping target module names to list of references
        """
        module_refs = {}
        for ref in self.references:
            if ref.from_module == module and ref.to_module != module:
                if ref.to_module not in module_refs:
                    module_refs[ref.to_module] = []
                module_refs[ref.to_module].append(ref)
        return module_refs

    def get_module_references_to(self, module: str) -> dict[str, list[Reference]]:
        """Get all references to a module from other modules (backreferences).

        Returns:
            Dictionary mapping source module names to list of references
        """
        module_refs = {}
        for ref in self.references:
            if ref.to_module == module and ref.from_module != module:
                if ref.from_module not in module_refs:
                    module_refs[ref.from_module] = []
                module_refs[ref.from_module].append(ref)
        return module_refs

    def save(self, path: Path) -> None:
        """Serialize the symbol database to a JSON file.

        Args:
            path: Path to save the database
        """
        data = {
            "symbols": {
                name: {
                    "name": symbol.name,
                    "symbol_type": symbol.symbol_type.value,
                    "module": symbol.module,
                    "anchor_id": symbol.anchor_id,
                    "line_number": symbol.line_number,
                    "url": symbol.url,
                    "signature": symbol.signature,
                    "description": symbol.description,
                }
                for name, symbol in self.symbols.items()
            },
            "references": [
                {
                    "from_symbol": ref.from_symbol,
                    "to_symbol": ref.to_symbol,
                    "from_module": ref.from_module,
                    "to_module": ref.to_module,
                    "reference_type": ref.reference_type.value,
                    "line_number": ref.line_number,
                    "context": ref.context,
                }
                for ref in self.references
            ],
            "module_symbols": self.module_symbols,
        }

        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w") as f:
            json.dump(data, f, indent=2)

    @classmethod
    def load(cls, path: Path) -> "SymbolDatabase":
        """Load a symbol database from a JSON file.

        Args:
            path: Path to load the database from

        Returns:
            Loaded symbol database
        """
        if not path.exists():
            return cls()

        with open(path) as f:
            data = json.load(f)

        db = cls()

        # Load symbols
        for name, symbol_data in data.get("symbols", {}).items():
            symbol = Symbol(
                name=symbol_data["name"],
                symbol_type=SymbolType(symbol_data["symbol_type"]),
                module=symbol_data["module"],
                anchor_id=symbol_data["anchor_id"],
                line_number=symbol_data.get("line_number"),
                url=symbol_data["url"],
                signature=symbol_data.get("signature"),
                description=symbol_data.get("description"),
            )
            db.symbols[name] = symbol

        # Load references
        for ref_data in data.get("references", []):
            ref = Reference(
                from_symbol=ref_data["from_symbol"],
                to_symbol=ref_data["to_symbol"],
                from_module=ref_data["from_module"],
                to_module=ref_data["to_module"],
                reference_type=ReferenceType(ref_data["reference_type"]),
                line_number=ref_data.get("line_number"),
                context=ref_data.get("context"),
            )
            db.references.append(ref)

        # Load module symbols mapping
        db.module_symbols = data.get("module_symbols", {})

        # Rebuild symbol usage mapping
        for ref in db.references:
            if ref.to_symbol not in db.symbol_usage:
                db.symbol_usage[ref.to_symbol] = []
            db.symbol_usage[ref.to_symbol].append(ref)

        return db


class SymbolExtractor:
    """Extract symbols and references from Agda HTML output."""

    def __init__(self, verbose: bool = False):
        """Initialize symbol extractor."""
        self.verbose = verbose

    def extract_symbols(
        self, html_content: str, module_name: str, url: str
    ) -> SymbolDatabase:
        """Extract all symbols and references from HTML content."""
        soup = BeautifulSoup(html_content, "html.parser")
        database = SymbolDatabase()

        # Extract different types of symbols
        self._extract_datatypes(soup, module_name, url, database)
        self._extract_records(soup, module_name, url, database)
        self._extract_constructors(soup, module_name, url, database)
        self._extract_functions(soup, module_name, url, database)
        self._extract_modules(soup, module_name, url, database)
        self._extract_primitives(soup, module_name, url, database)

        # Extract references between symbols
        self._extract_references(soup, module_name, database)

        if self.verbose:
            log.debug(f"Extracted {len(database.symbols)} symbols from {module_name}")
            log.debug(f"Found {len(database.references)} references")

        return database

    def _extract_datatypes(
        self, soup: BeautifulSoup, module: str, url: str, database: SymbolDatabase
    ) -> None:
        """Extract datatype definitions."""
        for anchor in soup.find_all("a", class_="Datatype"):
            # Definition sites have href pointing to same file with anchor
            href = anchor.get("href")
            anchor_id = anchor.get("id")
            if href and anchor_id and f"#{anchor_id}" in href:
                symbol = self._create_symbol(anchor, SymbolType.DATATYPE, module, url)
                if symbol:
                    database.add_symbol(symbol)
                    if self.verbose:
                        log.debug(f"Found datatype: {symbol.name}")

    def _extract_records(
        self, soup: BeautifulSoup, module: str, url: str, database: SymbolDatabase
    ) -> None:
        """Extract record definitions."""
        for anchor in soup.find_all("a", class_="Record"):
            # Definition sites have href pointing to same file with anchor
            href = anchor.get("href")
            anchor_id = anchor.get("id")
            if href and anchor_id and f"#{anchor_id}" in href:
                symbol = self._create_symbol(anchor, SymbolType.RECORD, module, url)
                if symbol:
                    database.add_symbol(symbol)
                    if self.verbose:
                        log.debug(f"Found record: {symbol.name}")

    def _extract_constructors(
        self, soup: BeautifulSoup, module: str, url: str, database: SymbolDatabase
    ) -> None:
        """Extract constructor definitions."""
        for anchor in soup.find_all("a", class_="InductiveConstructor"):
            # Definition sites have href pointing to same file with anchor
            href = anchor.get("href")
            anchor_id = anchor.get("id")
            if href and anchor_id and f"#{anchor_id}" in href:
                symbol = self._create_symbol(
                    anchor, SymbolType.CONSTRUCTOR, module, url
                )
                if symbol:
                    database.add_symbol(symbol)
                    if self.verbose:
                        log.debug(f"Found constructor: {symbol.name}")

    def _extract_functions(
        self, soup: BeautifulSoup, module: str, url: str, database: SymbolDatabase
    ) -> None:
        """Extract function definitions."""
        # Regular functions
        for anchor in soup.find_all("a", class_="Function"):
            if "Operator" in anchor.get("class", []):
                continue  # Handle operators separately

            # Definition sites have href pointing to same file with anchor
            href = anchor.get("href")
            anchor_id = anchor.get("id")
            if href and anchor_id and f"#{anchor_id}" in href:
                symbol = self._create_symbol(anchor, SymbolType.FUNCTION, module, url)
                if symbol:
                    database.add_symbol(symbol)
                    if self.verbose:
                        log.debug(f"Found function: {symbol.name}")

        # Operator functions
        for anchor in soup.find_all("a", class_=["Function", "Operator"]):
            if not all(
                cls in anchor.get("class", []) for cls in ["Function", "Operator"]
            ):
                continue

            # Definition sites have href pointing to same file with anchor
            href = anchor.get("href")
            anchor_id = anchor.get("id")
            if href and anchor_id and f"#{anchor_id}" in href:
                symbol = self._create_symbol(anchor, SymbolType.OPERATOR, module, url)
                if symbol:
                    database.add_symbol(symbol)
                    if self.verbose:
                        log.debug(f"Found operator: {symbol.name}")

    def _extract_modules(
        self, soup: BeautifulSoup, module: str, url: str, database: SymbolDatabase
    ) -> None:
        """Extract module references."""
        for anchor in soup.find_all("a", class_="Module"):
            # Definition sites have href pointing to same file with anchor
            href = anchor.get("href")
            anchor_id = anchor.get("id")
            if href and anchor_id and f"#{anchor_id}" in href:
                symbol = self._create_symbol(anchor, SymbolType.MODULE, module, url)
                if symbol:
                    database.add_symbol(symbol)
                    if self.verbose:
                        log.debug(f"Found module: {symbol.name}")

    def _extract_primitives(
        self, soup: BeautifulSoup, module: str, url: str, database: SymbolDatabase
    ) -> None:
        """Extract primitive type references."""
        for anchor in soup.find_all("a", class_="Primitive"):
            symbol = self._create_symbol(anchor, SymbolType.PRIMITIVE, module, url)
            if symbol:
                database.add_symbol(symbol)
                if self.verbose:
                    log.debug(f"Found primitive: {symbol.name}")

    def _extract_references(
        self, soup: BeautifulSoup, module: str, database: SymbolDatabase
    ) -> None:
        """Extract references between symbols with improved context awareness."""

        for anchor in soup.find_all("a", href=True):
            href = anchor.get("href")
            if not href or not anchor.string:
                continue

            # Skip self-references (anchors within same page)
            if href.startswith("#") and not href.count("."):
                continue

            # Determine reference type based on context
            ref_type = self._determine_reference_type(anchor)

            # Extract target module and symbol from href
            target_module, target_symbol = self._parse_href(href)

            # Handle cross-module references (href contains .html but not just #anchor)
            if ".html" in href and target_module and target_module != module:
                # This is a cross-module reference
                # Use the anchor text as the symbol name if we don't have target_symbol
                if not target_symbol:
                    target_symbol = anchor.string.strip()

                # Try to determine the source symbol from context
                from_symbol = self._determine_source_symbol(anchor, database)
                if not from_symbol:
                    from_symbol = f"{module}.__context__"  # Default context indicator

                # Extract line number if possible
                line_number = self._extract_line_number(anchor)

                reference = Reference(
                    from_symbol=from_symbol,
                    to_symbol=target_symbol,
                    from_module=module,
                    to_module=target_module,
                    reference_type=ref_type,
                    line_number=line_number,
                    context=self._extract_context(anchor),
                )

                database.add_reference(reference)

                if self.verbose:
                    log.debug(
                        f"Cross-module reference: {module}.{from_symbol} -> {target_module}.{target_symbol}"
                    )
            elif target_symbol and not href.startswith("#"):
                # Handle other types of references
                from_symbol = self._determine_source_symbol(anchor, database)
                line_number = self._extract_line_number(anchor)

                reference = Reference(
                    from_symbol=from_symbol,
                    to_symbol=target_symbol,
                    from_module=module,
                    to_module=target_module or module,
                    reference_type=ref_type,
                    line_number=line_number,
                    context=self._extract_context(anchor),
                )

                database.add_reference(reference)

    def _create_symbol(
        self, anchor, symbol_type: SymbolType, module: str, url: str
    ) -> Symbol | None:
        """Create a symbol from an anchor element."""
        name = anchor.string
        if not name:
            return None

        # Get anchor ID from previous sibling or element itself
        anchor_id = anchor.get("id")
        if not anchor_id:
            # Look for previous anchor with ID
            prev_anchor = anchor.find_previous_sibling("a")
            if prev_anchor and prev_anchor.get("id"):
                anchor_id = prev_anchor.get("id")

        return Symbol(
            name=name.strip(),
            symbol_type=symbol_type,
            module=module,
            anchor_id=anchor_id or "",
            line_number=None,  # TODO: Extract from position
            url=f"{url}#{anchor_id}" if anchor_id else url,
            signature=self._extract_signature(anchor),
            description=self._extract_description(anchor),
        )

    def _determine_reference_type(self, anchor) -> ReferenceType:
        """Determine the type of reference based on context and position."""
        classes = anchor.get("class", [])
        text = anchor.string or ""

        # Look at surrounding context for better type detection
        parent = anchor.parent
        context_text = parent.get_text() if parent else ""

        # Type annotation context
        if ":" in context_text and ("Function" in classes or "Datatype" in classes):
            return ReferenceType.TYPE_ANNOTATION

        # Pattern matching context (left side of =)
        if "=" in context_text and context_text.find(text) < context_text.find("="):
            return ReferenceType.PATTERN_MATCH

        # Definition context (has anchor ID indicating it's a definition site)
        if anchor.get("id"):
            return ReferenceType.DEFINITION

        # Default to usage
        return ReferenceType.USAGE

    def _parse_href(self, href: str) -> tuple[str | None, str | None]:
        """Parse href to extract module and symbol."""
        if "#" in href:
            file_part, fragment = href.split("#", 1)
            # Extract module from file part
            if ".html" in file_part:
                module = file_part.replace(".html", "").replace("/", ".")
            else:
                module = None
            return module, fragment
        return None, None

    def _extract_context(self, anchor) -> str | None:
        """Extract meaningful surrounding context for a reference."""
        # Get the nearest code block or containing element
        current = anchor
        while current and current.name != "pre":
            current = current.parent

        if current and current.name == "pre":
            # Extract the line containing the reference
            full_text = current.get_text()
            anchor_text = anchor.string or ""
            if anchor_text in full_text:
                lines = full_text.split("\n")
                for line in lines:
                    if anchor_text in line:
                        return line.strip()[:200]  # Return the line, max 200 chars

        # Fallback to parent context
        parent = anchor.parent
        if parent:
            return parent.get_text()[:100]
        return None

    def _determine_source_symbol(self, anchor, database: SymbolDatabase) -> str:
        """Try to determine which symbol is making this reference."""
        # Look for nearby definition anchors
        prev_elements = anchor.find_all_previous(["a"])
        for elem in prev_elements[:5]:  # Check last 5 anchors
            if elem.get("id") and elem.string:
                return elem.string

        # Fallback: extract from context
        context = self._extract_context(anchor)
        if context:
            # Simple heuristic: look for identifier-like words before the reference
            words = context.split()
            for i, word in enumerate(words):
                if anchor.string and anchor.string in word and i > 0:
                    prev_word = words[i - 1]
                    if prev_word.replace("_", "").isalnum():
                        return prev_word

        return ""  # Unknown source

    def _extract_line_number(self, anchor) -> int | None:
        """Try to extract line number from anchor position."""
        # This is approximate - would need more sophisticated parsing
        # for accurate line numbers
        try:
            # Count newlines before this anchor in the document
            text_before = ""
            for elem in anchor.find_all_previous(string=True):
                text_before = elem + text_before

            return text_before.count("\n") + 1
        except Exception:
            return None

    def _extract_signature(self, anchor) -> str | None:
        """Extract type signature for a symbol."""
        # Look for type signature in surrounding context
        # This is a simplified implementation
        return None

    def _extract_description(self, anchor) -> str | None:
        """Extract description/comment for a symbol."""
        # Look for comments or documentation
        # This is a simplified implementation
        return None
