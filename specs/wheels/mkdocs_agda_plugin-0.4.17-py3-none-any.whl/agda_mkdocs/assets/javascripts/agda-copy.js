// Add copy buttons to Agda code blocks
document.addEventListener("DOMContentLoaded", function() {
  // Find all pre.Agda elements
  const agdaBlocks = document.querySelectorAll('pre.Agda');

  agdaBlocks.forEach(function(block) {
    // Skip if button already exists
    if (block.querySelector('.agda-copy-button')) {
      return;
    }

    // Create button element
    const button = document.createElement('button');
    button.className = 'agda-copy-button';
    button.title = 'Copy to clipboard';
    button.setAttribute('aria-label', 'Copy to clipboard');

    // Add icon (using Material icons)
    button.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M19 21H8V7h11m0-2H8a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h11a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2m-3-4H4a2 2 0 0 0-2 2v14h2V3h12V1z"></path></svg>';

    // Styling is handled by CSS - no inline styles needed

    // Copy functionality
    button.addEventListener('click', function() {
      // Extract text content from the Agda block
      const text = block.innerText;

      // Copy to clipboard
      navigator.clipboard.writeText(text).then(function() {
        // Show feedback with checkmark
        const originalHTML = button.innerHTML;
        button.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M21 7L9 19l-5.5-5.5 1.41-1.41L9 16.17 19.59 5.59 21 7z"></path></svg>';
        button.classList.add('copied');

        setTimeout(function() {
          button.innerHTML = originalHTML;
          button.classList.remove('copied');
        }, 2000);
      });
    });

    // Add button to block (position is already set in CSS)
    block.appendChild(button);
  });
});
