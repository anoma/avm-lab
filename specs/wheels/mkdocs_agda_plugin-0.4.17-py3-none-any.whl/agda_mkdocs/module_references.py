"""Module reference tracking and display for bidirectional links."""

from .symbol_extractor import SymbolDatabase


class ModuleReferencesGenerator:
    """Generate references sections for Agda modules (like LogSeq backreferences)."""

    def __init__(self, symbol_database: SymbolDatabase, url_map: dict[str, str]):
        """Initialize the references generator.

        Args:
            symbol_database: The symbol database with all references
            url_map: Mapping of module names to their URLs
        """
        self.symbol_database = symbol_database
        self.url_map = url_map

    def generate_references_section(
        self,
        module_name: str,
        show_backreferences: bool = True,
        show_forward_references: bool = True,
    ) -> str:
        """Generate a complete references section for a module.

        Args:
            module_name: Name of the module to generate references for
            show_backreferences: Whether to show modules that reference this module
            show_forward_references: Whether to show modules this module references

        Returns:
            Markdown content for the references section
        """
        lines = []

        if show_backreferences:
            backrefs = self._generate_backreferences_section(module_name)
            if backrefs:
                lines.extend(backrefs)

        if show_forward_references:
            forward_refs = self._generate_forward_references_section(module_name)
            if forward_refs:
                if lines:  # Add spacing if we already have backreferences
                    lines.append("")
                lines.extend(forward_refs)

        if not lines:
            return ""

        # Wrap in a collapsible details section
        result = [
            "",
            "---",
            "",
            '<details markdown="1" class="module-references">',
            "<summary>Module References</summary>",
            "",
        ]
        result.extend(lines)
        result.append("")
        result.append("</details>")
        result.append("")

        return "\n".join(result)

    def _generate_backreferences_section(self, module_name: str) -> list[str]:
        """Generate the backreferences section (modules that cite this module).

        Args:
            module_name: Name of the module

        Returns:
            List of markdown lines for backreferences
        """
        backrefs = self.symbol_database.get_module_references_to(module_name)

        if not backrefs:
            return []

        # Collect all modules that have symbols to display
        module_entries = []

        for from_module in sorted(backrefs.keys()):
            refs = backrefs[from_module]
            module_url = self.url_map.get(from_module, "")

            # Convert URL to .lagda.md format
            if module_url:
                if module_url.endswith(".html"):
                    module_url = module_url.replace(".html", ".lagda.md")
                elif not module_url.endswith(".lagda.md"):
                    module_url = module_url.rstrip("/") + ".lagda.md"

            # Get unique symbols with their URLs
            symbol_refs = {}
            for ref in refs:
                if ref.to_symbol not in symbol_refs:
                    symbol_refs[ref.to_symbol] = ref

            # Get symbol objects to create proper links
            symbol_links = []
            if symbol_refs:
                for symbol_name in sorted(symbol_refs.keys()):
                    if symbol_name in self.symbol_database.symbols:
                        symbol = self.symbol_database.symbols[symbol_name]
                        # Create clickable link to the symbol
                        symbol_links.append(f"[{symbol_name}]({symbol.url})")
                    # Skip symbols not in database (external modules)

            # Only show module if we have actual symbols to display
            if symbol_links:
                entry = []
                # Module name (not clickable as per the image)
                entry.append(f"- **{from_module}**")
                # Join with commas
                symbols_str = ", ".join(symbol_links)
                entry.append(f"  - Symbols: {symbols_str}")
                module_entries.append("\n".join(entry))

        # Only generate section if we have modules with symbols
        if not module_entries:
            return []

        lines = [
            "**Referenced By**",
            "",
            "This module is referenced by:",
            "",
        ]
        for entry in module_entries:
            lines.extend(entry.split("\n"))
        lines.append("")
        return lines

    def _generate_forward_references_section(self, module_name: str) -> list[str]:
        """Generate the forward references section (modules this module cites).

        Args:
            module_name: Name of the module

        Returns:
            List of markdown lines for forward references
        """
        forward_refs = self.symbol_database.get_module_references_from(module_name)

        if not forward_refs:
            return []

        # Collect all modules that have symbols to display
        module_entries = []

        for to_module in sorted(forward_refs.keys()):
            refs = forward_refs[to_module]
            module_url = self.url_map.get(to_module, "")

            # Convert URL to .lagda.md format
            if module_url:
                if module_url.endswith(".html"):
                    module_url = module_url.replace(".html", ".lagda.md")
                elif not module_url.endswith(".lagda.md"):
                    module_url = module_url.rstrip("/") + ".lagda.md"

            # Get unique symbols with their URLs
            symbol_refs = {}
            for ref in refs:
                if ref.to_symbol not in symbol_refs:
                    symbol_refs[ref.to_symbol] = ref

            # Get symbol objects to create proper links
            symbol_links = []
            if symbol_refs:
                for symbol_name in sorted(symbol_refs.keys()):
                    if symbol_name in self.symbol_database.symbols:
                        symbol = self.symbol_database.symbols[symbol_name]
                        # Create clickable link to the symbol
                        symbol_links.append(f"[{symbol_name}]({symbol.url})")
                    # Skip symbols not in database (external modules like Agda.Primitive)

            # Only show module if we have actual symbols to display
            if symbol_links:
                entry = []
                # Module name (not clickable as per the image)
                entry.append(f"- **{to_module}**")
                # Join with commas
                symbols_str = ", ".join(symbol_links)
                entry.append(f"  - Imports: {symbols_str}")
                module_entries.append("\n".join(entry))

        # Only generate section if we have modules with symbols
        if not module_entries:
            return []

        lines = [
            "**References**",
            "",
            "This module references:",
            "",
        ]
        for entry in module_entries:
            lines.extend(entry.split("\n"))
        lines.append("")
        return lines
