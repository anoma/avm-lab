"""Simple caching system for processed Agda files."""

import hashlib
import json
import shutil
from pathlib import Path

from .utils import log


class CacheManager:
    """Manage cached Agda processing results."""

    def __init__(self, cache_dir: Path):
        """Initialize the cache manager.

        Args:
            cache_dir: Directory to store cache files
        """
        self.cache_dir = cache_dir
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.index_file = self.cache_dir / "index.json"
        self.index = self._load_index()

    def _load_index(self) -> dict:
        """Load the cache index from disk."""
        if self.index_file.exists():
            try:
                return json.loads(self.index_file.read_text())
            except Exception as e:
                log.warning(f"Failed to load cache index: {e}")
        return {}

    def _save_index(self) -> None:
        """Save the cache index to disk."""
        try:
            self.index_file.write_text(json.dumps(self.index, indent=2))
        except Exception as e:
            log.error(f"Failed to save cache index: {e}")

    def _content_hash(self, content: str) -> str:
        """Calculate hash of content."""
        return hashlib.sha256(content.encode()).hexdigest()

    def _cache_path(self, file_path: Path) -> Path:
        """Get the cache file path for a source file."""
        # Convert .lagda.md -> .md for cached files (like juvix does .juvix.md -> .md)
        if file_path.name.endswith(".lagda.md"):
            cache_name = file_path.name[:-9] + ".md"  # Remove .lagda.md, add .md
        elif file_path.name.endswith(".lagda"):
            cache_name = file_path.name[:-6] + ".md"  # Remove .lagda, add .md
        else:
            cache_name = file_path.name

        # Maintain directory structure in cache
        try:
            # If file_path is absolute, make it relative to docs dir for cache structure
            if file_path.is_absolute():
                # This is a simplified approach - in production you'd want to handle this better
                cache_file = self.cache_dir / cache_name
            else:
                cache_file = self.cache_dir / file_path.parent / cache_name
        except Exception:
            # Fallback to simple name-based caching
            cache_file = self.cache_dir / cache_name

        # Ensure parent directory exists
        cache_file.parent.mkdir(parents=True, exist_ok=True)
        return cache_file

    def is_cached(self, file_path: Path, content: str) -> bool:
        """Check if a file is cached and up-to-date.

        Args:
            file_path: Path to the source file
            content: Current content of the file

        Returns:
            True if cached and up-to-date
        """
        cache_key = str(file_path)

        if cache_key not in self.index:
            return False

        cached_info = self.index[cache_key]
        current_hash = self._content_hash(content)

        if cached_info.get("hash") != current_hash:
            # Hash mismatch, invalidate this cache entry
            del self.index[cache_key]
            self._save_index()
            return False

        cache_file = Path(cached_info["cache_file"])
        if not cache_file.exists():
            # Cache file missing, invalidate this cache entry
            del self.index[cache_key]
            self._save_index()
            return False

        return True

    def get_cached(self, file_path: Path) -> str | None:
        """Get cached content for a file.

        Args:
            file_path: Path to the source file

        Returns:
            Cached content or None if not found
        """
        cache_key = str(file_path)

        if cache_key not in self.index:
            return None

        cache_file = Path(self.index[cache_key]["cache_file"])

        if cache_file.exists():
            try:
                return cache_file.read_text()
            except Exception as e:
                log.error(f"Failed to read cache file {cache_file}: {e}")

        return None

    def cache_content(
        self,
        file_path: Path,
        original_content: str,
        processed_content: str,
    ) -> None:
        """Cache processed content.

        Args:
            file_path: Path to the source file
            original_content: Original file content
            processed_content: Processed content to cache
        """
        cache_key = str(file_path)
        cache_file = self._cache_path(file_path)

        try:
            # Write cached content
            cache_file.write_text(processed_content)

            # Update index
            self.index[cache_key] = {
                "hash": self._content_hash(original_content),
                "cache_file": str(cache_file),
            }

            self._save_index()
            log.debug(f"Cached content for {file_path}")

        except Exception as e:
            log.error(f"Failed to cache content for {file_path}: {e}")

    def clear(self) -> None:
        """Clear all cached files."""
        if self.cache_dir.exists():
            shutil.rmtree(self.cache_dir)
            self.cache_dir.mkdir(parents=True, exist_ok=True)
            self.index = {}
            self._save_index()
            log.info("Cache cleared")

    def cleanup(self) -> None:
        """Clean up stale cache entries."""
        stale_entries = []

        for cache_key, info in self.index.items():
            cache_file = Path(info["cache_file"])
            source_file = Path(cache_key)

            # Remove entries where cache file is missing or source file doesn't exist
            if not cache_file.exists() or not source_file.exists():
                stale_entries.append(cache_key)

        for entry in stale_entries:
            del self.index[entry]

        if stale_entries:
            self._save_index()
            log.info(f"Removed {len(stale_entries)} stale cache entries")
