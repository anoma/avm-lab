"""Utility functions for the Agda MkDocs plugin."""

import logging
import re
from pathlib import Path

# Set up logging
logging.basicConfig(level=logging.INFO)
log = logging.getLogger("mkdocs.plugins.agda")


def is_agda_file(file_path: str) -> bool:
    """Check if a file is an Agda literate markdown file.

    Args:
        file_path: Path to check

    Returns:
        True if the file is an Agda literate file
    """
    path = Path(file_path)
    # Check for all supported Agda file extensions
    # .lagda.md, .lagda.tex, .lagda, .agda
    return (
        path.suffix in [".lagda", ".agda"]
        or path.name.endswith(".lagda.md")
        or path.name.endswith(".lagda.tex")
    )


def get_module_name_from_file_path(file_path: str) -> str:
    """Convert an Agda file path to its module name.

    Strips all Agda file extensions (.lagda.md, .lagda.tex, .lagda, .agda)
    and converts path separators to dots.

    Args:
        file_path: Path to Agda file (e.g., "foundations/booleans.lagda.md")

    Returns:
        Module name (e.g., "foundations.booleans")

    Examples:
        >>> get_module_name_from_file_path("simple-test.lagda.md")
        'simple-test'
        >>> get_module_name_from_file_path("foundations/booleans.lagda.md")
        'foundations.booleans'
        >>> get_module_name_from_file_path("foo/bar.lagda.tex")
        'foo.bar'
        >>> get_module_name_from_file_path("baz.lagda")
        'baz'
        >>> get_module_name_from_file_path("qux.agda")
        'qux'
    """
    path_str = str(file_path)

    # Strip all known Agda file extensions (order matters - check compound extensions first)
    if path_str.endswith(".lagda.md"):
        path_str = path_str[: -len(".lagda.md")]
    elif path_str.endswith(".lagda.tex"):
        path_str = path_str[: -len(".lagda.tex")]
    elif path_str.endswith(".lagda"):
        path_str = path_str[: -len(".lagda")]
    elif path_str.endswith(".agda"):
        path_str = path_str[: -len(".agda")]

    # Convert path separators to dots for module name
    return path_str.replace("/", ".")


def extract_agda_blocks(content: str) -> list[tuple[int, int, str]]:
    """Extract Agda code blocks from markdown content.

    Args:
        content: Markdown content

    Returns:
        List of tuples (start_pos, end_pos, code_content)
    """
    blocks = []
    pattern = r"```agda\n(.*?)\n```"

    for match in re.finditer(pattern, content, re.DOTALL):
        start = match.start()
        end = match.end()
        code = match.group(1)
        blocks.append((start, end, code))

    return blocks
