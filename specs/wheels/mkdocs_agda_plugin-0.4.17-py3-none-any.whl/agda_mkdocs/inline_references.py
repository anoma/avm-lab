"""Inline reference processing for Agda@name syntax."""

import re

from .symbol_extractor import Symbol, SymbolDatabase
from .utils import log


class InlineReferenceProcessor:
    """Process inline references in markdown content using Agda@name syntax."""

    def __init__(
        self,
        symbol_database: SymbolDatabase,
        current_module: str = "",
        verbose: bool = False,
        url_resolver=None,
        current_page=None,
    ):
        """Initialize the inline reference processor.

        Args:
            symbol_database: Database of all available symbols
            current_module: Name of the current module being processed
            verbose: Enable verbose logging
            url_resolver: Optional URL resolver for generating correct links
            current_page: Optional current page for context
        """
        self.symbol_database = symbol_database
        self.current_module = current_module
        self.verbose = verbose
        self.url_resolver = url_resolver
        self.current_page = current_page

        # Pattern to match Agda@name syntax
        # Supports Unicode characters common in Agda: ≡, ≤, ≥, →, ∀, ∃, λ, ⊎, ×, etc.
        # Matches: Agda@Bool, Agda@foundations.booleans, Agda@_≡_, Agda@_→_, Agda@∀, etc.
        # Allows underscores at start/end for operators: _≡_, _+_, etc.
        # Allows periods for qualified names: foundations.booleans.Bool
        # Allows hyphens in names
        # Skips matches inside backticks (inline code)
        # Non-greedy match to avoid consuming too much
        # Periods are NOT allowed at the end (but allowed in the middle for qualified names like Module.Symbol)
        # Special handling for operators with symbols like +, -, *, /, =, <, >, etc.
        self.inline_ref_pattern = re.compile(
            r"(?<!`)Agda@([_a-zA-Z\u00A0-\uFFFF](?:[\w\-_\|\&\+\*\/\=\<\>\[\]\u00A0-\uFFFF]|\.(?![\s,.:;!?)]|$))*)",
            re.UNICODE,
        )

        # Track used references for the references section
        self.used_references: set[str] = set()
        # Track disambiguation choices for reporting
        self.disambiguation_log: list[tuple[str, list[str], str]] = []

    def process_content(self, content: str) -> str:
        """Process markdown content to replace Agda@name with links.

        Args:
            content: Original markdown content

        Returns:
            Content with Agda@name references replaced by links
        """

        def replace_reference(match) -> str:
            reference_name = match.group(1)
            # Calculate line and column for this match
            match_start = match.start()
            line_num = content[:match_start].count("\n") + 1
            col_num = match_start - content[:match_start].rfind("\n")
            return self._resolve_reference(reference_name, line_num, col_num)

        # Replace all Agda@name patterns
        processed_content = self.inline_ref_pattern.sub(replace_reference, content)

        return processed_content

    def _resolve_reference(
        self, reference_name: str, line_num: int = 0, col_num: int = 0
    ) -> str:
        """Resolve a reference name to a markdown link with improved disambiguation.

        Args:
            reference_name: The name after Agda@ (e.g., "Bool", "foundations.booleans")
            line_num: Line number where the reference appears (1-indexed)
            col_num: Column number where the reference appears (1-indexed)

        Returns:
            Markdown link or fallback text
        """
        # First try exact match in symbols
        if reference_name in self.symbol_database.symbols:
            symbol = self.symbol_database.symbols[reference_name]
            self.used_references.add(symbol.module)
            return self._create_symbol_link(symbol)

        # Try qualified name resolution (e.g., "Module.Symbol")
        if "." in reference_name:
            qualified_matches = self._resolve_qualified_name(reference_name)
            if qualified_matches:
                return qualified_matches

        # Try to find by module name
        module_symbols = self.symbol_database.get_by_module(reference_name)
        if module_symbols:
            # Use the first symbol from that module to get the URL
            symbol = module_symbols[0]
            self.used_references.add(symbol.module)
            return self._create_module_link(reference_name, symbol.url.split("#")[0])

        # Try smart partial matching with prioritization
        matches = self._find_symbol_matches(reference_name)

        if len(matches) == 1:
            symbol = matches[0]
            self.used_references.add(symbol.module)
            return self._create_symbol_link(symbol)
        elif len(matches) > 1:
            # Multiple matches - use smart disambiguation
            best_match = self._disambiguate_matches(reference_name, matches)
            if best_match:
                self.used_references.add(best_match.module)
                return self._create_symbol_link(best_match)

        # No matches found - return as is with a warning class
        if self.verbose:
            if self.current_page:
                # VSCode-compatible format: file:line:column
                file_location = (
                    f"{self.current_page.file.src_path}:{line_num}:{col_num}"
                )
                log.warning(
                    f"Could not resolve Agda reference '{reference_name}' at {file_location}"
                )
            else:
                log.warning(f"Could not resolve Agda reference: {reference_name}")
        return f'<span class="agda-ref-unresolved" title="Unresolved reference: {reference_name}">{reference_name}</span>'

    def _create_symbol_link(self, symbol: Symbol) -> str:
        """Create a markdown link for a symbol.

        Args:
            symbol: The symbol to link to

        Returns:
            Markdown link with appropriate styling
        """
        # Use URL resolver if available for correct relative URLs
        if self.url_resolver and self.current_page:
            # Extract module name and anchor from symbol URL
            if "#" in symbol.url:
                module_html, anchor = symbol.url.split("#", 1)
            else:
                module_html = symbol.url
                anchor = symbol.anchor_id or ""

            # Get module name from HTML filename
            module_name = module_html.replace(".html", "").replace("/", ".")

            # Use resolver to get correct URL
            url = self.url_resolver.resolve_inline_reference(
                module_name, anchor, self.current_page
            )
        else:
            # Fallback to original logic
            if symbol.module == self.current_module:
                url = f"#{symbol.anchor_id}" if symbol.anchor_id else ""
            else:
                url = symbol.url

        # Add CSS class for styling
        symbol_type_class = symbol.symbol_type.value.lower().replace(" ", "-")
        # Escape square brackets and underscores in symbol name to prevent markdown interpretation
        escaped_name = (
            symbol.name.replace("_", "\\_").replace("[", "\\[").replace("]", "\\]")
        )
        return f"[{escaped_name}]({url}){{.agda-ref .agda-{symbol_type_class}}}"

    def _create_module_link(self, module_name: str, module_url: str) -> str:
        """Create a markdown link for a module.

        Args:
            module_name: Name of the module
            module_url: URL to the module

        Returns:
            Markdown link with module styling
        """
        # Use the URL as-is - should already be in correct format (.html)
        url = module_url

        return f"[{module_name}]({url}){{.agda-ref .agda-module}}"

    def generate_references_section(self) -> str:
        """Generate a collapsible references section for modules used in this page.

        Returns:
            Markdown content for the references section
        """
        if not self.used_references:
            return ""

        # Filter out the current module
        external_modules = {
            mod for mod in self.used_references if mod != self.current_module
        }

        if not external_modules:
            return ""

        lines = [
            "",
            "---",
            "",
            '<details markdown="1">',
            "<summary>References to other modules</summary>",
            "",
            "This page references the following modules:",
            "",
        ]

        # Group symbols by module for better organization
        for module_name in sorted(external_modules):
            module_symbols = self.symbol_database.get_by_module(module_name)
            if module_symbols:
                # Get module URL from first symbol
                module_url = module_symbols[0].url.split("#")[0]
                # module_url is already relative, no need for ../ prefix

                lines.append(f"- **[{module_name}]({module_url})**")

                # List symbols from this module that were referenced
                referenced_symbols = []
                for symbol_name, symbol in self.symbol_database.symbols.items():
                    if symbol.module == module_name:
                        # Check if this symbol was likely referenced (this is approximate)
                        referenced_symbols.append(symbol)

                # Show ALL symbols (exhaustive, no truncation)
                if referenced_symbols:
                    symbol_links = []
                    for symbol in referenced_symbols:
                        symbol_url = symbol.url
                        # symbol_url is already relative, no need for ../ prefix
                        symbol_links.append(f"[{symbol.name}]({symbol_url})")

                    lines.append(f"  - Symbols: {', '.join(symbol_links)}")

        lines.extend(["", "</details>", ""])

        # Add disambiguation report if in verbose mode
        if self.verbose and self.disambiguation_log:
            lines.extend(
                [
                    "",
                    "---",
                    "",
                    '<details markdown="1">',
                    "<summary>Symbol disambiguation log</summary>",
                    "",
                    "The following references had multiple matches and were disambiguated:",
                    "",
                ]
            )
            for ref_name, candidates, chosen in self.disambiguation_log:
                lines.append(f"- `{ref_name}`: chose `{chosen}` from {candidates[:3]}")
            lines.extend(["", "</details>", ""])

        return "\n".join(lines)

    def _resolve_qualified_name(self, qualified_name: str) -> str | None:
        """Resolve qualified names like 'Module.Symbol' or 'foundations.booleans.Bool'.

        Args:
            qualified_name: Qualified symbol name

        Returns:
            Markdown link or None if not found
        """
        parts = qualified_name.split(".")

        # Try as module.symbol
        if len(parts) >= 2:
            potential_module = ".".join(parts[:-1])
            potential_symbol = parts[-1]

            # Look for symbol in that specific module
            for symbol_name, symbol in self.symbol_database.symbols.items():
                if symbol.module == potential_module and (
                    symbol_name == potential_symbol
                    or symbol_name.endswith(potential_symbol)
                ):
                    self.used_references.add(symbol.module)
                    return self._create_symbol_link(symbol)

        return None

    def _find_symbol_matches(self, reference_name: str) -> list[Symbol]:
        """Find symbol matches with improved scoring.

        Args:
            reference_name: Symbol name to match

        Returns:
            List of matching symbols, ordered by relevance
        """
        matches = []

        for symbol_name, symbol in self.symbol_database.symbols.items():
            score = self._calculate_match_score(reference_name, symbol_name, symbol)
            if score > 0:
                matches.append((score, symbol))

        # Sort by score (descending) and return symbols only
        matches.sort(key=lambda x: x[0], reverse=True)
        return [symbol for _, symbol in matches]

    def _calculate_match_score(
        self, reference: str, symbol_name: str, symbol: Symbol
    ) -> int:
        """Calculate how well a symbol matches the reference.

        Args:
            reference: Reference name being resolved
            symbol_name: Full symbol name
            symbol: Symbol object

        Returns:
            Score (higher is better, 0 means no match)
        """
        score = 0

        # Exact match gets highest score
        if symbol_name == reference:
            score += 100

        # For operators, try matching without underscores
        # e.g., "≡" should match "_≡_", "&&" should match "_&&_"
        base_ref = reference.strip("_")
        base_symbol = symbol_name.strip("_")

        if base_symbol == base_ref and base_ref:
            score += 95  # Very high score for operator matches

        # Exact suffix match (e.g., "_≡_" matches "≡")
        elif symbol_name.endswith(reference) and len(reference) >= 1:
            score += 80

        # Exact prefix match
        elif symbol_name.startswith(reference) and len(reference) >= 2:
            score += 75

        # Symbol name contains reference
        elif reference in symbol_name and len(reference) >= 2:
            score += 60

        # Check if it's an operator pattern match
        # e.g., "+" matches "_+_", "&&" matches "_&&_"
        elif f"_{base_ref}_" == symbol_name or f"_{reference}_" == symbol_name:
            score += 85

        # Check if reference matches the base name (without underscores)
        elif base_symbol.endswith(base_ref) and len(base_ref) >= 1:
            score += 70

        # Don't match if the reference is significantly longer than the symbol
        # This prevents "NonExistentSymbol" from matching "Bool"
        if len(reference) > len(symbol_name) * 2:
            score = 0

        # Additional filtering: require some meaningful similarity
        if score > 0 and score < 60:
            # For partial matches, require at least 40% character overlap (lowered threshold)
            common_chars = set(reference.lower()) & set(symbol_name.lower())
            if len(common_chars) < min(len(reference), len(symbol_name)) * 0.4:
                score = 0

        # Bonus for symbols in current module
        if score > 0 and symbol.module == self.current_module:
            score += 20

        # Bonus for common symbol types
        if score > 0 and symbol.symbol_type.value in [
            "Datatype",
            "Function",
            "Function Operator",
        ]:
            score += 10

        return score

    def _disambiguate_matches(
        self, reference_name: str, matches: list[Symbol]
    ) -> Symbol | None:
        """Choose the best symbol from multiple matches.

        Args:
            reference_name: Original reference name
            matches: List of potential symbol matches

        Returns:
            Best matching symbol or None
        """
        if not matches:
            return None

        # Prefer symbols from current module
        current_module_matches = [s for s in matches if s.module == self.current_module]
        if current_module_matches:
            chosen = current_module_matches[0]
        else:
            chosen = matches[0]

        # Log disambiguation for debugging
        candidate_names = [f"{s.module}.{s.name}" for s in matches[:5]]
        chosen_name = f"{chosen.module}.{chosen.name}"
        self.disambiguation_log.append((reference_name, candidate_names, chosen_name))

        if self.verbose:
            log.debug(
                f"Disambiguated '{reference_name}': chose '{chosen_name}' from {candidate_names[:3]}"
            )

        return chosen
