"""Centralized URL resolution for agda-mkdocs plugin.

This module provides a unified approach to URL handling that works consistently
for both local development and GitHub Pages deployments (including subdirectory deployments).
"""

import logging
from pathlib import Path
from urllib.parse import urlparse

from mkdocs.config import Config as MkDocsConfig
from mkdocs.structure.files import Files
from mkdocs.structure.pages import Page

from .utils import get_module_name_from_file_path, is_agda_file

log = logging.getLogger(__name__)


class URLResolver:
    """Centralized URL resolution for all link types in agda-mkdocs."""

    def __init__(self, config: MkDocsConfig):
        """Initialize the URL resolver with MkDocs configuration.

        Args:
            config: MkDocs configuration object
        """
        self.config = config
        self.site_url = config.get("site_url", "")
        self.use_directory_urls = config.get("use_directory_urls", True)

        # Parse site URL to detect subdirectory deployments
        self.base_path = ""
        if self.site_url:
            parsed = urlparse(self.site_url)
            path_parts = [p for p in parsed.path.split("/") if p]
            if path_parts:
                # GitHub Pages subdirectory deployment detected
                self.base_path = "/" + "/".join(path_parts) + "/"
                log.debug(
                    f"Detected subdirectory deployment with base path: {self.base_path}"
                )

        # Build file mappings
        self.url_map: dict[str, str] = {}
        self.module_to_url: dict[str, str] = {}

    def build_url_mappings(self, files: Files) -> None:
        """Build mappings from Agda modules and file paths to URLs.

        Args:
            files: MkDocs Files collection
        """
        self.url_map.clear()
        self.module_to_url.clear()

        for file in files:
            src_path = file.src_path

            # Handle Agda files specially (all types: .lagda.md, .lagda.tex, .lagda, .agda)
            if is_agda_file(src_path):
                # Extract module name (handles all Agda file extensions)
                module_name = get_module_name_from_file_path(src_path)

                # Get the URL (MkDocs will have already stripped .lagda from file.url)
                url = file.url

                # Store various mappings for flexible lookup
                self.module_to_url[module_name] = url
                self.url_map[f"{module_name}.html"] = url
                self.url_map[module_name] = url

                # Also map the source path for markdown link resolution
                self.url_map[src_path] = url
                # Map the .md version for all Agda file types
                md_path = get_module_name_from_file_path(src_path) + ".md"
                self.url_map[md_path] = url

                log.debug(f"Mapped module {module_name} -> {url}")

            # Handle regular .md files
            elif src_path.endswith(".md"):
                base_name = src_path[:-3]  # Remove .md
                url = file.url

                self.url_map[src_path] = url
                self.url_map[base_name] = url
                self.url_map[f"{base_name}/"] = url

    def resolve_agda_html_link(self, href: str, current_page: Page) -> str:
        """Resolve an Agda-generated HTML link (e.g., "module.html#123").

        Args:
            href: The original href from Agda HTML
            current_page: The current MkDocs page being processed

        Returns:
            Resolved URL appropriate for the deployment context
        """
        # Handle external URLs
        if (
            href.startswith("http://")
            or href.startswith("https://")
            or href.startswith("//")
        ):
            return href

        # Handle anchor-only links
        if href.startswith("#"):
            return href

        # Split href into base and fragment
        if "#" in href:
            base_href, fragment = href.split("#", 1)
            anchor = f"#{fragment}"
        else:
            base_href = href
            anchor = ""

        # Normalize the href for lookup (e.g., "foundations/booleans.html" -> "foundations.booleans.html")
        normalized_href = base_href.replace("/", ".")

        # Check if this is a self-reference
        current_module = self._get_module_name(current_page.file.src_path)
        target_module = base_href.replace(".html", "").replace("/", ".")

        if current_module and target_module == current_module:
            # Self-reference - use anchor only
            return anchor if anchor else "#"

        # Try to find the target in our mappings
        target_url = None
        if base_href in self.url_map:
            target_url = self.url_map[base_href]
        elif normalized_href in self.url_map:
            target_url = self.url_map[normalized_href]
        elif target_module in self.module_to_url:
            target_url = self.module_to_url[target_module]
        else:
            # External module (e.g., Agda stdlib) - these are copied to site root
            # Use relative path from current page
            target_url = base_href

        # Convert to relative URL
        relative_url = self._make_relative_url(current_page, target_url)
        return relative_url + anchor

    def resolve_markdown_link(
        self, link_url: str, current_page: Page, files: Files
    ) -> str:
        """Resolve a markdown link (e.g., "[text](../module.lagda.md#anchor)").

        Args:
            link_url: The original URL from markdown
            current_page: The current MkDocs page being processed
            files: MkDocs Files collection

        Returns:
            Resolved URL appropriate for the deployment context
        """
        # Skip external links
        if "://" in link_url or link_url.startswith("mailto:"):
            return link_url

        # Skip anchor-only links
        if link_url.startswith("#"):
            return link_url

        # Keep .lagda.md references as-is (MkDocs will handle them)
        if ".lagda.md" in link_url:
            return link_url

        # Resolve relative path to absolute src_path
        current_dir = Path(current_page.file.src_path).parent

        # Handle relative paths
        if link_url.startswith("../"):
            parts = link_url.split("/")
            up_levels = sum(1 for p in parts if p == "..")
            remaining = [p for p in parts if p != ".." and p]

            current_parts = (
                list(current_dir.parts) if current_dir.parts != (".",) else []
            )
            if len(current_parts) >= up_levels:
                base_parts = (
                    current_parts[:-up_levels] if up_levels > 0 else current_parts
                )
                target_src = "/".join(base_parts + remaining)
            else:
                return link_url  # Can't resolve
        else:
            if current_dir.parts != (".",):
                target_src = str(current_dir / link_url)
            else:
                target_src = link_url

        # Normalize path
        target_src = target_src.replace("\\", "/")

        # Handle anchors
        anchor = ""
        if "#" in target_src:
            target_src, anchor = target_src.split("#", 1)
            anchor = f"#{anchor}"

        # Try to find target in mappings
        for variation in [
            target_src,
            f"{target_src}.md",
            target_src.rstrip("/"),
            f"{target_src}/",
        ]:
            if variation in self.url_map:
                target_url = self.url_map[variation]
                relative_url = self._make_relative_url(current_page, target_url)
                return relative_url + anchor

        # Not found, return original
        return link_url

    def resolve_inline_reference(
        self, module_name: str, anchor: str, current_page: Page
    ) -> str:
        """Resolve an inline reference (Agda@name) to a URL.

        For inline references, we use absolute URLs (relative to site root) to avoid
        broken links in nested pages. This works correctly with both local development
        and GitHub Pages subdirectory deployments.

        Args:
            module_name: The module containing the symbol
            anchor: The anchor/fragment for the symbol
            current_page: The current MkDocs page being processed

        Returns:
            Resolved URL with anchor (absolute URL relative to site root)
        """
        # Check if referencing current module
        current_module = self._get_module_name(current_page.file.src_path)
        if current_module and module_name == current_module:
            return f"#{anchor}"

        # Find target URL
        if module_name in self.module_to_url:
            target_url = self.module_to_url[module_name]
        else:
            # External module - generate URL to copied HTML
            target_url = f"{module_name.replace('.', '/')}.html"

        # For inline references, use absolute URLs (relative to site root)
        # This prevents broken links in nested pages
        absolute_url = self._make_absolute_site_url(target_url)
        return f"{absolute_url}#{anchor}"

    def get_absolute_url(self, page: Page) -> str:
        """Get the absolute URL for a page (for canonical URLs, sitemaps, etc.).

        Args:
            page: The MkDocs page

        Returns:
            Absolute URL including site_url
        """
        if self.site_url:
            # Remove trailing slash from site_url if present
            base = self.site_url.rstrip("/")
            # Add page URL (which already has leading slash)
            return base + "/" + page.url.lstrip("/")
        else:
            # No site_url configured, return relative URL
            return page.url

    def _get_module_name(self, src_path: str) -> str | None:
        """Extract Agda module name from source path.

        Args:
            src_path: Source file path

        Returns:
            Module name or None
        """
        if not src_path:
            return None

        if is_agda_file(src_path):
            return get_module_name_from_file_path(src_path)
        elif src_path.endswith(".md"):
            # Check if this was originally a .lagda.md file
            potential_module = src_path.replace(".md", "").replace("/", ".")
            if potential_module in self.module_to_url:
                return potential_module

        return None

    def _make_absolute_site_url(self, target_url: str) -> str:
        """Convert a target URL to an absolute URL relative to site root.

        For subdirectory deployments (e.g., GitHub Pages at /repo-name/),
        this prepends the base path. For root deployments, it just ensures
        the URL starts with '/'.

        Args:
            target_url: Target URL (e.g., "foundations/booleans.html")

        Returns:
            Absolute URL relative to site root (e.g., "/agda-mkdocs/foundations/booleans.html")
        """
        # Handle already absolute URLs
        if (
            target_url.startswith("http://")
            or target_url.startswith("https://")
            or target_url.startswith("//")
        ):
            return target_url

        # Remove leading slash if present
        target_url = target_url.lstrip("/")

        # Add base path for subdirectory deployments
        if self.base_path:
            # base_path already has leading and trailing slashes
            return f"{self.base_path}{target_url}"
        else:
            # Root deployment - just add leading slash
            return f"/{target_url}"

    def _make_relative_url(self, current_page: Page, target_url: str) -> str:
        """Calculate relative URL from current page to target.

        This is the core function that ensures all URLs work correctly
        in both local development and GitHub Pages deployments.

        Args:
            current_page: The current page
            target_url: The target URL (can be relative or absolute)

        Returns:
            Relative URL from current page to target
        """
        # Handle absolute URLs
        if (
            target_url.startswith("http://")
            or target_url.startswith("https://")
            or target_url.startswith("//")
        ):
            return target_url

        # Get current page URL and target URL
        current_url = current_page.url

        # Handle the use_directory_urls setting
        if not self.use_directory_urls:
            # URLs are like "path/to/page.html"
            # Calculate relative path between them
            current_parts = current_url.split("/")[:-1]  # Remove filename
            target_parts = target_url.split("/")

            # Handle target that's just a filename
            if len(target_parts) == 1:
                if len(current_parts) == 0:
                    # Both in root
                    return target_url
                else:
                    # Need to go up to root and then to target
                    return "/".join([".."] * len(current_parts) + [target_url])

            # Find common prefix
            common_length = 0
            for i, (cp, tp) in enumerate(zip(current_parts, target_parts[:-1])):
                if cp == tp:
                    common_length += 1
                else:
                    break

            # Calculate relative path
            up_levels = len(current_parts) - common_length
            down_parts = target_parts[common_length:]

            if up_levels == 0 and len(down_parts) == 1:
                # Same directory
                return down_parts[0]
            else:
                parts = [".."] * up_levels + down_parts
                return "/".join(parts)
        else:
            # URLs are like "path/to/page/"
            # This case is more complex and less commonly used with agda-mkdocs
            # For now, return target_url as-is
            return target_url

    def should_process_as_agda(self, src_path: str) -> bool:
        """Check if a file should be processed as an Agda file.

        Args:
            src_path: Source file path

        Returns:
            True if file should be processed as Agda
        """
        return is_agda_file(src_path)
