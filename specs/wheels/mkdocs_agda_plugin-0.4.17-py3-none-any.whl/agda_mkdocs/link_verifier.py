"""Link verification for agda-mkdocs generated sites.

This module provides post-build link verification to catch broken links
before deployment.
"""

import logging
from pathlib import Path
from typing import NamedTuple
from urllib.parse import unquote

from bs4 import BeautifulSoup

log = logging.getLogger(__name__)


class BrokenLink(NamedTuple):
    """Information about a broken link."""

    source_file: str  # HTML file containing the link
    link_url: str  # The broken URL/anchor
    link_type: str  # Type: "internal", "anchor", "asset"
    line_context: str  # Line or context where the link appears


class LinkVerificationResult(NamedTuple):
    """Results from link verification."""

    total_links: int
    broken_links: list[BrokenLink]
    files_checked: int

    @property
    def has_errors(self) -> bool:
        """Check if there are any broken links."""
        return len(self.broken_links) > 0

    @property
    def success_rate(self) -> float:
        """Calculate percentage of working links."""
        if self.total_links == 0:
            return 100.0
        return ((self.total_links - len(self.broken_links)) / self.total_links) * 100.0


class LinkVerifier:
    """Verifies links in generated HTML files."""

    def __init__(
        self,
        site_dir: Path,
        verify_anchors: bool = True,
        verify_assets: bool = True,
        ignore_external: bool = True,
        verbose: bool = False,
    ):
        """Initialize the link verifier.

        Args:
            site_dir: Path to the generated site directory
            verify_anchors: Whether to verify fragment identifiers exist
            verify_assets: Whether to verify CSS/JS assets exist
            ignore_external: Whether to skip external URL verification
            verbose: Enable verbose logging
        """
        self.site_dir = Path(site_dir)
        self.verify_anchors = verify_anchors
        self.verify_assets = verify_assets
        self.ignore_external = ignore_external
        self.verbose = verbose

        # Track statistics
        self.total_links = 0
        self.files_checked = 0
        self.broken_links: list[BrokenLink] = []

    def verify_site(self) -> LinkVerificationResult:
        """Verify all links in the generated site.

        Returns:
            LinkVerificationResult with statistics and broken links
        """
        if not self.site_dir.exists():
            log.error(f"Site directory does not exist: {self.site_dir}")
            return LinkVerificationResult(0, [], 0)

        log.info(f"Verifying links in {self.site_dir}")

        # Find all HTML files
        html_files = list(self.site_dir.rglob("*.html"))

        if not html_files:
            log.warning(f"No HTML files found in {self.site_dir}")
            return LinkVerificationResult(0, [], 0)

        # Verify each HTML file
        for html_file in html_files:
            self._verify_html_file(html_file)

        return LinkVerificationResult(
            total_links=self.total_links,
            broken_links=self.broken_links,
            files_checked=self.files_checked,
        )

    def _verify_html_file(self, html_file: Path) -> None:
        """Verify links in a single HTML file.

        Args:
            html_file: Path to HTML file to verify
        """
        try:
            content = html_file.read_text(encoding="utf-8")
            soup = BeautifulSoup(content, "html.parser")

            # Get file path relative to site_dir for reporting
            rel_path = html_file.relative_to(self.site_dir)

            # Verify all links
            self._verify_links(soup, html_file, rel_path)

            # Verify assets if enabled
            if self.verify_assets:
                self._verify_assets_in_file(soup, html_file, rel_path)

            self.files_checked += 1

            if self.verbose:
                log.debug(f"Verified {rel_path}")

        except Exception as e:
            log.warning(f"Error verifying {html_file}: {e}")

    def _verify_links(
        self, soup: BeautifulSoup, html_file: Path, rel_path: Path
    ) -> None:
        """Verify all <a> links in the document.

        Args:
            soup: BeautifulSoup parsed HTML
            html_file: Absolute path to HTML file
            rel_path: Relative path for reporting
        """
        for a_tag in soup.find_all("a", href=True):
            href = a_tag["href"]
            self.total_links += 1

            # Skip external links if configured
            if self.ignore_external and self._is_external_url(href):
                continue

            # Skip mailto and javascript links
            if href.startswith(("mailto:", "javascript:", "tel:")):
                continue

            # Verify the link
            self._verify_link(href, html_file, rel_path, a_tag)

    def _verify_link(self, href: str, html_file: Path, rel_path: Path, a_tag) -> None:
        """Verify a single link.

        Args:
            href: The href attribute value
            html_file: Absolute path to HTML file containing the link
            rel_path: Relative path for reporting
            a_tag: BeautifulSoup tag for context
        """
        # Split into path and fragment
        if "#" in href:
            path_part, fragment = href.split("#", 1)
        else:
            path_part = href
            fragment = None

        # Handle anchor-only links (same page)
        if not path_part:
            if fragment and self.verify_anchors:
                if not self._anchor_exists(html_file, fragment):
                    self._add_broken_link(
                        rel_path,
                        href,
                        "anchor",
                        f"Missing anchor: #{fragment}",
                    )
            return

        # Resolve relative path
        target_file = self._resolve_link_path(html_file, path_part)

        if not target_file or not target_file.exists():
            # Check if this might be a .lagda.md source file link
            if path_part.endswith(".lagda.md"):
                # Source files should exist
                source_target = self._resolve_link_path(html_file, path_part)
                if not source_target or not source_target.exists():
                    self._add_broken_link(
                        rel_path,
                        href,
                        "internal",
                        f"Missing source file: {path_part}",
                    )
                return

            # Broken link
            self._add_broken_link(
                rel_path,
                href,
                "internal",
                f"Missing file: {path_part}",
            )
            return

        # Verify fragment if present
        if fragment and self.verify_anchors and target_file.suffix == ".html":
            if not self._anchor_exists(target_file, fragment):
                self._add_broken_link(
                    rel_path,
                    href,
                    "anchor",
                    f"Missing anchor #{fragment} in {target_file.name}",
                )

    def _verify_assets_in_file(
        self, soup: BeautifulSoup, html_file: Path, rel_path: Path
    ) -> None:
        """Verify CSS and JS assets in the document.

        Args:
            soup: BeautifulSoup parsed HTML
            html_file: Absolute path to HTML file
            rel_path: Relative path for reporting
        """
        # Check CSS links
        for link_tag in soup.find_all("link", rel="stylesheet", href=True):
            href = link_tag["href"]
            if self._is_external_url(href):
                continue

            target = self._resolve_link_path(html_file, href)
            if not target or not target.exists():
                self._add_broken_link(
                    rel_path,
                    href,
                    "asset",
                    f"Missing CSS: {href}",
                )

        # Check JS scripts
        for script_tag in soup.find_all("script", src=True):
            src = script_tag["src"]
            if self._is_external_url(src):
                continue

            target = self._resolve_link_path(html_file, src)
            if not target or not target.exists():
                self._add_broken_link(
                    rel_path,
                    src,
                    "asset",
                    f"Missing JS: {src}",
                )

    def _resolve_link_path(self, source_file: Path, link: str) -> Path | None:
        """Resolve a relative or absolute link to a file path.

        Args:
            source_file: The HTML file containing the link
            link: The link URL

        Returns:
            Resolved absolute path, or None if cannot be resolved
        """
        # Decode URL encoding
        link = unquote(link)

        # Remove query strings and fragments
        if "?" in link:
            link = link.split("?")[0]
        if "#" in link:
            link = link.split("#")[0]

        # Handle absolute paths (relative to site root)
        if link.startswith("/"):
            return self.site_dir / link.lstrip("/")

        # Handle relative paths
        return (source_file.parent / link).resolve()

    def _anchor_exists(self, html_file: Path, fragment: str) -> bool:
        """Check if an anchor/fragment exists in an HTML file.

        Args:
            html_file: Path to HTML file
            fragment: Fragment identifier (without #)

        Returns:
            True if anchor exists, False otherwise
        """
        try:
            content = html_file.read_text(encoding="utf-8")
            soup = BeautifulSoup(content, "html.parser")

            # Check for id attribute
            if soup.find(id=fragment):
                return True

            # Check for name attribute (legacy)
            if soup.find(attrs={"name": fragment}):
                return True

            # Agda-specific: check for data-anchor attributes
            if soup.find(attrs={"data-anchor": fragment}):
                return True

            return False

        except Exception as e:
            log.debug(f"Error checking anchor {fragment} in {html_file}: {e}")
            return True  # Assume exists on error to avoid false positives

    def _is_external_url(self, url: str) -> bool:
        """Check if a URL is external.

        Args:
            url: URL to check

        Returns:
            True if external URL, False otherwise
        """
        return url.startswith(("http://", "https://", "//"))

    def _add_broken_link(
        self, source_file: Path, link_url: str, link_type: str, context: str
    ) -> None:
        """Add a broken link to the results.

        Args:
            source_file: File containing the broken link
            link_url: The broken URL
            link_type: Type of link
            context: Context or error message
        """
        broken_link = BrokenLink(
            source_file=str(source_file),
            link_url=link_url,
            link_type=link_type,
            line_context=context,
        )
        self.broken_links.append(broken_link)

        if self.verbose:
            log.warning(
                f"Broken link in {source_file}: {link_url} ({link_type}) - {context}"
            )

    def format_report(self, result: LinkVerificationResult) -> str:
        """Format verification results as a human-readable report.

        Args:
            result: Verification results

        Returns:
            Formatted report string
        """
        lines = []
        lines.append("=" * 60)
        lines.append("Link Verification Report")
        lines.append("=" * 60)
        lines.append(f"Files checked: {result.files_checked}")
        lines.append(f"Total links: {result.total_links}")
        lines.append(f"Broken links: {len(result.broken_links)}")
        lines.append(f"Success rate: {result.success_rate:.1f}%")
        lines.append("")

        if result.broken_links:
            lines.append("Broken Links:")
            lines.append("-" * 60)

            # Group by source file
            by_file: dict[str, list[BrokenLink]] = {}
            for link in result.broken_links:
                if link.source_file not in by_file:
                    by_file[link.source_file] = []
                by_file[link.source_file].append(link)

            for source_file in sorted(by_file.keys()):
                links = by_file[source_file]
                lines.append(f"\n{source_file} ({len(links)} broken links):")
                for link in links:
                    lines.append(
                        f"  [{link.link_type}] {link.link_url} - {link.line_context}"
                    )

        lines.append("")
        lines.append("=" * 60)

        return "\n".join(lines)
