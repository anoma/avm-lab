"""Agda file processor for converting literate Agda markdown to HTML."""

import re
import subprocess
from pathlib import Path

from bs4 import BeautifulSoup

from .utils import extract_agda_blocks, get_module_name_from_file_path, log


class AgdaProcessor:
    """Process Agda literate markdown files."""

    def __init__(
        self,
        agda_dir: str = "html",
        highlight_code_only: bool = True,
        verbose: bool = False,
        custom_css: str | None = None,
        highlight_occurrences: bool = False,
        timeout: int = 30,
        force_rebuild: bool = False,
        include_paths: list[str] | None = None,
    ):
        """Initialize the processor.

        Args:
            agda_dir: Directory for Agda output
            highlight_code_only: Only highlight code blocks (not the entire file)
            verbose: Enable verbose output
            custom_css: Custom CSS file URL for HTML backend
            highlight_occurrences: Enable occurrence highlighting in HTML
            timeout: Compilation timeout in seconds
            force_rebuild: Force rebuild of all files, ignoring cache
            include_paths: List of paths to include with --include-path flags
        """
        self.agda_dir = agda_dir
        self.highlight_code_only = highlight_code_only
        self.verbose = verbose
        self.custom_css = custom_css
        self.highlight_occurrences = highlight_occurrences
        self.timeout = timeout
        self.force_rebuild = force_rebuild
        self.include_paths = include_paths or []

    def process_file(
        self,
        file_path: Path,
        markdown_content: str,
        temp_dir: Path,
        symbol_extractor=None,
        symbol_database=None,
        module_name: str = "",
        module_url: str = "",
    ) -> str:
        """Process an Agda literate markdown file.

        Args:
            file_path: Path to the source file
            markdown_content: Original markdown content
            temp_dir: Temporary directory for Agda output

        Returns:
            Processed markdown with highlighted Agda code
        """
        # Extract and preserve YAML frontmatter
        frontmatter, content_without_frontmatter = (
            AgdaProcessor._extract_yaml_frontmatter(markdown_content)
        )

        # Extract Agda code blocks
        blocks = extract_agda_blocks(content_without_frontmatter)

        if not blocks:
            # No Agda blocks found, return original content
            return markdown_content

        try:
            # Create temporary Agda file preserving directory structure
            # file_path should be relative to docs directory (e.g., "foundations/booleans.lagda.md")
            temp_agda = temp_dir / file_path

            # Only create/copy the file if it doesn't exist (preprocessing may have already copied it)
            if not temp_agda.exists():
                temp_agda.parent.mkdir(parents=True, exist_ok=True)
                # Write content without frontmatter for Agda
                temp_agda.write_text(content_without_frontmatter)

            # Run Agda to generate HTML
            output_dir = temp_dir  # Output will be in temp_dir/self.agda_dir
            html_output = self._run_agda(temp_agda, output_dir, temp_dir)

            if html_output:
                # Extract symbols from generated HTML if extractor is provided
                if symbol_extractor and symbol_database and module_name:
                    html_content = html_output.read_text()
                    extracted_db = symbol_extractor.extract_symbols(
                        html_content, module_name, module_url
                    )
                    # Merge extracted symbols into main database
                    for symbol in extracted_db.symbols.values():
                        symbol_database.add_symbol(symbol)
                    for reference in extracted_db.references:
                        symbol_database.add_reference(reference)

                # Process the generated HTML
                processed = self._process_html(
                    html_output, content_without_frontmatter, blocks
                )

                # Restore YAML frontmatter to the final output
                if frontmatter:
                    processed = frontmatter + "\n\n" + processed

                return processed
            else:
                log.warning(f"No HTML output generated for {file_path}")
                return markdown_content

        except Exception as e:
            log.error(f"Error processing {file_path}: {e}")
            raise

    @staticmethod
    def _extract_yaml_frontmatter(content: str) -> tuple[str, str]:
        """Extract YAML frontmatter from markdown content.

        YAML frontmatter is delimited by --- at the beginning and end.

        Args:
            content: Original markdown content

        Returns:
            Tuple of (frontmatter, content_without_frontmatter)
            If no frontmatter, returns ("", original_content)
        """
        lines = content.split("\n")

        # Check if content starts with YAML frontmatter delimiter
        if not lines or lines[0].strip() != "---":
            # No YAML frontmatter
            return "", content

        # Find the closing delimiter
        for i, line in enumerate(lines[1:], 1):
            if line.strip() == "---":
                # Found closing delimiter
                frontmatter = "\n".join(lines[: i + 1])
                # Skip empty lines immediately after frontmatter
                start_idx = i + 1
                while start_idx < len(lines) and lines[start_idx].strip() == "":
                    start_idx += 1
                content_without = "\n".join(lines[start_idx:])
                return frontmatter, content_without

        # No closing delimiter found, treat as regular content
        log.warning(
            "YAML frontmatter delimiter '---' found at start but no closing delimiter found"
        )
        return "", content

    @staticmethod
    def _strip_yaml_frontmatter(content: str) -> str:
        """Strip YAML frontmatter from markdown content.

        YAML frontmatter is delimited by --- at the beginning and end.
        This needs to be removed before passing content to Agda.

        Args:
            content: Original markdown content

        Returns:
            Content with YAML frontmatter removed
        """
        _, content_without = AgdaProcessor._extract_yaml_frontmatter(content)
        return content_without

    def _run_agda(
        self, agda_file: Path, output_dir: Path, temp_dir: Path
    ) -> Path | None:
        """Run Agda compiler to generate output.

        Args:
            agda_file: Path to the Agda file
            output_dir: Directory for output
            temp_dir: Temporary directory containing source files

        Returns:
            Path to generated file or None if failed
        """
        cmd = ["agda"]

        # Add HTML backend options (LaTeX backend removed)
        cmd.append("--html")
        # HTML directory needs to be relative to the working directory (temp_dir)
        html_dir = output_dir / self.agda_dir
        relative_html_dir = html_dir.relative_to(temp_dir)
        cmd.append(f"--html-dir={relative_html_dir}")

        if self.highlight_code_only:
            cmd.append("--html-highlight=code")
        else:
            cmd.append("--html-highlight=all")

        if self.highlight_occurrences:
            cmd.append("--highlight-occurrences")

        if self.custom_css:
            cmd.append(f"--css={self.custom_css}")

        # Add include paths if specified
        for include_path in self.include_paths:
            cmd.append(f"--include-path={include_path}")

        # Set working directory to where the source files are located
        # This allows Agda to find files with proper module paths
        # The source files should be in temp_dir, and we need to run from there
        working_dir = temp_dir

        # Use relative path from the source directory (temp_dir)
        relative_path = agda_file.relative_to(temp_dir)
        cmd.append(str(relative_path))

        try:
            if self.verbose:
                log.info(f"Running Agda command: {' '.join(cmd)}")
                log.info(f"Working directory: {working_dir}")

            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=self.timeout,
                cwd=working_dir,
            )

            if self.verbose:
                log.info(f"Agda stdout: {result.stdout}")
                log.info(f"Agda stderr: {result.stderr}")

            if result.returncode != 0:
                log.error(f"Agda compilation failed: {result.stderr}")
                # Include both stdout and stderr in the error for better diagnostics
                full_output = ""
                if result.stdout:
                    full_output += f"Stdout:\n{result.stdout}\n\n"
                if result.stderr:
                    full_output += f"Stderr:\n{result.stderr}"
                raise RuntimeError(f"Agda compilation failed:\n{full_output}")

            # Find the generated file
            output_backend_dir = output_dir / self.agda_dir

            # Determine expected file extension based on highlight mode
            if self.highlight_code_only:
                # --html-highlight=code generates .md files for literate Agda inputs
                # Uses module-based naming: foundations/booleans.lagda.md -> foundations.booleans.md
                if agda_file.name.endswith((".lagda.md", ".lagda.tex", ".lagda")):
                    # Extract module name from the file path (handles all Agda file types)
                    relative_path = agda_file.relative_to(temp_dir)
                    module_name = get_module_name_from_file_path(str(relative_path))
                    expected_file = output_backend_dir / f"{module_name}.md"
                else:
                    # For .agda files, use .html
                    expected_file = (
                        output_backend_dir / agda_file.with_suffix(".html").name
                    )
            else:
                # --html-highlight=all generates .html files with module-based names
                # For foundations/booleans.lagda.md -> foundations.booleans.html
                if agda_file.name.endswith((".lagda.md", ".lagda.tex", ".lagda")):
                    # Extract module name from the file path (handles all Agda file types)
                    relative_path = agda_file.relative_to(temp_dir)
                    module_name = get_module_name_from_file_path(str(relative_path))
                    expected_file = output_backend_dir / f"{module_name}.html"
                else:
                    # For .agda files, use .html
                    expected_file = (
                        output_backend_dir / agda_file.with_suffix(".html").name
                    )

            if self.verbose:
                log.info(f"Looking for expected output file: {expected_file}")

            if expected_file.exists():
                if self.verbose:
                    log.info(f"Found output file: {expected_file}")
                return expected_file
            else:
                if self.verbose:
                    log.warning(f"Expected output file not found: {expected_file}")
                    # List what files were actually created
                    if output_backend_dir.exists():
                        actual_files = list(output_backend_dir.rglob("*"))
                        log.info(f"Files in output directory: {actual_files}")

            return None

        except subprocess.TimeoutExpired:
            log.error(f"Agda compilation timed out for {agda_file}")
            raise
        except Exception as e:
            log.error(f"Error running Agda: {e}")
            raise

    def _process_html(
        self,
        html_file: Path,
        original_markdown: str,
        agda_blocks: list,
    ) -> str:
        """Process the Agda-generated HTML and merge with original markdown.

        Args:
            html_file: Path to Agda-generated HTML
            original_markdown: Original markdown content
            agda_blocks: List of Agda code block positions

        Returns:
            Processed markdown with highlighted Agda code
        """
        html_content = html_file.read_text()

        if self.highlight_code_only:
            # Extract highlighted code blocks from the HTML
            return self._merge_highlighted_code(
                html_content, original_markdown, agda_blocks
            )
        else:
            # Extract content from the generated HTML document
            return self._extract_agda_content(html_content)

    def _merge_highlighted_code(
        self,
        html_content: str,
        original_markdown: str,
        agda_blocks: list,
    ) -> str:
        """Merge highlighted Agda code blocks back into the original markdown.

        Args:
            html_content: Agda-generated HTML content
            original_markdown: Original markdown content
            agda_blocks: List of Agda code block positions

        Returns:
            Markdown with highlighted Agda code blocks
        """
        # Parse the generated content to extract highlighted code
        soup = BeautifulSoup(html_content, "html.parser")

        # Find all Agda code blocks
        code_blocks = soup.find_all("pre", class_="Agda")

        if not code_blocks:
            log.warning("No Agda code blocks found in generated HTML")
            return original_markdown

        # Replace code blocks in the original markdown
        result = original_markdown

        # Pattern to find code blocks - handle optional leading/trailing newlines
        pattern = r"\n?```agda\n(.*?)\n```\n*"

        matches_found = len(re.findall(pattern, result, flags=re.DOTALL))
        log.debug(
            f"Found {matches_found} code blocks to replace, have {len(code_blocks)} Agda HTML blocks"
        )

        def replace_block(match):
            nonlocal code_blocks
            if code_blocks:
                # Get the next highlighted block
                highlighted = str(code_blocks.pop(0))
                log.debug(
                    f"Replacing code block with HTML block of length {len(highlighted)}"
                )
                # Preserve a newline before the HTML block for proper spacing
                return f"\n{highlighted}\n"
            else:
                # Return original if no more highlighted blocks
                log.warning("No more highlighted blocks available for replacement")
                return match.group(0)

        result = re.sub(pattern, replace_block, result, flags=re.DOTALL)

        if code_blocks:
            log.warning(
                f"Still have {len(code_blocks)} unused Agda HTML blocks after replacement"
            )

        return result

    def _extract_agda_content(self, html_content: str) -> str:
        """Extract the Agda content from a full HTML document.

        Args:
            html_content: Full HTML document generated by Agda

        Returns:
            Processed content with markdown structure and highlighted Agda code
        """
        # Parse the HTML document
        soup = BeautifulSoup(html_content, "html.parser")

        # Find the main Agda pre block
        agda_pre = soup.find("pre", class_="Agda")

        if not agda_pre:
            log.warning("No Agda pre block found in generated HTML")
            return html_content

        # Process the content to separate markdown sections from code blocks
        content = self._convert_agda_html_to_markdown(agda_pre)

        return content

    def _convert_agda_html_to_markdown(self, agda_pre) -> str:
        """Convert Agda HTML pre block to markdown with proper structure.

        Args:
            agda_pre: BeautifulSoup element containing the Agda pre block

        Returns:
            Markdown content with proper structure
        """
        # Extract all child elements
        content_parts = []
        current_markdown = []
        in_code_block = False

        for element in agda_pre.children:
            if hasattr(element, "name") and element.name == "a":
                css_class = element.get("class", [])

                # Check if this is a markup element (```agda or ```)
                if "Markup" in css_class:
                    text = element.get_text()
                    if text.strip() == "```agda":
                        # Start of code block - output HTML pre tag instead of markdown code block
                        if current_markdown:
                            content_parts.append("".join(current_markdown).strip())
                            current_markdown = []
                        # Start HTML pre block with Agda class
                        content_parts.append('\n<pre class="Agda">\n')
                        in_code_block = True
                    elif text.strip() == "```":
                        # End of code block - close HTML pre tag
                        content_parts.append("</pre>\n\n")
                        in_code_block = False
                    else:
                        # Other markup, treat as text
                        if in_code_block:
                            content_parts.append(str(element))
                        else:
                            current_markdown.append(text)
                elif "Background" in css_class:
                    # Background text (regular markdown content)
                    text = element.get_text()
                    if not in_code_block:
                        current_markdown.append(text)
                    else:
                        content_parts.append(text)
                else:
                    # Code elements (keep HTML for highlighting)
                    if in_code_block:
                        content_parts.append(str(element))
                    else:
                        # Outside code blocks, extract text only
                        current_markdown.append(element.get_text())
            else:
                # Text nodes or other elements
                text = str(element) if hasattr(element, "strip") else str(element)
                if in_code_block:
                    content_parts.append(text)
                else:
                    current_markdown.append(text)

        # Add any remaining markdown content
        if current_markdown:
            content_parts.append("".join(current_markdown).strip())

        # Join all parts and clean up
        result = "".join(content_parts)

        # Clean up excessive blank lines (more than 2 consecutive) while preserving structure
        # Markdown needs blank lines to separate paragraphs, headings, etc.
        lines = result.split("\n")
        cleaned_lines = []
        consecutive_blanks = 0

        for line in lines:
            if line.strip():
                # Non-blank line - always add it and reset counter
                cleaned_lines.append(line)
                consecutive_blanks = 0
            else:
                # Blank line - only add if we haven't had too many consecutive blanks
                consecutive_blanks += 1
                if consecutive_blanks <= 2:
                    cleaned_lines.append(line)

        return "\n".join(cleaned_lines)
