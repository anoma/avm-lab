"""Main Agda plugin for MkDocs."""

import shutil
import subprocess
import tempfile
from pathlib import Path

try:
    from importlib.metadata import version
except ImportError:
    from importlib_metadata import version

from bs4 import BeautifulSoup
from mkdocs.config import config_options
from mkdocs.config.defaults import MkDocsConfig
from mkdocs.plugins import BasePlugin
from mkdocs.structure.files import File, Files
from mkdocs.structure.pages import Page

from .cache import CacheManager
from .index_generators import (
    DatatypeIndexGenerator,
    FunctionIndexGenerator,
    UsageIndexGenerator,
)
from .inline_references import InlineReferenceProcessor
from .link_verifier import LinkVerifier
from .processor import AgdaProcessor
from .symbol_extractor import SymbolDatabase, SymbolExtractor
from .url_resolver import URLResolver
from .utils import get_module_name_from_file_path, is_agda_file, log


class AgdaPlugin(BasePlugin):
    """MkDocs plugin for processing Agda literate markdown files."""

    config_scheme = (
        ("agda_dir", config_options.Type(str, default="html")),
        (
            "agda_config_dir",
            config_options.Type(str, default=None),
        ),  # New: Agda library config dir
        ("include_css", config_options.Type(bool, default=True)),
        ("include_copy_button", config_options.Type(bool, default=True)),
        ("cache_dir", config_options.Type(str, default=".agda-mkdocs-cache")),
        ("highlight_code_only", config_options.Type(bool, default=True)),
        ("fail_on_error", config_options.Type(bool, default=False)),
        ("verbose", config_options.Type(bool, default=False)),
        ("force_rebuild", config_options.Type(bool, default=False)),
        ("generate_index", config_options.Type(bool, default=True)),
        ("index_filename", config_options.Type(str, default="agda-modules.md")),
        ("index_include_sections", config_options.Type(bool, default=False)),
        # Symbol indexing options
        ("generate_datatype_index", config_options.Type(bool, default=False)),
        (
            "datatype_index_filename",
            config_options.Type(str, default="agda-datatypes.md"),
        ),
        ("generate_function_index", config_options.Type(bool, default=False)),
        (
            "function_index_filename",
            config_options.Type(str, default="agda-functions.md"),
        ),
        ("generate_usage_index", config_options.Type(bool, default=False)),
        ("usage_index_filename", config_options.Type(str, default="agda-usage.md")),
        # Symbol extraction options
        ("include_operators", config_options.Type(bool, default=True)),
        ("include_examples", config_options.Type(bool, default=True)),
        ("min_usage_count", config_options.Type(int, default=1)),
        ("track_cross_module_refs", config_options.Type(bool, default=True)),
        # Inline reference features
        ("enable_inline_references", config_options.Type(bool, default=True)),
        ("inline_ref_unresolved_warning", config_options.Type(bool, default=True)),
        ("generate_references_section", config_options.Type(bool, default=True)),
        # URL rewriting control
        ("rewrite_urls", config_options.Type(bool, default=True)),
        # Module references (bidirectional links like LogSeq)
        ("show_module_references", config_options.Type(bool, default=True)),
        ("show_backreferences", config_options.Type(bool, default=True)),
        ("show_forward_references", config_options.Type(bool, default=True)),
        # HTML generation options (LaTeX backend removed)
        ("custom_css", config_options.Type(str, default=None)),
        ("highlight_occurrences", config_options.Type(bool, default=False)),
        ("compilation_timeout", config_options.Type(int, default=30)),
        # Compilation mode options
        (
            "compilation_mode",
            config_options.Type(str, default="auto"),
        ),  # "batch", "per-file", or "auto"
        ("index_files", config_options.Type(list, default=[])),
        ("auto_generate_index", config_options.Type(bool, default=False)),
        ("index_file_name", config_options.Type(str, default="everything.lagda.md")),
        # Agda pragma flags for auto-generated index files
        (
            "safe_pragma_flags",
            config_options.Type(
                list, default=["--type-in-type", "--guardedness", "--sized-types"]
            ),
        ),
        (
            "conditional_pragma_flags",
            config_options.Type(list, default=["--without-K", "--exact-split"]),
        ),
        # Agda include paths for library dependencies
        ("include_paths", config_options.Type(list, default=[])),
        # Link verification options
        ("verify_links", config_options.Type(bool, default=True)),
        ("verify_anchors", config_options.Type(bool, default=True)),
        ("verify_assets", config_options.Type(bool, default=True)),
        ("fail_on_broken_links", config_options.Type(bool, default=False)),
    )

    def __init__(self):
        """Initialize the plugin."""
        self.processor: AgdaProcessor | None = None
        self.cache: CacheManager | None = None
        self.site_dir: Path | None = None
        self.docs_dir: Path | None = None
        self.temp_dir: Path | None = None
        self.url_map: dict[str, str] = {}  # Maps module names to MkDocs URLs
        self.processed_modules: list[str] = []  # List of processed module names
        self.symbol_extractor: SymbolExtractor | None = None
        self.symbol_database: SymbolDatabase = SymbolDatabase()
        self.url_resolver: URLResolver | None = None  # Centralized URL resolution

    def on_config(self, config: MkDocsConfig) -> MkDocsConfig | None:
        """Initialize plugin configuration."""
        import json
        import os

        # Display plugin version info
        try:
            plugin_version = version("mkdocs-agda-plugin")
            log.info(f"Using mkdocs-agda-plugin v{plugin_version}")
        except Exception:
            log.info("Using mkdocs-agda-plugin (version unknown)")

        # URL handling is now managed by the centralized URLResolver class
        # which provides consistent handling for all deployment scenarios

        self.docs_dir = Path(config["docs_dir"])
        self.site_dir = Path(config["site_dir"])

        # Try to load preprocessed symbol database
        cache_dir = Path(self.config.get("cache_dir", ".agda-mkdocs-cache"))
        symbol_db_path = cache_dir / "symbols.db"
        metadata_path = cache_dir / "metadata.json"

        self.preprocessed = False
        if symbol_db_path.exists():
            log.info("Loading preprocessed symbol database")
            try:
                self.symbol_database = SymbolDatabase.load(symbol_db_path)
                self.preprocessed = True
                log.info(
                    f"Loaded {len(self.symbol_database.symbols)} symbols from cache"
                )

                # Load metadata
                if metadata_path.exists():
                    with open(metadata_path) as f:
                        self.preprocessing_metadata = json.load(f)
                        log.debug(
                            f"Preprocessing metadata: {self.preprocessing_metadata}"
                        )
            except Exception as e:
                log.warning(f"Failed to load symbol database: {e}")
                self.symbol_database = SymbolDatabase()
        else:
            log.debug("No preprocessed symbol database found")
            self.symbol_database = SymbolDatabase()

        # Set AGDA_DIR environment variable if configured
        if self.config["agda_config_dir"]:
            agda_config_path = Path(self.config["agda_config_dir"])
            if not agda_config_path.is_absolute():
                # Make relative to mkdocs.yml location (config file dir)
                mkdocs_dir = Path(config["config_file_path"]).parent
                agda_config_path = (mkdocs_dir / agda_config_path).resolve()
            else:
                agda_config_path = agda_config_path.resolve()
            os.environ["AGDA_DIR"] = str(agda_config_path)
            log.info(f"Set AGDA_DIR={agda_config_path}")

        # Check if Agda is available and get version
        agda_version = None
        if not shutil.which("agda"):
            log.warning(
                "Agda compiler not found. Please install Agda to use this plugin."
            )
        else:
            # Get Agda version
            try:
                result = subprocess.run(
                    ["agda", "--version"],
                    capture_output=True,
                    text=True,
                    timeout=5,
                )
                if result.returncode == 0:
                    # Parse version from output like "Agda version 2.6.4"
                    import re

                    version_match = re.search(r"Agda version ([\d.]+)", result.stdout)
                    if version_match:
                        agda_version = version_match.group(1)
                        log.debug(f"Detected Agda version: {agda_version}")
            except Exception as e:
                log.debug(f"Could not detect Agda version: {e}")

        # Get agda-mkdocs version
        try:
            from importlib.metadata import version as get_version

            agda_mkdocs_version = get_version("mkdocs-agda-plugin")
        except Exception:
            agda_mkdocs_version = "unknown"

        # Add versions to MkDocs extra context for footer
        if "extra" not in config:
            config["extra"] = {}

        config["extra"]["agda_version"] = agda_version
        config["extra"]["agda_mkdocs_version"] = agda_mkdocs_version

        # Append Agda and plugin version to copyright/generator info
        if agda_version and agda_mkdocs_version:
            generator_text = f"Built with <a href='https://github.com/agda/agda'>Agda {agda_version}</a> and <a href='https://github.com/jonaprieto/agda-mkdocs'>agda-mkdocs {agda_mkdocs_version}</a>"

            # Add to copyright if it exists, otherwise add to extra
            if "copyright" in config and config["copyright"]:
                config["copyright"] += f"<br>{generator_text}"
            else:
                config["extra"]["generator_info"] = generator_text

        if not agda_version:
            return config

        # Initialize cache manager
        # Cache directory is relative to project root (where mkdocs.yml is)
        project_root = Path(config["config_file_path"]).parent
        cache_dir_name = self.config["cache_dir"]
        if Path(cache_dir_name).is_absolute():
            cache_dir = Path(cache_dir_name)
        else:
            cache_dir = project_root / cache_dir_name
        self.cache = CacheManager(cache_dir)

        # Clear caches if force_rebuild is enabled
        if self.config["force_rebuild"]:
            log.info("Force rebuild enabled - clearing all caches")
            self.cache.clear()
            # Also clear external Agda cache directories
            external_cache_paths = [
                Path("/tmp/agda-test"),
                Path.home() / ".agda" / "cache",  # Common Agda cache location
            ]
            for cache_path in external_cache_paths:
                if cache_path.exists():
                    try:
                        shutil.rmtree(cache_path)
                        log.debug(f"Cleared external cache: {cache_path}")
                    except Exception as e:
                        log.warning(f"Failed to clear external cache {cache_path}: {e}")

        # Get Agda version
        self.agda_version = self._get_agda_version()

        # Initialize processor
        # Determine CSS path for Agda compilation
        css_path = self.config["custom_css"]
        if self.config["include_css"] and not css_path:
            # Copy the plugin's CSS to temp directory so Agda can use it
            plugin_dir = Path(__file__).parent
            css_source = plugin_dir / "assets" / "stylesheets" / "agda.css"

            # We'll copy it to the temp directory after it's created
            # For now, just set the path that Agda should use
            # The CSS will be at the same level as the html/ directory
            css_path = "../agda.css"

        self.processor = AgdaProcessor(
            agda_dir=self.config["agda_dir"],
            highlight_code_only=self.config["highlight_code_only"],
            verbose=self.config["verbose"],
            custom_css=css_path,
            highlight_occurrences=self.config["highlight_occurrences"],
            timeout=self.config["compilation_timeout"],
            force_rebuild=self.config["force_rebuild"],
            include_paths=self.config["include_paths"],
        )

        # Initialize symbol extractor
        self.symbol_extractor = SymbolExtractor(verbose=self.config["verbose"])

        # Initialize URL resolver
        self.url_resolver = URLResolver(config)

        # Create temporary directory for Agda HTML output
        self.temp_dir = Path(tempfile.mkdtemp(prefix="agda-mkdocs-"))
        log.info(f"Initialized Agda plugin with temp dir: {self.temp_dir}")

        # Copy plugin CSS to temp directory if using default CSS
        if self.config["include_css"] and not self.config["custom_css"]:
            plugin_dir = Path(__file__).parent
            css_source = plugin_dir / "assets" / "stylesheets" / "agda.css"
            if css_source.exists():
                css_dest = self.temp_dir / "agda.css"
                shutil.copy2(css_source, css_dest)
                log.debug("Copied plugin CSS to temp directory for Agda compilation")

        # Generate and add Agda code block CSS
        self._generate_and_add_css(config)

        # Disable link validation warnings since we handle Agda-specific links
        # These warnings occur because:
        # 1. Inline references create .md links but MkDocs sees .lagda.md files
        # 2. Links are validated before on_page_markdown rewrites them
        if "validation" not in config:
            config["validation"] = {}
        if "links" not in config["validation"]:
            config["validation"]["links"] = {}

        # Disable various link warnings we can't prevent
        config["validation"]["links"]["not_found"] = (
            0  # Files with .md vs .lagda.md mismatch
        )
        config["validation"]["links"]["unrecognized_links"] = 0  # Agda-generated links
        config["validation"]["links"]["anchors"] = 0  # Agda-generated anchors
        log.debug("Disabled link validation warnings for Agda-specific links")

        return config

    def on_files(self, files: Files, config: MkDocsConfig) -> Files:
        """Process Agda files and cache results."""
        if not self.processor:
            return files

        agda_files = []
        for file in files:
            if is_agda_file(file.src_path):
                agda_files.append(file)

        if agda_files:
            log.info(f"Found {len(agda_files)} Agda literate files to process")

            # Build URL mapping for link rewriting
            self._build_url_mapping(files, config)

            # Determine compilation mode
            compilation_mode = self.config["compilation_mode"].lower()
            if compilation_mode not in ["batch", "per-file", "auto"]:
                log.warning(
                    f"Invalid compilation_mode '{compilation_mode}', using 'auto'"
                )
                compilation_mode = "auto"

            # Check if index-based compilation is enabled
            index_files = self.config["index_files"]

            # Auto-generate index file if enabled and doesn't exist
            if self.config["auto_generate_index"] and not index_files:
                generated_index = self._auto_generate_index_file(agda_files)
                if generated_index:
                    index_files = [generated_index]
                    log.info(f"Auto-generated index file: {generated_index}")

            # Determine if we should use batch compilation
            use_batch = False
            if compilation_mode == "batch":
                if index_files:
                    use_batch = True
                    log.info("Compilation mode: batch (forced)")
                else:
                    log.warning(
                        "Batch compilation requested but no index file available, falling back to per-file"
                    )
            elif compilation_mode == "per-file":
                use_batch = False
                log.info("Compilation mode: per-file (forced)")
            elif compilation_mode == "auto":
                use_batch = bool(index_files)
                if use_batch:
                    log.info("Compilation mode: auto -> batch (index file available)")
                else:
                    log.info("Compilation mode: auto -> per-file (no index file)")

            if use_batch and index_files:
                log.info(
                    f"Using batch compilation with {len(index_files)} index file(s)"
                )
                processed_files = self._process_via_index_files(agda_files, index_files)

                # Process any remaining files individually (fallback)
                unprocessed_files = [f for f in agda_files if f not in processed_files]

                # Exclude index files from per-file processing to avoid duplication
                index_file_paths = set(index_files)
                unprocessed_files = [
                    f for f in unprocessed_files if f.src_path not in index_file_paths
                ]

                if unprocessed_files:
                    log.info(
                        f"Processing {len(unprocessed_files)} files not covered by index files"
                    )
                    for file in unprocessed_files:
                        self._process_agda_file(file)
            else:
                # Per-file compilation
                log.info(f"Compiling {len(agda_files)} files individually")
                for file in agda_files:
                    self._process_agda_file(file)

            # Resolve anchor ID references to symbol names after all files processed
            if not self.preprocessed and self.symbol_database:
                log.debug(
                    f"Resolving anchor references in {len(self.symbol_database.references)} total references"
                )
                resolved_count = self.symbol_database.resolve_anchor_references()
                log.info(
                    f"Resolved {resolved_count} anchor ID references to symbol names"
                )
                if self.config.get("verbose", False):
                    log.debug(
                        f"Symbol database now has {len(self.symbol_database.symbol_usage)} symbols with usage data"
                    )

            # Skip index generation if using preprocessed data
            if not self.preprocessed:
                # Generate module index if enabled
                if self.config["generate_index"]:
                    self._generate_module_index(files, config)

                # Generate symbol indexes if enabled
                self._generate_symbol_indexes(files, config)

                # Export debug data if verbose mode is enabled
                try:
                    if self.config.get("verbose", False):
                        log.debug("Exporting debug data...")
                        self._export_debug_data()
                except Exception as e:
                    log.error(f"Failed to export debug data: {e}", exc_info=True)
            else:
                log.debug("Skipping index generation - using preprocessed indexes")

            # Add generated indexes to navigation if enabled
            self._add_indexes_to_navigation(config)

            # Copy copy button JavaScript to docs/javascripts
            if self.config["include_copy_button"]:
                self._copy_agda_copy_button_js()

            # Copy plugin CSS to docs/stylesheets
            self._copy_plugin_css()

        return files

    def _build_url_mapping(self, files: Files, config: MkDocsConfig) -> None:
        """Build mapping from Agda module names to MkDocs URLs."""
        # Keep local url_map for backward compatibility
        self.url_map = {}

        for file in files:
            # Check with original src_path before stripping
            if ".lagda.md" in file.src_path:
                # Extract module name from file path BEFORE stripping (handles all Agda file types)
                # Convert path like "numbers.lagda.md" to module name "numbers"
                # Convert path like "data/list.lagda.md" to module name "data.list"
                # Also handles .lagda.tex, .lagda, .agda
                module_name = get_module_name_from_file_path(file.src_path)

                # Strip .lagda from file URLs and paths early so MkDocs generates correct canonical URLs
                # Note: Do NOT modify src_path as it needs to match the actual file on disk
                file.name = file.name.replace(".lagda", "")
                file.url = file.url.replace(".lagda", "")
                file.dest_uri = file.dest_uri.replace(".lagda", "")
                file.abs_dest_path = file.abs_dest_path.replace(".lagda", "")
                file.dest_path = file.dest_path.replace(
                    ".lagda", ""
                )  # Also update dest_path

                # Store mapping both with and without .html extension (for backward compatibility)
                self.url_map[f"{module_name}.html"] = file.url
                self.url_map[module_name] = file.url

                # Add to processed modules list
                self.processed_modules.append(module_name)

                log.debug(f"URL mapping: {module_name}.html -> {file.url}")

        # Build URL mappings in the resolver
        if self.url_resolver:
            self.url_resolver.build_url_mappings(files)

    def _process_agda_file(self, file):
        """Process a single Agda file and cache the result."""
        file_path = self.docs_dir / file.src_path

        # Extract module name for symbol extraction (handles all Agda file types)
        module_name = get_module_name_from_file_path(file.src_path)
        module_url = self.url_map.get(module_name, "")

        # Check cache first (unless force_rebuild is enabled)
        if (
            self.cache
            and not self.config["force_rebuild"]
            and self.cache.is_cached(file_path, file_path.read_text())
        ):
            log.debug(f"File {file.src_path} is already cached")

            # Even if cached, extract symbols from existing HTML if available
            if self.symbol_extractor and module_name:
                # Try to find HTML file in typical Agda output locations
                html_locations = [
                    self.temp_dir / f"{module_name}.html",
                    Path(f"/tmp/agda-test/{module_name}.html"),
                    self.docs_dir / f"{module_name}.html",
                ]

                for html_file in html_locations:
                    if html_file.exists():
                        try:
                            html_content = html_file.read_text()
                            extracted_db = self.symbol_extractor.extract_symbols(
                                html_content, module_name, module_url
                            )
                            # Merge extracted symbols into main database
                            for symbol in extracted_db.symbols.values():
                                self.symbol_database.add_symbol(symbol)
                            for reference in extracted_db.references:
                                self.symbol_database.add_reference(reference)

                            if self.config.get("verbose", False):
                                log.debug(
                                    f"Extracted {len(extracted_db.symbols)} symbols from cached file {module_name} using {html_file}"
                                )
                            break
                        except Exception as e:
                            log.warning(
                                f"Could not extract symbols from HTML {html_file}: {e}"
                            )
                            continue
            return

        log.info(f"Processing Agda file: {file.src_path}")

        try:
            original_content = file_path.read_text()

            processed_content = self.processor.process_file(
                file.src_path,  # Use relative path to preserve directory structure
                original_content,
                self.temp_dir,
                symbol_extractor=self.symbol_extractor,
                symbol_database=self.symbol_database,
                module_name=module_name,
                module_url=module_url,
            )

            # Cache the processed content
            if self.cache:
                self.cache.cache_content(file_path, original_content, processed_content)

        except Exception as e:
            error_msg = str(e)
            log.error(f"Error processing {file.src_path}: {error_msg}")

            if self.config["fail_on_error"]:
                raise
            else:
                # Preserve YAML frontmatter and show detailed error
                lines = original_content.split("\n")
                frontmatter_lines = []
                content_lines = []

                # Extract frontmatter if it exists
                if lines and lines[0].strip() == "---":
                    frontmatter_lines.append(lines[0])
                    for i, line in enumerate(lines[1:], 1):
                        if line.strip() == "---":
                            frontmatter_lines.append(line)
                            content_lines = lines[i + 1 :]
                            break
                        frontmatter_lines.append(line)
                    else:
                        # No closing delimiter found, treat all as content
                        content_lines = lines
                        frontmatter_lines = []
                else:
                    content_lines = lines

                # Build error content with preserved frontmatter
                error_parts = []

                # Add frontmatter if it exists
                if frontmatter_lines:
                    error_parts.append("\n".join(frontmatter_lines))
                    error_parts.append("")  # Empty line after frontmatter

                # Add detailed error message
                error_parts.append('!!! error "Agda Compilation Error"')
                error_parts.append(f"    File: {file.src_path}")
                error_parts.append("")

                # Format the error message properly
                for error_line in error_msg.split("\n"):
                    if error_line.strip():
                        error_parts.append(f"    {error_line}")

                error_parts.append("")

                # Add original content (without frontmatter)
                error_parts.append("## Original Content")
                error_parts.append("")
                error_parts.extend(content_lines)

                error_content = "\n".join(error_parts)

                # Cache error message so we don't retry
                if self.cache:
                    self.cache.cache_content(file_path, original_content, error_content)

    def _is_auto_generated_index(self, index_path: Path) -> bool:
        """Check if an index file is auto-generated by the plugin.

        Args:
            index_path: Path to the index file

        Returns:
            True if file has AUTO-GENERATED marker comment
        """
        if not index_path.exists():
            return False

        try:
            content = index_path.read_text()
            return "AUTO-GENERATED by mkdocs-agda-plugin" in content
        except Exception:
            return False

    def _validate_index_file(
        self, index_path: Path, current_modules: list[str]
    ) -> bool:
        """Validate that an index file imports all current modules.

        Args:
            index_path: Path to the index file
            current_modules: List of module names that should be imported

        Returns:
            True if index file imports all current modules
        """
        if not index_path.exists():
            return False

        try:
            content = index_path.read_text()
            # Extract import statements
            imports = set()
            for line in content.split("\n"):
                stripped = line.strip()
                if stripped.startswith("import "):
                    module = stripped.replace("import ", "").strip()
                    imports.add(module)

            # Check if all current modules are imported
            current_set = set(current_modules)
            missing = current_set - imports
            extra = imports - current_set

            if missing:
                log.debug(f"Index file missing imports: {', '.join(sorted(missing))}")
                return False

            if extra:
                log.debug(f"Index file has extra imports: {', '.join(sorted(extra))}")
                # Extra imports are okay, might be manual additions

            return True
        except Exception as e:
            log.warning(f"Error validating index file: {e}")
            return False

    def _auto_generate_index_file(self, agda_files: list) -> str | None:
        """Auto-generate an index file that imports all Agda modules.

        Args:
            agda_files: List of File objects for .lagda.md files

        Returns:
            Path to generated index file relative to docs_dir, or None if generation failed
        """
        index_file_name = self.config["index_file_name"]

        # Auto-convert .agda to .lagda.md if not already
        if index_file_name.endswith(".agda"):
            index_file_name = index_file_name.replace(".agda", ".lagda.md")
            log.info(
                f"Auto-converting index filename to literate format: {index_file_name}"
            )
        elif not index_file_name.endswith(".lagda.md"):
            index_file_name = index_file_name + ".lagda.md"
            log.info(f"Adding .lagda.md extension to index filename: {index_file_name}")

        index_path = self.docs_dir / index_file_name

        # Extract module names from agda files that actually contain Agda modules
        module_imports = []
        pragma_sets = []  # List of pragma sets from each module
        for file in agda_files:
            # Check if the file contains an Agda module declaration
            try:
                file_path = self.docs_dir / file.src_path
                content = file_path.read_text(encoding="utf-8")

                # Look for module declaration
                import re

                module_match = re.search(
                    r"^module\s+(\S+)\s+where", content, re.MULTILINE
                )
                if not module_match:
                    continue  # Skip files without module declarations

                # Convert file path to module name (handles all Agda file extensions)
                # e.g., "simple-test.lagda.md" -> "simple-test"
                # e.g., "foundations/booleans.lagda.md" -> "foundations.booleans"
                # e.g., "foo.lagda.tex" -> "foo", "bar.lagda" -> "bar", "baz.agda" -> "baz"
                module_name = get_module_name_from_file_path(file.src_path)
                # Skip the index file itself
                index_module = get_module_name_from_file_path(index_file_name)
                if module_name != index_module:
                    module_imports.append(module_name)

                # Extract pragma flags from the file
                pragma_match = re.search(
                    r"\{-#\s*OPTIONS\s+([^#]*?)#-\}", content, re.MULTILINE
                )
                if pragma_match:
                    pragma_text = pragma_match.group(1).strip()
                    # Split on whitespace and add individual flags
                    flags = set(pragma_text.split())
                    pragma_sets.append(flags)

            except Exception as e:
                log.warning(f"Could not read file {file.src_path}: {e}")
                continue

        # Determine compatible pragma flags
        # Use the most inclusive set that is compatible with all modules
        required_pragmas = set()
        if pragma_sets:
            # Start with common flags that appear in all modules
            common_flags = (
                set.intersection(*pragma_sets)
                if len(pragma_sets) > 1
                else pragma_sets[0]
            )

            # Add "safe" flags that don't conflict (configurable)
            all_flags = set.union(*pragma_sets)
            safe_flags = set(self.config.get("safe_pragma_flags", []))

            # Only include conditional flags if ALL modules use them (configurable)
            conditional_flags = set(self.config.get("conditional_pragma_flags", []))

            required_pragmas = common_flags | (safe_flags & all_flags)

            # Add conditional flags only if all modules have them
            for flag in conditional_flags:
                if all(flag in pragma_set for pragma_set in pragma_sets):
                    required_pragmas.add(flag)

        # Handle existing index file
        if index_path.exists():
            is_auto_generated = self._is_auto_generated_index(index_path)

            if is_auto_generated:
                # Auto-generated file: always regenerate (like other indexes)
                log.info(f"Regenerating auto-generated index file: {index_file_name}")
                # Continue to regenerate
            else:
                # User-managed file: validate but don't regenerate
                is_valid = self._validate_index_file(index_path, module_imports)
                if not is_valid:
                    log.warning(
                        f"Index file may be outdated (user-managed): {index_file_name}"
                    )
                    log.warning(
                        "Add AUTO-GENERATED comment to enable automatic updates"
                    )
                log.info(f"Using existing user-managed index file: {index_file_name}")
                return index_file_name

        if not module_imports:
            log.warning("No Agda modules found for auto-generation")
            return None

        # Determine module name for the index file (handles all Agda file types)
        index_module_name = get_module_name_from_file_path(index_file_name)

        # Generate index file content with YAML frontmatter first
        # IMPORTANT: YAML frontmatter MUST be at the very beginning for MkDocs to process it
        lines = [
            "---",
            "title: Everything",
            "search:",
            "  exclude: true",
            "hide:",
            "  - navigation",
            "  - toc",
            "---",
            "",
            "<!-- AUTO-GENERATED by mkdocs-agda-plugin - DO NOT EDIT MANUALLY -->",
            "<!-- This file is automatically updated to import all Agda modules -->",
            "",
            "# Everything",
            "",
            "This module imports all Agda modules in the project for batch compilation.",
            "",
            "```agda",
        ]

        # Add pragma flags if any were found
        if required_pragmas:
            pragma_line = "{-# OPTIONS " + " ".join(sorted(required_pragmas)) + " #-}"
            lines.append(pragma_line)
            lines.append("")

        lines.extend(
            [
                f"module {index_module_name} where",
                "",
            ]
        )

        # Add imports
        for module in sorted(module_imports):
            # Skip the index file itself if it happens to be in the list
            if module != index_module_name:
                lines.append(f"import {module}")

        lines.append("```")
        content = "\n".join(lines) + "\n"

        # Write the file
        try:
            index_path.write_text(content)
            log.info(
                f"Generated literate index file with {len(module_imports)} imports: {index_file_name}"
            )
            return index_file_name
        except Exception as e:
            log.error(f"Failed to generate index file {index_file_name}: {e}")
            return None

    def _process_via_index_files(self, agda_files: list, index_files: list) -> list:
        """Process Agda files via index file batch compilation.

        Args:
            agda_files: List of File objects for .lagda.md files
            index_files: List of index file paths to compile

        Returns:
            List of File objects that were successfully processed via index compilation
        """
        import subprocess

        processed_files = []

        # First, copy all Agda files to temp directory to enable imports
        # Strip YAML frontmatter before passing to Agda
        from .processor import AgdaProcessor

        for file in agda_files:
            src_file = self.docs_dir / file.src_path
            dest_file = self.temp_dir / file.src_path
            dest_file.parent.mkdir(parents=True, exist_ok=True)
            # Read and strip YAML frontmatter
            content = src_file.read_text()
            stripped_content = AgdaProcessor._strip_yaml_frontmatter(content)
            dest_file.write_text(stripped_content)

        for index_file_path in index_files:
            # Resolve index file path relative to docs directory
            index_path = self.docs_dir / index_file_path

            if not index_path.exists():
                log.warning(f"Index file not found: {index_file_path}")
                continue

            log.info(f"Compiling index file: {index_file_path}")

            # Copy index file to temp directory if not already copied
            # Strip YAML frontmatter before passing to Agda
            temp_index_path = self.temp_dir / index_file_path
            if not temp_index_path.exists():
                temp_index_path.parent.mkdir(parents=True, exist_ok=True)
                # Read and strip YAML frontmatter
                content = index_path.read_text()
                stripped_content = AgdaProcessor._strip_yaml_frontmatter(content)
                temp_index_path.write_text(stripped_content)

            # Build Agda command with same options as individual compilation
            cmd = ["agda", "--html"]
            cmd.append(f"--html-dir={self.config['agda_dir']}")

            if self.config["highlight_code_only"]:
                cmd.append("--html-highlight=code")
            else:
                cmd.append("--html-highlight=all")

            if self.config["highlight_occurrences"]:
                cmd.append("--highlight-occurrences")

            # Add index file as argument
            cmd.append(index_file_path)

            try:
                # Run Agda from temp directory
                result = subprocess.run(
                    cmd,
                    cwd=self.temp_dir,
                    capture_output=True,
                    text=True,
                    timeout=self.config["compilation_timeout"],
                )

                if result.returncode != 0:
                    log.error(f"Agda compilation failed for index {index_file_path}")
                    log.error(f"Error: {result.stderr}")
                    log.warning(
                        "Batch compilation failed, falling back to per-file compilation for error reporting"
                    )
                    # Don't continue - fall back to per-file mode below
                    break

                if self.config["verbose"]:
                    log.info(f"Agda stdout: {result.stdout}")
                    if result.stderr:
                        log.info(f"Agda stderr: {result.stderr}")

                # Detect which files were generated by this index compilation
                processed_in_batch = self._detect_processed_files(agda_files)
                processed_files.extend(processed_in_batch)

                log.info(
                    f"Index {index_file_path} generated HTML for {len(processed_in_batch)} files"
                )

            except subprocess.TimeoutExpired:
                log.error(f"Agda compilation timed out for index {index_file_path}")
            except Exception as e:
                log.error(f"Error compiling index {index_file_path}: {e}")

        return processed_files

    def _detect_processed_files(self, agda_files: list) -> list:
        """Detect which Agda files were processed by checking generated output.

        Args:
            agda_files: List of File objects for .lagda.md files

        Returns:
            List of File objects that have corresponding generated output
        """
        processed = []
        output_dir = self.temp_dir / self.config["agda_dir"]

        if not output_dir.exists():
            return processed

        for file in agda_files:
            # Determine expected output file name based on module name (handles all Agda file types)
            module_name = get_module_name_from_file_path(file.src_path)

            # Check for both .html and .md extensions depending on highlight mode
            if self.config["highlight_code_only"]:
                expected_file = output_dir / f"{module_name}.md"
            else:
                expected_file = output_dir / f"{module_name}.html"

            if expected_file.exists():
                log.debug(
                    f"Found generated output for {file.src_path}: {expected_file}"
                )

                # Extract symbols and process content
                try:
                    output_content = expected_file.read_text()

                    # Extract symbols for this module
                    if self.symbol_extractor:
                        module_url = self.url_map.get(module_name, "")
                        extracted_db = self.symbol_extractor.extract_symbols(
                            output_content, module_name, module_url
                        )
                        for symbol in extracted_db.symbols.values():
                            self.symbol_database.add_symbol(symbol)
                        for reference in extracted_db.references:
                            self.symbol_database.add_reference(reference)

                    # Process the content (extract Agda code blocks from generated HTML)
                    processed_content = self.processor._extract_agda_content(
                        output_content
                    )

                    # Get original content for caching
                    original_content = (self.docs_dir / file.src_path).read_text()

                    # Cache the processed content
                    if self.cache:
                        self.cache.cache_content(
                            self.docs_dir / file.src_path,
                            original_content,
                            processed_content,
                        )

                    processed.append(file)

                except Exception as e:
                    log.warning(f"Error processing output for {file.src_path}: {e}")

        return processed

    def _generate_module_index(self, files: Files, config: MkDocsConfig) -> None:
        """Generate an index page listing all processed Agda modules."""
        if not self.processed_modules:
            log.debug("No Agda modules to index")
            return

        # Sort modules by last component (e.g., "booleans" from "foundations.booleans")
        def get_sort_key(module_name):
            # Get last component after splitting by dots
            parts = module_name.split(".")
            return parts[-1]

        sorted_modules = sorted(self.processed_modules, key=get_sort_key)

        # Group modules by their first letter of the last component
        grouped_modules = {}
        for module_name in sorted_modules:
            last_component = get_sort_key(module_name)
            first_letter = last_component[0].upper()
            if first_letter not in grouped_modules:
                grouped_modules[first_letter] = []
            grouped_modules[first_letter].append(module_name)

        # Generate markdown content
        content_lines = [
            "---",
            "title: Agda Modules",
            "search:",
            "  exclude: true",
            "---",
            "",
            "# Agda Modules Index",
            "",
            "This page lists all Agda modules processed by the agda-mkdocs plugin, organized alphabetically.",
            "",
        ]

        # Add section navigation if enabled and there are multiple sections
        if self.config["index_include_sections"] and len(grouped_modules) > 1:
            content_lines.append("## Sections")
            content_lines.append("")
            for letter in sorted(grouped_modules.keys()):
                content_lines.append(f"- [{letter}](#{letter.lower()})")
            content_lines.append("")

        # Add module sections
        for letter in sorted(grouped_modules.keys()):
            modules = grouped_modules[letter]
            content_lines.append(f"## {letter} {{#{letter.lower()}}}")
            content_lines.append("")

            for module_name in modules:
                if module_name in self.url_map:
                    url = self.url_map[module_name]
                    # Convert URL to .lagda.md reference (actual file name)
                    # For use_directory_urls: false, we need to reference actual files
                    lagda_url = (
                        url.replace(".html", ".lagda.md")
                        if url.endswith(".html")
                        else url
                    )
                    if not lagda_url.endswith(".lagda.md"):
                        lagda_url = lagda_url.rstrip("/") + ".lagda.md"
                    content_lines.append(f"- [{module_name}]({lagda_url})")
                else:
                    content_lines.append(f"- {module_name}")
            content_lines.append("")

        # Write the index file
        index_content = "\n".join(content_lines)
        index_filename = self.config["index_filename"]
        index_file_path = self.docs_dir / index_filename

        try:
            index_file_path.write_text(index_content)
            log.info(f"Generated Agda modules index: {index_file_path}")

            # Add the generated file to MkDocs Files collection
            file = File(
                path=index_filename,
                src_dir=str(self.docs_dir),
                dest_dir=config["site_dir"],
                use_directory_urls=config["use_directory_urls"],
            )
            files.append(file)
            log.debug(f"Added {index_filename} to Files collection")
        except Exception as e:
            log.error(f"Error generating module index: {e}")

    def _generate_symbol_indexes(self, files: Files, config: MkDocsConfig) -> None:
        """Generate symbol indexes based on configuration."""
        if not self.symbol_database.symbols:
            log.debug("No symbols found, skipping symbol index generation")
            return

        # Generate datatype index
        if self.config.get("generate_datatype_index", False):
            self._generate_datatype_index(files, config)

        # Generate function index
        if self.config.get("generate_function_index", False):
            self._generate_function_index(files, config)

        # Generate usage index
        if self.config.get("generate_usage_index", False):
            self._generate_usage_index(files, config)

    def _generate_datatype_index(self, files: Files, config: MkDocsConfig) -> None:
        """Generate datatype index."""
        try:
            generator = DatatypeIndexGenerator(self.symbol_database, self.config)
            index_content = generator.generate_index()

            # Use default filename if config filename is empty
            filename = self.config["datatype_index_filename"]
            if not filename or filename.strip() == "":
                filename = "agda-datatypes.md"
                log.warning(
                    f"Empty datatype_index_filename provided, using default: {filename}"
                )

            index_file_path = self.docs_dir / filename
            index_file_path.write_text(index_content)
            log.info(f"Generated Agda datatypes index: {index_file_path}")

            # Add the generated file to MkDocs Files collection
            file = File(
                path=filename,
                src_dir=str(self.docs_dir),
                dest_dir=config["site_dir"],
                use_directory_urls=config["use_directory_urls"],
            )
            files.append(file)
            log.debug(f"Added {filename} to Files collection")
        except Exception as e:
            log.error(f"Error generating datatype index: {e}")

    def _generate_function_index(self, files: Files, config: MkDocsConfig) -> None:
        """Generate function index."""
        try:
            generator = FunctionIndexGenerator(self.symbol_database, self.config)
            index_content = generator.generate_index()

            # Use default filename if config filename is empty
            filename = self.config["function_index_filename"]
            if not filename or filename.strip() == "":
                filename = "agda-functions.md"
                log.warning(
                    f"Empty function_index_filename provided, using default: {filename}"
                )

            index_file_path = self.docs_dir / filename
            index_file_path.write_text(index_content)
            log.info(f"Generated Agda functions index: {index_file_path}")

            # Add the generated file to MkDocs Files collection
            file = File(
                path=filename,
                src_dir=str(self.docs_dir),
                dest_dir=config["site_dir"],
                use_directory_urls=config["use_directory_urls"],
            )
            files.append(file)
            log.debug(f"Added {filename} to Files collection")
        except Exception as e:
            log.error(f"Error generating function index: {e}")

    def _generate_usage_index(self, files: Files, config: MkDocsConfig) -> None:
        """Generate usage index."""
        try:
            generator = UsageIndexGenerator(self.symbol_database, self.config)
            index_content = generator.generate_index()

            # Use default filename if config filename is empty
            filename = self.config["usage_index_filename"]
            if not filename or filename.strip() == "":
                filename = "agda-usage.md"
                log.warning(
                    f"Empty usage_index_filename provided, using default: {filename}"
                )

            index_file_path = self.docs_dir / filename
            index_file_path.write_text(index_content)
            log.info(f"Generated Agda usage index: {index_file_path}")

            # Add the generated file to MkDocs Files collection
            file = File(
                path=filename,
                src_dir=str(self.docs_dir),
                dest_dir=config["site_dir"],
                use_directory_urls=config["use_directory_urls"],
            )
            files.append(file)
            log.debug(f"Added {filename} to Files collection")
        except Exception as e:
            log.error(f"Error generating usage index: {e}")

    def _export_debug_data(self) -> None:
        """Export symbol database and index data for debugging."""
        try:
            cache_dir = Path(self.config.get("cache_dir", ".agda-mkdocs-cache"))
            cache_dir.mkdir(parents=True, exist_ok=True)

            # Export symbol database as JSON
            db_json_path = cache_dir / "symbol_database.json"
            self.symbol_database.save(db_json_path)
            log.info(f"Exported symbol database to {db_json_path}")

            # Export symbol statistics
            stats = {
                "total_symbols": len(self.symbol_database.symbols),
                "total_references": len(self.symbol_database.references),
                "symbols_by_type": {},
                "symbols_by_module": {},
                "references_by_module": {},
                "symbol_usage_counts": {},
            }

            # Count symbols by type
            from .symbol_extractor import SymbolType

            for symbol_type in SymbolType:
                count = len(
                    [
                        s
                        for s in self.symbol_database.symbols.values()
                        if s.symbol_type == symbol_type
                    ]
                )
                stats["symbols_by_type"][symbol_type.value] = count

            # Count symbols by module
            for module, symbol_names in self.symbol_database.module_symbols.items():
                stats["symbols_by_module"][module] = len(symbol_names)

            # Count references by source module
            for ref in self.symbol_database.references:
                if ref.from_module not in stats["references_by_module"]:
                    stats["references_by_module"][ref.from_module] = 0
                stats["references_by_module"][ref.from_module] += 1

            # Count usage per symbol
            for symbol_name, refs in self.symbol_database.symbol_usage.items():
                stats["symbol_usage_counts"][symbol_name] = len(refs)

            # Export statistics
            stats_path = cache_dir / "symbol_statistics.json"
            with open(stats_path, "w") as f:
                import json

                json.dump(stats, f, indent=2)
            log.info(f"Exported symbol statistics to {stats_path}")

        except Exception as e:
            log.error(f"Error exporting debug data: {e}")

    def on_page_read_source(self, page: Page, config: MkDocsConfig) -> str | None:
        """Process Agda files from cache and pre-process links in all markdown files."""
        file_path = self.docs_dir / page.file.src_path

        # For Agda files, return cached content if available and up-to-date
        if self.cache and is_agda_file(page.file.src_path):
            try:
                current_content = file_path.read_text()
                # Check if cache is valid and up-to-date
                if self.cache.is_cached(file_path, current_content):
                    cached_content = self.cache.get_cached(file_path)
                    if cached_content:
                        log.debug(f"Reading cached content for {page.file.src_path}")

                        # Extract frontmatter from original file and prepend to cached content
                        from .processor import AgdaProcessor

                        frontmatter, _ = AgdaProcessor._extract_yaml_frontmatter(
                            current_content
                        )
                        if frontmatter:
                            cached_content = frontmatter + "\n\n" + cached_content

                        # Pre-process links to convert .lagda.md references
                        return self._preprocess_markdown_links(cached_content)

                log.debug(f"Cache invalid or missing for {page.file.src_path}")
                return None
            except Exception as e:
                log.debug(f"Error reading file {page.file.src_path}: {e}")
                return None

        # For regular markdown files, pre-process links to avoid warnings
        if page.file.src_path.endswith(".md"):
            try:
                content = file_path.read_text()
                # Pre-process links to convert .lagda.md references and directory URLs
                return self._preprocess_markdown_links(content)
            except Exception as e:
                log.debug(f"Error reading {page.file.src_path}: {e}")
                return None

        return None

    def on_page_markdown(
        self, markdown: str, page: Page, config: MkDocsConfig, files: Files
    ) -> str:
        """Process inline references and add source link headers for Agda files.

        Note: URL rewriting has been moved to on_page_content hook.
        This hook now only handles markdown-level processing (inline refs, headers, etc).
        """
        # Add source file link header for Agda files
        if is_agda_file(page.file.src_path):
            markdown = self._add_source_link_header(markdown, page)

        # Process inline references for all files (Agda and non-Agda) if enabled
        # Non-Agda files can use Agda@name syntax to reference symbols from Agda modules
        if (
            self.config.get("enable_inline_references", True)
            and len(self.symbol_database.symbols) > 0
        ):
            # Determine current module name (handles all Agda file types)
            current_module = ""
            if is_agda_file(page.file.src_path):
                current_module = get_module_name_from_file_path(page.file.src_path)

            # Process inline references
            processor = InlineReferenceProcessor(
                self.symbol_database,
                current_module,
                verbose=self.config.get("verbose", False),
                url_resolver=self.url_resolver,
                current_page=page,
            )
            markdown = processor.process_content(markdown)

            # Add references section if enabled
            if self.config.get("generate_references_section", True):
                references_section = processor.generate_references_section()
                if references_section:
                    markdown += references_section

        # Add module references section for Agda files if enabled
        if is_agda_file(page.file.src_path) and self.config.get(
            "show_module_references", True
        ):
            # Check for page-specific override in frontmatter
            show_refs = self._should_show_module_references(page)

            if show_refs:
                # Extract module name (handles all Agda file types)
                module_name = get_module_name_from_file_path(page.file.src_path)
                markdown = self._add_module_references_section(
                    markdown, module_name, page
                )

        # .lagda stripping is now done in on_files hook for correct canonical URL generation
        return markdown

    def _should_show_module_references(self, page: Page) -> bool:
        """Check if module references should be shown for this page.

        Checks YAML frontmatter for page-specific override.

        Args:
            page: Current page

        Returns:
            True if module references should be shown
        """
        # Check for frontmatter override
        if hasattr(page, "meta") and page.meta:
            if "show_module_references" in page.meta:
                return page.meta["show_module_references"]

        # Default to config value
        return self.config.get("show_module_references", True)

    def _add_module_references_section(
        self, markdown: str, module_name: str, page: Page
    ) -> str:
        """Add module references section to the page.

        Args:
            markdown: Current page markdown
            module_name: Name of the module
            page: Current page

        Returns:
            Markdown with module references section appended
        """
        from .module_references import ModuleReferencesGenerator

        # Determine which references to show
        show_backrefs = self.config.get("show_backreferences", True)
        show_forward = self.config.get("show_forward_references", True)

        # Check for frontmatter overrides
        if hasattr(page, "meta") and page.meta:
            if "show_backreferences" in page.meta:
                show_backrefs = page.meta["show_backreferences"]
            if "show_forward_references" in page.meta:
                show_forward = page.meta["show_forward_references"]

        # Generate references section
        generator = ModuleReferencesGenerator(self.symbol_database, self.url_map)
        references_section = generator.generate_references_section(
            module_name,
            show_backreferences=show_backrefs,
            show_forward_references=show_forward,
        )

        if references_section:
            markdown += references_section

        return markdown

    def _add_source_link_header(self, markdown: str, page: Page) -> str:
        """Add a small link to the source file at the top of the page.

        Handles YAML frontmatter correctly by inserting the link after frontmatter
        but before the main content.

        Args:
            markdown: Page markdown content
            page: Current page

        Returns:
            Markdown with source link header inserted after frontmatter
        """
        # Get just the filename (not the full path) since source files
        # are copied to the same directory as the generated HTML
        from pathlib import Path

        source_filename = Path(page.file.src_path).name

        # Create small, monospace link to source file using HTML anchor
        # This prevents MkDocs from converting it to .html
        source_link = f'<div style="font-size: 0.85em; font-family: monospace; margin-bottom: 1em;"><a href="{source_filename}">view source: {source_filename}</a></div>\n\n'

        # Check for YAML frontmatter
        if markdown.startswith("---\n"):
            # Find the end of frontmatter
            parts = markdown.split("---\n", 2)
            if len(parts) >= 3:
                # Frontmatter exists: parts[0] is empty, parts[1] is frontmatter, parts[2] is content
                frontmatter = parts[1]
                content = parts[2]
                # Insert source link after frontmatter
                return f"---\n{frontmatter}---\n\n{source_link}{content}"

        # No frontmatter, prepend source link
        return source_link + markdown

    def _preprocess_markdown_links(self, markdown: str) -> str:
        """Pre-process links to convert .lagda.md references to avoid MkDocs warnings.

        This runs in on_page_read_source BEFORE MkDocs validates links.
        """
        import re

        log.debug(f"Preprocessing markdown with {len(markdown)} characters")

        # Pattern to match markdown links
        link_pattern = r"\[([^\]]*)\]\(([^)]+)\)"

        def convert_link(match):
            link_text = match.group(1)
            link_url = match.group(2)
            original_link = match.group(0)

            log.debug(f"Processing link: {original_link}")

            # Skip external links
            if "://" in link_url or link_url.startswith("mailto:"):
                log.debug(f"Skipping external link: {link_url}")
                return match.group(0)

            # Skip anchor-only links
            if link_url.startswith("#"):
                log.debug(f"Skipping anchor-only link: {link_url}")
                return match.group(0)

            # Skip .lagda.md file references - MkDocs will handle them directly
            # For use_directory_urls: false, MkDocs recognizes .lagda.md files
            if ".lagda.md" in link_url:
                log.debug(f"Keeping .lagda.md link as-is: {original_link}")
                return match.group(0)

            # Convert directory-style URLs to .md file references for MkDocs
            # Check if this looks like a directory URL (ends with /)
            if link_url.endswith("/"):
                # Remove trailing slash
                base_path = link_url.rstrip("/")

                # Check if a corresponding .lagda.md file exists
                potential_lagda_file = self.docs_dir / f"{base_path}.lagda.md"
                log.debug(f"Checking for file: {potential_lagda_file}")
                if potential_lagda_file.exists():
                    # Convert to .md reference for MkDocs
                    new_url = f"{base_path}.md"
                    new_link = f"[{link_text}]({new_url})"
                    log.debug(
                        f"Converted directory link: {original_link} -> {new_link}"
                    )
                    return new_link
                else:
                    # Check if a regular .md file exists
                    potential_md_file = self.docs_dir / f"{base_path}.md"
                    log.debug(
                        f"Checking for regular markdown file: {potential_md_file}"
                    )
                    if potential_md_file.exists():
                        # Convert to .md reference for MkDocs
                        new_url = f"{base_path}.md"
                        new_link = f"[{link_text}]({new_url})"
                        log.debug(
                            f"Converted directory link to regular .md: {original_link} -> {new_link}"
                        )
                        return new_link
                    else:
                        log.debug(
                            f"No corresponding .lagda.md or .md file found for {base_path}"
                        )

            # Convert directory-style URLs with anchors (e.g., simple-test/#333)
            if "/#" in link_url:
                base_path, anchor = link_url.split("/#", 1)

                # Check if a corresponding .lagda.md file exists
                potential_lagda_file = self.docs_dir / f"{base_path}.lagda.md"
                log.debug(f"Checking for file with anchor: {potential_lagda_file}")
                if potential_lagda_file.exists():
                    # Convert to .md reference with anchor for MkDocs
                    new_url = f"{base_path}.md#{anchor}"
                    new_link = f"[{link_text}]({new_url})"
                    log.debug(f"Converted anchor link: {original_link} -> {new_link}")
                    return new_link

            log.debug(f"No conversion needed for: {original_link}")
            return match.group(0)

        result = re.sub(link_pattern, convert_link, markdown)
        log.debug(f"Preprocessing complete, result has {len(result)} characters")
        return result

    def _rewrite_markdown_links(self, markdown: str, page: Page, files: Files) -> str:
        """DEPRECATED: Link rewriting moved to on_page_content hook.

        This method is kept for backward compatibility but is no longer used.
        """
        import re

        if not self.url_resolver:
            # If no resolver available, return markdown unchanged
            return markdown

        # Find all markdown links
        link_pattern = r"\[([^\]]*)\]\(([^)]+)\)"

        def replace_link(match):
            link_text = match.group(1)
            link_url = match.group(2)

            # Use the URL resolver to get the correct URL
            new_url = self.url_resolver.resolve_markdown_link(link_url, page, files)

            if new_url != link_url and self.config.get("verbose", False):
                log.debug(f"Rewrote markdown link: {link_url} -> {new_url}")

            return f"[{link_text}]({new_url})"

        # Apply link rewriting
        return re.sub(link_pattern, replace_link, markdown)

    def _make_relative_url(self, current_page: Page, target_url: str) -> str:
        """Calculate relative URL from current page to target URL.

        Delegates to the URL resolver for consistent handling.
        """
        if self.url_resolver:
            return self.url_resolver._make_relative_url(current_page, target_url)

        # Fallback implementation if resolver not available
        from pathlib import Path

        # If target URL is absolute, return as-is
        if target_url.startswith("http") or target_url.startswith("//"):
            return target_url

        # If target URL starts with /, it's already absolute relative to site root
        if target_url.startswith("/"):
            target_url = target_url[1:]  # Remove leading slash for calculation

        # Get current page's URL (should end with .html for use_directory_urls: false)
        current_url = current_page.url

        # Handle anchors in target
        anchor = ""
        if "#" in target_url:
            target_url, anchor = target_url.split("#", 1)
            anchor = f"#{anchor}"

        # Get directory paths (strip filename.html from both)
        current_dir = str(Path(current_url).parent)
        if current_dir == ".":
            current_dir = ""

        target_dir = str(Path(target_url).parent)
        if target_dir == ".":
            target_dir = ""

        # Get filenames
        target_filename = Path(target_url).name

        # Calculate relative path between directories
        current_parts = [p for p in current_dir.split("/") if p]
        target_parts = [p for p in target_dir.split("/") if p]

        # Find common prefix
        common_length = 0
        for i, (current_part, target_part) in enumerate(
            zip(current_parts, target_parts)
        ):
            if current_part == target_part:
                common_length += 1
            else:
                break

        # Calculate relative path
        up_levels = len(current_parts) - common_length
        down_parts = target_parts[common_length:]

        # Construct relative URL
        if up_levels == 0 and len(down_parts) == 0:
            # Same directory
            relative_url = target_filename
        else:
            relative_parts = [".."] * up_levels + down_parts + [target_filename]
            relative_url = "/".join(relative_parts)

        return relative_url + anchor

    def on_page_content(
        self, html: str, page: Page, config: MkDocsConfig, files: Files
    ) -> str:
        """Rewrite all internal links in the rendered HTML.

        This hook runs after markdown->HTML conversion but before template rendering.
        It consolidates all URL rewriting in one place using BeautifulSoup for reliable
        HTML parsing, similar to the mkdocs-site-urls plugin approach.

        Args:
            html: The rendered HTML content
            page: Current page object
            config: MkDocs configuration
            files: Collection of all files

        Returns:
            Modified HTML with rewritten URLs
        """
        # Skip if URL rewriting is disabled
        if not self.config.get("rewrite_urls", True):
            log.debug(f"URL rewriting disabled for {page.file.src_path}")
            return html

        # Skip if no URL resolver available
        if not self.url_resolver:
            log.debug(f"No URL resolver available for {page.file.src_path}")
            return html

        log.debug(f"Rewriting URLs in {page.file.src_path}")

        # Parse HTML with BeautifulSoup
        soup = BeautifulSoup(html, "html.parser")

        # Rewrite all anchor tags (href attributes)
        for a_tag in soup.find_all("a", href=True):
            href = a_tag["href"]

            # Skip external URLs and mailto links
            if href.startswith(("http://", "https://", "//", "mailto:")):
                continue

            # Skip anchor-only links
            if href.startswith("#"):
                continue

            # Determine the type of link and resolve accordingly
            new_href = None

            # Check if this looks like an Agda-generated link (contains .html or module reference)
            if ".html" in href or "/" in href:
                # Try Agda HTML link resolution first
                new_href = self.url_resolver.resolve_agda_html_link(href, page)
            else:
                # Regular markdown link
                new_href = self.url_resolver.resolve_markdown_link(href, page, files)

            # Update href if it changed
            if new_href and new_href != href:
                log.debug(f"Rewrote link: {href} -> {new_href}")
                a_tag["href"] = new_href

        # Rewrite image and resource src attributes (if needed in the future)
        # for tag in soup.find_all(src=True):
        #     src = tag["src"]
        #     if not src.startswith(("http://", "https://", "//", "#")):
        #         # Resolve resource path
        #         new_src = self.url_resolver.resolve_resource(src, page)
        #         if new_src and new_src != src:
        #             tag["src"] = new_src

        return str(soup)

    def on_post_page(self, output: str, page: Page, config: MkDocsConfig) -> str:
        """Post-process the page to include Agda CSS.

        Note: URL rewriting has been moved to on_page_content hook for better reliability.
        """
        if not self.processor or not is_agda_file(page.file.src_path):
            return output

        return output

    def _rewrite_agda_links(self, html_content: str, page: Page) -> str:
        """DEPRECATED: Link rewriting moved to on_page_content hook.

        This method is kept for backward compatibility but is no longer used.
        All link rewriting now happens in on_page_content for better reliability.
        """
        soup = BeautifulSoup(html_content, "html.parser")

        # Find all anchor tags with href attributes
        for a_tag in soup.find_all("a", href=True):
            href = a_tag["href"]

            # Skip non-HTML links (already processed correctly)
            if not (".html" in href or href.startswith("#")):
                continue

            # Use the URL resolver if available
            if self.url_resolver:
                new_url = self.url_resolver.resolve_agda_html_link(href, page)
            else:
                # Fallback for tests and when resolver not available
                # Check if it's an internal link first
                base_href = href.split("#")[0] if "#" in href else href
                if base_href in self.url_map:
                    # Internal link - use url_map value directly
                    new_url = href  # Keep as is since test expects this
                elif ".html" in href:
                    # External module - use relative path
                    new_url = self._make_relative_url(page, href)
                else:
                    new_url = href

            if new_url != href:
                log.debug(f"Rewrote Agda link: {href} -> {new_url}")
                a_tag["href"] = new_url

        return str(soup)

    def on_serve(self, server, config, builder):
        """Add .lagda.md files to the watch list for live reloading.

        Args:
            server: The MkDocs development server
            config: MkDocs configuration
            builder: The MkDocs builder

        Returns:
            The server with additional watch patterns
        """
        from pathlib import Path

        # Watch for .lagda.md file changes
        docs_dir = Path(config["docs_dir"])

        # Add watch patterns for Agda files
        for pattern in ["*.lagda.md", "*.lagda", "*.agda"]:
            for agda_file in docs_dir.rglob(pattern):
                server.watch(str(agda_file))

        log.info("Added .lagda.md files to watch list for live reloading")

        # Also watch the preprocessed symbol database
        cache_dir = Path(self.config.get("cache_dir", ".agda-mkdocs-cache"))
        symbol_db_path = cache_dir / "symbols.db"
        if symbol_db_path.exists():
            server.watch(str(symbol_db_path))

        return server

    def on_post_build(self, config: MkDocsConfig) -> None:
        """Clean up temporary files after build and copy source files."""
        # Copy .lagda.md source files to build output directory
        if self.docs_dir and self.site_dir:
            self._copy_source_files_to_site()

        # Copy all generated HTML files (including stdlib) to site
        if self.temp_dir and self.temp_dir.exists() and self.site_dir:
            self._copy_generated_html_to_site()

        # Verify links if enabled
        if self.config.get("verify_links", True) and self.site_dir:
            self._verify_site_links()

        if self.temp_dir and self.temp_dir.exists():
            shutil.rmtree(self.temp_dir)
            log.debug(f"Cleaned up temp directory: {self.temp_dir}")

        if self.cache:
            self.cache.cleanup()

    def _copy_agda_copy_button_js(self) -> None:
        """Copy agda-copy.js to docs/javascripts for copy button functionality."""
        # Get the plugin's asset directory
        plugin_dir = Path(__file__).parent
        js_source = plugin_dir / "assets" / "javascripts" / "agda-copy.js"

        if js_source.exists():
            js_dest = self.docs_dir / "javascripts" / "agda-copy.js"
            js_dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(js_source, js_dest)
            log.info(
                "Copied agda-copy.js to docs/javascripts - "
                "add 'javascripts/agda-copy.js' to extra_javascript in mkdocs.yml"
            )
        else:
            log.warning(
                f"agda-copy.js not found at {js_source} - copy button will not work"
            )

    def _copy_plugin_css(self) -> None:
        """Copy plugin CSS to docs/stylesheets for Agda styling."""
        # Get the plugin's asset directory
        plugin_dir = Path(__file__).parent
        css_source = plugin_dir / "assets" / "stylesheets" / "agda.css"

        if css_source.exists():
            css_dest = self.docs_dir / "stylesheets" / "agda.css"
            css_dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(css_source, css_dest)
            log.info(
                "Copied agda.css to docs/stylesheets - "
                "add 'stylesheets/agda.css' to extra_css in mkdocs.yml"
            )
        else:
            log.warning(f"agda.css not found at {css_source} - styling may not work")

    def _copy_source_files_to_site(self) -> None:
        """Copy .lagda.md source files to the site directory for direct access."""

        # Find all .lagda.md files in docs directory
        for lagda_file in self.docs_dir.glob("**/*.lagda.md"):
            # Get relative path from docs directory
            rel_path = lagda_file.relative_to(self.docs_dir)

            # Destination path in site directory (same structure)
            dest_path = self.site_dir / rel_path

            # Create parent directory if needed
            dest_path.parent.mkdir(parents=True, exist_ok=True)

            # Copy the source file
            try:
                shutil.copy2(lagda_file, dest_path)
                log.debug(f"Copied source file: {rel_path} -> {dest_path}")
            except Exception as e:
                log.warning(f"Failed to copy source file {lagda_file}: {e}")

    def _copy_generated_html_to_site(self) -> None:
        """Copy all Agda-generated HTML files (including stdlib) to site directory.

        This ensures that links to standard library modules work without 404 errors.
        """
        html_dir = self.temp_dir / self.config["agda_dir"]
        log.info(f"Looking for Agda-generated HTML in: {html_dir}")

        if not html_dir.exists():
            log.info(f"HTML directory does not exist: {html_dir}")
            return

        # Count total HTML files found
        all_html_files = list(html_dir.rglob("*.html"))
        log.info(f"Found {len(all_html_files)} total HTML files in {html_dir}")

        copied_count = 0
        skipped_count = 0

        # Copy all HTML files from temp html directory
        for html_file in all_html_files:
            # Get relative path from html directory
            rel_path = html_file.relative_to(html_dir)

            # Destination in site directory
            dest_path = self.site_dir / rel_path

            # Skip files that MkDocs already generated (our own .lagda.md files)
            # Those are already in the site directory with proper structure
            if dest_path.exists():
                log.debug(f"Skipping already-generated file: {rel_path}")
                skipped_count += 1
                continue

            # Create parent directories
            dest_path.parent.mkdir(parents=True, exist_ok=True)

            # Copy the HTML file
            try:
                shutil.copy2(html_file, dest_path)
                copied_count += 1
                log.info(f"Copied stdlib HTML: {rel_path}")
            except Exception as e:
                log.warning(f"Failed to copy {html_file}: {e}")

        log.info(
            f"Stdlib HTML copy complete: {copied_count} copied, {skipped_count} skipped"
        )

        if copied_count > 0:
            log.info(f"Copied {copied_count} stdlib HTML files to avoid 404 errors")

    def _get_agda_version(self) -> str:
        """Get the Agda version."""
        try:
            result = subprocess.run(
                ["agda", "--version"], capture_output=True, text=True, timeout=10
            )
            if result.returncode == 0:
                # Extract version from output like "Agda version 2.6.4"
                version_line = result.stdout.strip().split("\n")[0]
                if "version" in version_line.lower():
                    version = version_line.split()[-1]
                    return version
            return "unknown"
        except Exception as e:
            log.warning(f"Could not detect Agda version: {e}")
            return "unknown"

    def _generate_agda_css(self, css_file: Path) -> Path | None:
        """Generate the CSS file for Agda code blocks with copy button and label."""
        template_file = Path(__file__).parent / "agda_codeblock_footer.template"

        if not template_file.exists():
            log.error(f"CSS template file not found: {template_file}")
            return None

        try:
            css_file.parent.mkdir(parents=True, exist_ok=True)
            template_content = template_file.read_text()

            # Replace the version placeholder
            agda_label = (
                f"Agda {self.agda_version}"
                if self.agda_version != "unknown"
                else "Agda"
            )
            css_content = template_content.replace("{agda_version}", agda_label)

            css_file.write_text(css_content)

            if css_file.exists():
                log.debug(f"Generated Agda CSS file: {css_file}")
                return css_file
        except Exception as e:
            log.error(f"Error generating Agda CSS file: {e}")

        return None

    def _generate_and_add_css(self, config: MkDocsConfig) -> None:
        """Generate CSS file for Agda code blocks and add it to extra_css."""
        if not self.docs_dir:
            return

        css_file = self.docs_dir / "assets" / "agda-codeblock.css"

        # Generate the CSS file
        generated_css = self._generate_agda_css(css_file)

        if generated_css:
            # Add CSS file to extra_css if not already present
            css_path = generated_css.relative_to(self.docs_dir)
            extra_css = config.get("extra_css", [])

            if css_path.as_posix() not in extra_css:
                config["extra_css"] = extra_css + [css_path.as_posix()]
                log.debug(f"Added Agda CSS to extra_css: {css_path.as_posix()}")

    def _add_indexes_to_navigation(self, config: MkDocsConfig) -> None:
        """Add generated index files to MkDocs navigation if they don't exist."""
        if not config.get("nav"):
            # If no explicit navigation, MkDocs will auto-discover files
            return

        nav = config["nav"]
        index_entries = []

        # Collect all generated index files that should be added
        # Auto-generated everything index
        if self.config.get("auto_generate_index", False):
            index_file = self.config["index_file_name"]
            if (self.docs_dir / index_file).exists():
                index_entries.append(("Everything", index_file))

        if self.config.get("generate_index", True):
            index_file = self.config["index_filename"]
            if (self.docs_dir / index_file).exists():
                index_entries.append(("Agda Modules", index_file))

        if self.config.get("generate_datatype_index", False):
            datatype_file = self.config["datatype_index_filename"]
            if not datatype_file or datatype_file.strip() == "":
                datatype_file = "agda-datatypes.md"
            if (self.docs_dir / datatype_file).exists():
                index_entries.append(("Agda Datatypes", datatype_file))

        if self.config.get("generate_function_index", False):
            function_file = self.config["function_index_filename"]
            if not function_file or function_file.strip() == "":
                function_file = "agda-functions.md"
            if (self.docs_dir / function_file).exists():
                index_entries.append(("Agda Functions", function_file))

        if self.config.get("generate_usage_index", False):
            usage_file = self.config["usage_index_filename"]
            if not usage_file or usage_file.strip() == "":
                usage_file = "agda-usage.md"
            if (self.docs_dir / usage_file).exists():
                index_entries.append(("Agda Usage", usage_file))

        if not index_entries:
            return

        # First, fix any existing titleless entries for these index files
        index_file_map = {filename: title for title, filename in index_entries}
        if index_file_map:
            self._fix_titleless_nav_entries(nav, index_file_map)

        # Check if we need to add an "Agda Index" section
        existing_files = set()
        self._collect_nav_files(nav, existing_files)

        # Only add index entries that aren't already in navigation
        new_entries = []
        for title, filename in index_entries:
            if filename not in existing_files:
                new_entries.append({title: filename})

        if new_entries:
            # Add as a new section at the end
            if len(new_entries) == 1:
                nav.extend(new_entries)
            else:
                nav.append({"Agda Index": new_entries})

            log.info(f"Added {len(new_entries)} Agda index files to navigation")

    def _fix_titleless_nav_entries(self, nav_item, index_file_map: dict) -> None:
        """Fix navigation entries that are strings (titleless) for index files.

        Replaces entries like:
            - ./everything.lagda.md
        With:
            - Everything: ./everything.lagda.md
        """
        if isinstance(nav_item, list):
            for i, item in enumerate(nav_item):
                if isinstance(item, str):
                    # This is a titleless entry
                    normalized = item.lstrip("./")
                    if normalized in index_file_map:
                        # Replace with titled entry
                        title = index_file_map[normalized]
                        nav_item[i] = {title: item}
                        log.info(f"Added title '{title}' to navigation entry: {item}")
                elif isinstance(item, dict) or isinstance(item, list):
                    self._fix_titleless_nav_entries(item, index_file_map)
        elif isinstance(nav_item, dict):
            for key, value in nav_item.items():
                if isinstance(value, list) or isinstance(value, dict):
                    self._fix_titleless_nav_entries(value, index_file_map)

    def _collect_nav_files(self, nav_item, files: set) -> None:
        """Recursively collect all files referenced in navigation."""
        if isinstance(nav_item, list):
            for item in nav_item:
                self._collect_nav_files(item, files)
        elif isinstance(nav_item, dict):
            for key, value in nav_item.items():
                if isinstance(value, str):
                    # Normalize path by removing leading ./
                    normalized = value.lstrip("./")
                    files.add(normalized)
                else:
                    self._collect_nav_files(value, files)
        elif isinstance(nav_item, str):
            # Normalize path by removing leading ./
            normalized = nav_item.lstrip("./")
            files.add(normalized)

    def _verify_site_links(self) -> None:
        """Verify all links in the generated site."""
        log.info("Verifying links in generated site...")

        verifier = LinkVerifier(
            site_dir=self.site_dir,
            verify_anchors=self.config.get("verify_anchors", True),
            verify_assets=self.config.get("verify_assets", True),
            ignore_external=True,  # Always ignore external links
            verbose=self.config.get("verbose", False),
        )

        result = verifier.verify_site()

        # Log results
        if result.has_errors:
            report = verifier.format_report(result)
            log.warning(f"\n{report}")

            if self.config.get("fail_on_broken_links", False):
                raise RuntimeError(
                    f"Link verification failed: {len(result.broken_links)} broken links found"
                )
        else:
            log.info(
                f"Link verification passed: {result.total_links} links checked across {result.files_checked} files"
            )
