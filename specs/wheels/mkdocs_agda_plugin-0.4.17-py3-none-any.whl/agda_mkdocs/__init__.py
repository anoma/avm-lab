"""Agda plugin for MkDocs - Process Agda literate markdown files."""

import importlib.metadata

try:
    __version__ = importlib.metadata.version("mkdocs-agda-plugin")
except importlib.metadata.PackageNotFoundError:
    __version__ = "0.0.0+unknown"
