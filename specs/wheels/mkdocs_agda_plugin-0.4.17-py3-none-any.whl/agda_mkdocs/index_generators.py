"""Index generators for various types of Agda symbols."""

from abc import ABC, abstractmethod

from . import __version__
from .symbol_extractor import Symbol, SymbolDatabase, SymbolType
from .utils import log


def get_version() -> str:
    """Get the agda-mkdocs version for generated files."""
    return __version__


class IndexGenerator(ABC):
    """Base class for generating various types of indexes."""

    def __init__(self, symbol_db: SymbolDatabase, config: dict):
        """Initialize index generator."""
        self.symbol_db = symbol_db
        self.config = config

    @abstractmethod
    def generate_index(self) -> str:
        """Generate the index content."""
        pass

    def group_by_module(self, symbols: list[Symbol]) -> dict[str, list[Symbol]]:
        """Group symbols by their module."""
        grouped = {}
        for symbol in symbols:
            if symbol.module not in grouped:
                grouped[symbol.module] = []
            grouped[symbol.module].append(symbol)
        return grouped

    def _escape_symbol_name(self, name: str) -> str:
        """Escape special characters in symbol names to prevent markdown interpretation."""
        # No escaping needed here - the inline_references.py will handle escaping
        # when creating the markdown link
        return name

    def _generate_anchor_id(self, symbol_name: str, suffix: str = "") -> str:
        """Generate a valid HTML anchor ID from a symbol name.

        Uses a general approach that works for any Agda symbol:
        - Keeps alphanumeric characters as-is (lowercase)
        - Replaces underscores with 'u' (e.g., _&&_ -> u-x26-x26-u)
        - Encodes other characters as hex (e.g., <$> -> x3c-x24-x3e)
        - Ensures uniqueness and determinism for all possible Agda symbols

        Examples:
            Bool -> bool
            _&&_ -> u-x26-x26-u
            _<$>_ -> u-x3c-x24-x3e-u
            ++-assoc -> x2b-x2b-assoc
            not -> not
            ≡-refl -> x2261-refl

        Args:
            symbol_name: The symbol name
            suffix: Optional suffix to append (e.g., "-usage")

        Returns:
            Valid HTML anchor ID
        """
        import hashlib

        # Build anchor by processing each character
        parts = []
        i = 0
        while i < len(symbol_name):
            char = symbol_name[i]

            if char.isalnum():
                # Keep alphanumeric as-is
                parts.append(char.lower())
            elif char == "-":
                # Keep hyphens (but avoid double-hyphens)
                if parts and parts[-1] != "-":
                    parts.append("-")
            elif char == "_":
                # Underscores become 'u' with separators
                if parts and parts[-1] != "-":
                    parts.append("-")
                parts.append("u")
            else:
                # Encode special characters as hex
                hex_code = format(ord(char), "x")
                if parts and parts[-1] != "-":
                    parts.append("-")
                parts.append(f"x{hex_code}")

            i += 1

        # Join parts and clean up
        anchor = "".join(parts)

        # Remove leading/trailing hyphens
        anchor = anchor.strip("-")

        # Ensure anchor is not empty (fallback to hash)
        if not anchor:
            hash_hex = hashlib.md5(symbol_name.encode()).hexdigest()[:8]
            anchor = f"symbol-{hash_hex}"

        # Add suffix if provided
        if suffix:
            # Ensure there's a separator before suffix
            if not anchor.endswith("-"):
                anchor += "-"
            anchor += suffix.lstrip("-")

        return anchor

    def _convert_url_to_markdown_file(self, url: str) -> str:
        """Convert URL pointing to HTML files of Agda Literate Markdown files
        to markdown file reference (MkDocs will convert to .html). This
        processing is expected to happend before MkDocs processes the markdown
        files.

        Examples:
            simple-test.html -> simple-test.lagda.md foundations/booleans.html
            -> foundations/booleans.lagda.md simple-test.html#123 ->
            simple-test.lagda.md#123 foundations/booleans.html#456 ->
            foundations/booleans.lagda.md#456

        Note: We use .lagda.md so MkDocs can find the actual files for
        validation. MkDocs will automatically convert .lagda.md references to
        .html during build.
        """
        # Handle anchor fragment
        if "#" in url:
            base_url, anchor = url.split("#", 1)
            # Replace .html with .lagda.md
            if base_url.endswith(".html"):
                base_url = base_url.replace(".html", ".lagda.md")
            elif not base_url.endswith(".lagda.md"):
                base_url = base_url.rstrip("/") + ".lagda.md"
            md_url = base_url + "#" + anchor
        else:
            # Replace .html with .lagda.md
            if url.endswith(".html"):
                md_url = url.replace(".html", ".lagda.md")
            elif not url.endswith(".lagda.md"):
                md_url = url.rstrip("/") + ".lagda.md"
            else:
                md_url = url

        return md_url

    def _generate_header_comment(self) -> str:
        """Generate HTML comment header for generated files."""
        return f"<!-- This file was automatically generated by agda-mkdocs version {get_version()} -->"


class DatatypeIndexGenerator(IndexGenerator):
    """Generate index for datatypes, records, and their constructors."""

    def generate_index(self) -> str:
        """Generate the datatype index content."""
        datatypes = self.symbol_db.get_by_type(SymbolType.DATATYPE)
        records = self.symbol_db.get_by_type(SymbolType.RECORD)
        # Combine datatypes and records for unified indexing
        all_types = datatypes + records
        constructors = self.symbol_db.get_by_type(SymbolType.CONSTRUCTOR)

        if not all_types:
            log.debug("No datatypes or records found for index generation")
            return self._generate_empty_index()

        # Group constructors by their parent datatype
        constructor_map = self._group_constructors_by_datatype(constructors)

        # Group datatypes and records by module for better organization
        module_groups = self.group_by_module(all_types)

        content_lines = [
            "---",
            "title: Agda Datatypes and Records",
            "search:",
            "  exclude: true",
            "---",
            "",
            self._generate_header_comment(),
            "",
            "# Agda Datatypes and Records Index",
            "",
            "This page lists all datatypes and records defined in the Agda modules, organized by module.",
            "",
        ]

        for module_name in sorted(module_groups.keys()):
            module_types = module_groups[module_name]
            content_lines.extend(
                self._generate_module_section(
                    module_name, module_types, constructor_map
                )
            )

        return "\n".join(content_lines)

    def _generate_empty_index(self) -> str:
        """Generate empty index when no datatypes or records found."""
        return "\n".join(
            [
                self._generate_header_comment(),
                "",
                "# Agda Datatypes and Records Index",
                "",
                "No datatypes or records have been processed yet.",
                "",
            ]
        )

    def _group_constructors_by_datatype(
        self, constructors: list[Symbol]
    ) -> dict[str, list[Symbol]]:
        """Group constructors by their parent datatype."""
        constructor_map = {}

        for constructor in constructors:
            # Extract datatype name from constructor anchor ID
            # Format is typically "DataType.constructor"
            if "." in constructor.anchor_id:
                datatype_name = constructor.anchor_id.split(".")[0]
            else:
                # Fallback: try to infer from module context
                datatype_name = "Unknown"

            if datatype_name not in constructor_map:
                constructor_map[datatype_name] = []
            constructor_map[datatype_name].append(constructor)

        return constructor_map

    def _generate_module_section(
        self,
        module_name: str,
        datatypes: list[Symbol],
        constructor_map: dict[str, list[Symbol]],
    ) -> list[str]:
        """Generate a section for a specific module."""
        lines = []

        # Module header
        module_display = module_name.replace(".", " › ")
        module_anchor = module_name.replace(".", "-").lower()
        lines.extend(
            [
                f"## {module_display} {{#{module_anchor}}}",
                "",
            ]
        )

        for datatype in sorted(datatypes, key=lambda d: d.name.lower()):
            lines.extend(
                self._generate_compact_datatype_entry(datatype, constructor_map)
            )

        lines.append("")
        return lines

    def _generate_compact_datatype_entry(
        self, datatype: Symbol, constructor_map: dict[str, list[Symbol]]
    ) -> list[str]:
        """Generate compact entry for a single datatype or record."""
        lines = []

        # Create datatype/record link using Agda@ syntax for proper styling and resolution
        # Escape special characters that might be interpreted as HTML markup
        escaped_name = self._escape_symbol_name(datatype.name)
        datatype_link = f"Agda@{escaped_name}"

        # Add type indicator for records
        type_indicator = (
            " (record)" if datatype.symbol_type == SymbolType.RECORD else ""
        )

        if datatype.signature:
            lines.append(f"- {datatype_link}{type_indicator} : `{datatype.signature}`")
        else:
            lines.append(f"- {datatype_link}{type_indicator}")

        # Add constructors inline if available (only for datatypes, not records)
        constructors = constructor_map.get(datatype.name, [])
        if constructors:
            constructor_links = []
            for constructor in sorted(constructors, key=lambda c: c.name):
                escaped_constructor_name = self._escape_symbol_name(constructor.name)
                constructor_link = f"Agda@{escaped_constructor_name}"
                constructor_links.append(constructor_link)
            lines.append(f"  - Constructors: {', '.join(constructor_links)}")

        return lines


class FunctionIndexGenerator(IndexGenerator):
    """Generate index for functions and operators."""

    def generate_index(self) -> str:
        """Generate the function index content."""
        functions = self.symbol_db.get_by_type(SymbolType.FUNCTION)
        operators = self.symbol_db.get_by_type(SymbolType.OPERATOR)

        if not functions and not operators:
            log.debug("No functions or operators found for index generation")
            return self._generate_empty_index()

        content_lines = [
            "---",
            "title: Agda Functions",
            "search:",
            "  exclude: true",
            "---",
            "",
            self._generate_header_comment(),
            "",
            "# Agda Functions Index",
            "",
            "This page lists all functions and operators defined in the Agda modules.",
            "",
        ]

        # Add operators section
        if operators and self.config.get("include_operators", True):
            content_lines.extend(self._generate_operators_section(operators))

        # Add regular functions section
        if functions:
            content_lines.extend(self._generate_functions_section(functions))

        return "\n".join(content_lines)

    def _generate_empty_index(self) -> str:
        """Generate empty index when no functions found."""
        return "\n".join(
            [
                self._generate_header_comment(),
                "",
                "# Agda Functions Index",
                "",
                "No functions or operators have been processed yet.",
                "",
            ]
        )

    def _generate_operators_section(self, operators: list[Symbol]) -> list[str]:
        """Generate the operators section."""
        lines = [
            "## Operators {#operators}",
            "",
        ]

        module_groups = self.group_by_module(operators)
        for module_name in sorted(module_groups.keys()):
            module_operators = module_groups[module_name]

            # Module subheader
            module_display = module_name.replace(".", " › ")
            lines.extend(
                [
                    f"### {module_display}",
                    "",
                ]
            )

            # Create compact list of operators for this module
            for operator in sorted(module_operators, key=lambda o: o.name):
                escaped_name = self._escape_symbol_name(operator.name)
                operator_link = f"Agda@{escaped_name}"
                if operator.signature:
                    lines.append(f"- {operator_link} : `{operator.signature}`")
                else:
                    lines.append(f"- {operator_link}")

            lines.append("")

        return lines

    def _generate_functions_section(self, functions: list[Symbol]) -> list[str]:
        """Generate the regular functions section."""
        lines = [
            "## Regular Functions {#functions}",
            "",
        ]

        module_groups = self.group_by_module(functions)
        for module_name in sorted(module_groups.keys()):
            module_functions = module_groups[module_name]

            # Module subheader
            module_display = module_name.replace(".", " › ")
            lines.extend(
                [
                    f"### {module_display}",
                    "",
                ]
            )

            # Create compact list of functions for this module
            for function in sorted(module_functions, key=lambda f: f.name):
                escaped_name = self._escape_symbol_name(function.name)
                function_link = f"Agda@{escaped_name}"
                if function.signature:
                    lines.append(f"- {function_link} : `{function.signature}`")
                else:
                    lines.append(f"- {function_link}")

            lines.append("")

        return lines


class UsageIndexGenerator(IndexGenerator):
    """Generate index for symbol usage and back-references."""

    def generate_index(self) -> str:
        """Generate the usage index content."""
        # Get all symbols with minimum usage count
        min_usage = self.config.get("min_usage_count", 1)

        symbols_with_usage = []
        for symbol in self.symbol_db.symbols.values():
            references = self.symbol_db.get_references_to(symbol.name)
            if len(references) >= min_usage:
                symbols_with_usage.append((symbol, references))

        if not symbols_with_usage:
            log.debug("No symbols with sufficient usage found for index generation")
            return self._generate_empty_index()

        # Sort by usage count (descending) then by name
        symbols_with_usage.sort(key=lambda x: (-len(x[1]), x[0].name.lower()))

        content_lines = [
            "---",
            "title: Symbol Usage",
            "search:",
            "  exclude: true",
            "---",
            "",
            self._generate_header_comment(),
            "",
            "# Symbol Usage Index",
            "",
            "This page shows where each symbol is used throughout the codebase.",
            "",
        ]

        for symbol, references in symbols_with_usage:
            content_lines.extend(self._generate_symbol_usage_entry(symbol, references))
            content_lines.append("")

        return "\n".join(content_lines)

    def _generate_empty_index(self) -> str:
        """Generate empty index when no usage found."""
        return "\n".join(
            [
                self._generate_header_comment(),
                "",
                "# Symbol Usage Index",
                "",
                "No symbols with sufficient usage have been found yet.",
                "",
            ]
        )

    def _generate_symbol_usage_entry(
        self, symbol: Symbol, references: list
    ) -> list[str]:
        """Generate usage entry for a single symbol."""
        lines = []

        # Filter out references from external modules (not in our project)
        internal_references = [
            ref
            for ref in references
            if ref.from_module in self.symbol_db.module_symbols
        ]

        if not internal_references:
            # Skip symbols with no internal references
            return []

        # Symbol header
        symbol_anchor = self._generate_anchor_id(symbol.name, "-usage")
        escaped_name = self._escape_symbol_name(symbol.name)
        lines.extend(
            [
                f"## `{symbol.name}` {{#{symbol_anchor}}}",
                f"**Defined in:** Agda@{escaped_name}",
                f"**Total references:** {len(internal_references)}",
                "",
            ]
        )

        # Group references by type and module
        ref_groups = self._group_references(internal_references)

        for ref_type, refs in ref_groups.items():
            if refs:
                lines.extend(self._generate_reference_group(ref_type, refs))

        lines.append("---")
        return lines

    def _group_references(self, references: list) -> dict[str, list]:
        """Group references by type."""
        groups = {
            "Type Signatures": [],
            "Pattern Matching": [],
            "Expressions": [],
            "Other": [],
        }

        for ref in references:
            if ":" in str(ref.context) and ref.reference_type.value == "type":
                groups["Type Signatures"].append(ref)
            elif "=" in str(ref.context) and ref.reference_type.value == "pattern":
                groups["Pattern Matching"].append(ref)
            elif ref.reference_type.value == "usage":
                groups["Expressions"].append(ref)
            else:
                groups["Other"].append(ref)

        return groups

    def _generate_reference_group(self, group_name: str, references: list) -> list[str]:
        """Generate a group of references."""
        lines = [
            f"### {group_name} ({len(references)})",
            "",
        ]

        # Deduplicate references with identical context and module
        seen = set()
        unique_refs = []
        for ref in references:
            # Create key from module and context to identify duplicates
            key = (ref.from_module, ref.context)
            if key not in seen:
                seen.add(key)
                unique_refs.append(ref)

        # Show up to 10 unique references
        for ref in unique_refs[:10]:
            module_url = ref.from_module.replace(".", "/")

            # Add line number anchor if available
            if ref.line_number:
                module_url += f"#{ref.line_number}"

            if ref.context:
                # Strip Agda@ syntax to prevent inline reference resolution
                context = ref.context.strip().replace("Agda@", "")[:100]
                if len(ref.context) > 100:
                    context += "..."
                # Escape any remaining special characters
                context = context.replace("[", "\\[").replace("]", "\\]")

                location_text = f"[{ref.from_module}]({module_url})"
                if ref.line_number:
                    location_text = (
                        f"[{ref.from_module}:{ref.line_number}]({module_url})"
                    )

                lines.append(f"- `{context}` in {location_text}")
            else:
                lines.append(f"- [{ref.from_module}]({module_url})")

        # Show count of remaining unique references
        remaining = len(unique_refs) - 10
        if remaining > 0:
            lines.append(f"- ... and {remaining} more unique reference(s)")

        lines.append("")
        return lines
